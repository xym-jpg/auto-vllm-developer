# Encoder-Cache-Miss 修复分析（DyCP + PD 分离 + 多模态抢占）

> **范围**：汇总 5 份分析师报告，覆盖 `D:/xym/Code/ant/0713/vllm`（HEAD `3a1d3c4f4`，PD 分离 / Ascend / Mooncake / kimi-k2.5-w4a8）与 `D:/xym/Code/ant/0713/vllm-ascend` 中 Encoder-Cache-Miss 崩溃的背景、根因、复现、patch 演进（patch1→patch2→patch3）、验证状态与源码现状。
> **行号约定 / 基线**：源码行号统一以**干净 HEAD `3a1d3c4f435782a5e9c3d19f221c7241fe6bd0b5`** 为准——这正是 patch3 的基线，其 index blob `d590b5d`(cross_dp_scheduler)/`6cef209`(scheduler) 与干净 HEAD blob 哈希完全一致，故 patch3 是**干净 HEAD 完整版补丁**。assert 在 `gpu_model_runner.py:2779`（`.get` 在 `:2778`，该文件干净/dirty 一致）；落盘文档（报告 2/3/4）多误记为 `:2780`（off-by-one），本文件**纠正为 `:2779`**。
> **磁盘实况**：`0713/vllm` 工作区 = 干净 HEAD + 未提交改动（offload-adapt M4–M7 + `encode_cache_miss.patch` 复现埋点 + RequestManager 幂等加固 + per-rank token-budget assert），`cross_dp_scheduler.py` 较干净 HEAD 多约 +155 行。因此若直接读磁盘，行号较本文件引用普遍偏移 +22~+145；括注里给出磁盘 dirty 行号。**阅后请 `git checkout --` 回干净 HEAD 再 apply patch3**，以本文件行号为准。
> **来源**：报告 1（6 份 patch 逐 hunk 分析）、报告 2（`方案结论.md` 提取）、报告 3（`修复方案.md` 提取）、报告 4（`线上crash-多模态encoder适配-方案结论.md` 提取，含 A/C/D/E 缺陷链扩展）、报告 5（当前 HEAD 源码核对）。5 份报告齐备，无缺口。

---

## 1. 问题背景

**部署拓扑**：2 节点 × 16 卡 D 节点，`data-parallel-size=32`、`dp-per-domain=16` ⇒ 2 个 domain = 2 个独立 `CrossDPScheduler` 实例，每个 domain = 16 个 DP rank（调度器视角 `cp_world_size=16`）。PD 分离：P 节点 `kv_producer`（2DP×8TP），D 节点 `kv_consumer`（32DP×1TP）。动态 CP（DyCP）：长序列走 CP 切 16 路，短序列走单路 DP。模型 kimi-k2.5（MLA + MoE，多模态）。

**线上 crash 现象**：D 节点 running 队列调度中，某 request `allocate_slots` 分配 `new_blocks` 失败触发抢占；被抢的带图 request 重新走 prefill 时崩在 `gpu_model_runner.py:2779`：

```python
encoder_output = self.encoder_cache.get(mm_hash, None)        # :2778
assert encoder_output is not None, f"Encoder cache miss for {mm_hash}."  # :2779
```

Ascend CP 路径对应 `pcp_utils.py:371-372`（`gather_mm_embeddings_for_pcp` 内，由 `model_runner_v1.py:1088` 在 `common_pcp_size > 1` 时派发）。

**触发链（一句话结论）**：running 队列抢占 → 被抢的带图请求重排 prefill → 换 rank → 新 rank 的 runner 从没算过这张图的 encoder，scheduler 又没把它派给新 rank 重算 → `_gather_mm_embeddings` 取 `encoder_cache[mm_hash]` 得 None → 崩 `:2779`。

**复现闭环**（HEAD `3a1d3c4f4` + 强制抢占调试代码 `flagg=1` / `new_blocks=None`）：

| 时刻 | 日志 | 含义 |
|---|---|---|
| 03:24:33.533 | `len(self.running):2 → new_blocks:None → get in premmpt` | running 队列触发抢占 |
| 03:24:33.533 | `[repro] PREEMPTED req_id=...-22-968e7db4 preempted_by=...-30-8d74a230 mm_hashes=['61ef1e3b...'] cp_ranks=[4] prev_num_computed=141 has_encoder_inputs=True` | 队尾带图请求 22 被抢，已 decode 到 141 tok，占 rank4 |
| 之后 | `_preempt_request` 置 `num_computed=0`，重入 waiting，重新 prefill | 释放已算 KV，重走 prefill |
| 03:24:33.668 | `Worker_Domain0_DP3_EP3 ... AssertionError: Encoder cache miss for 61ef1e3b...` | 崩在 DP3 |

**闭环判定**：崩的 mm_hash `61ef1e3b...` == 被抢请求 22 的 `mm_hashes[0]`；请求 22 被抢时在 rank4、崩在 DP3（换 rank 了）→ 崩的就是被抢请求自身，重排到新 rank 取不到 encoder。与线上描述逐字一致。

> 复现用的手动抢占/调试日志为临时代码（见 §3.4、§4.4），验证修复后必须还原。

---

## 2. 问题根因

### 2.1 根因 A — CrossDPScheduler 未实现 encoder input 调度

`CrossDPScheduler.schedule()`（`cross_dp_scheduler.py:811-1608`）整体重写基类 `schedule()`，**从不调用** `_try_schedule_encoder_inputs`（全文件 grep 零命中，报告 5 实测确认），running/waiting loop 仅为 TODO/注释占位：

- `cross_dp_scheduler.py:927-929`（running loop）：`"""TODO(AoChen): Encoder inputs scheduling is not implemented yet."""`
- `cross_dp_scheduler.py:1234-1236`（waiting loop）：三行全注释 `# encoder_inputs_to_schedule = None` / `# external_load_encoder_input = []` / `# new_encoder_compute_budget = encoder_compute_budget`
- 基类 `scheduler.py:423`（running）/`:695`（waiting）才会调用 `_try_schedule_encoder_inputs`（干净 HEAD；磁盘 dirty `:428`/`:708`），但被重写后不再触达

**后果**：被抢请求重排进 waiting、再被调度为 prefill 时，scheduler 不把它放进任何 rank 的 `scheduled_encoder_inputs` → 没有哪个 D worker 为它算 encoder → 它重排落到的那个 rank 的 `encoder_cache` 里没有它的 mm_hash → miss。

### 2.2 根因 B — 账本全局共享 vs encoder tensor GPU 进程局部

- `gpu_model_runner.py:503` `self.encoder_cache: dict[str, torch.Tensor] = {}` 是 worker 进程局部 dict；读取 `:2778`、写入 `_execute_mm_encoder`（`:2566-2717`）、消费 `_gather_mm_embeddings`（`:2719-2826`）、批装 `_batch_mm_inputs_from_scheduler`（`:2523-2564`）。
- scheduler 侧却是全局单例：
  - 基类 `scheduler.py:208-212` 创建单一 `self.encoder_cache_manager`
  - `cross_dp_scheduler.py:1577` `free_encoder_mm_hashes=self.encoder_cache_manager.get_freed_mm_hashes()`（单一 manager 养全 16 rank）
  - `CrossDPScheduler` 的 `SchedulerOutput` 用单一 `scheduled_encoder_inputs` dict 喂全部 16 个 rank
  - `cross_dp_scheduler.py:807-809` `_preempt_request` 仅调 `super()._preempt_request(...)` 后置 `kv_transfer_params=None`，无 encoder-cache 释放、无 per-rank `prev_cp_ranks` 处理

**后果**：scheduler 的全局记账无法区分"这个 cache hit 是哪个 rank 的 worker 真持有的 tensor"。被抢请求从 rank4 换到 rank3，rank3 的 runner 从没算过这张图，scheduler 全局账本却可能因别处 hit 就不重算 → rank3 上 miss。

### 2.3 复现证据（闭环）

见 §1 复现闭环表。判定三要素：(1) 崩的 mm_hash == 被抢请求 mm_hash[0]；(2) 被抢时 cp_ranks=[4]（单 rank）；(3) 崩在 DP3（换 rank）。三者闭环证明崩点即被抢请求重排后在新 rank 取不到 encoder。报告 4（§12.3）补充：短请求 `cp_size=1` 抢占只触发 B 不触发 A（CP comm 撕裂），与本次复现场景吻合。

### 2.4 四个缺口（patch3 追补对象）

| 缺口 | 描述 | patch 对应 |
|---|---|---|
| **缺口 1**（记账顺序约束） | `_free_encoder_cache_for_request` 依赖 `request.cp_ranks`（兜底 `prev_cp_ranks`）。preemption 路径必须是「先 free encoder cache（cp_ranks 还在）→ 再 `cp_ranks=[]`、`prev_cp_ranks=原`」。修复版 `_preempt_request` 顺序正确但无注释，后人易引入泄漏 | patch3 加 ORDER CONSTRAINT 注释 |
| **缺口 2**（长序列多 rank 重排边界） | 每 rank `encoder_compute_budgets[rank]` 独立 = `max_num_encoder_input_tokens`；16 个 rank 各自重算同一张大图，若某 rank 预算不足 → 该 rank `can_allocate=False` → `num_new_tokens=0` → 该 rank 不算 encoder → SchedulerOutput 不含此 mm_hash → 该 rank runner 仍可能 miss。修复版 `num_new_tokens==0` 整请求 break 短期避开，但被抢长请求可能卡住/再异常 | patch3 加 WARN 日志 + 整请求跳过 |
| **缺口 3**（ECConnector 联动未 rank-local） | `gpu_model_runner.py:2715` `maybe_save_ec_to_connector` 路径修复版未动 runner 侧。当前用 MooncakeConnector（KV 层）不触发；报告 5 实测 `vllm-ascend` 全仓 grep `maybe_save_ec_to_connector` 零命中——save 侧根本未实现，只有 recv 侧 `maybe_get_ec_connector_output`（`model_runner_v1.py:1452`）。留备忘，若以后开 ECConnector（跨节点共享 encoder）需复查 | 留备忘，未修 |
| **缺口 4**（回退 free） | `check_and_update_cache` 探测时加引用；waiting loop 在 `num_new_tokens==0` / `new_blocks is None` 回退时必须 `encoder_cache_managers[rank].free(request)` 释放探测引用，否则泄漏引用、破坏后续 cache 记账 | patch3 保留两处回退 free |

### 2.5 patch2 共病（重大更正，报告 2 §11 / 报告 4 §11）

patch2（及 patch1）把 encoder 处理分支插在 waiting loop 里、**在 `load_kv_async` 的 async 分支（置 `WAITING_FOR_REMOTE_KVS` 等 KV）之前**：

```python
if request.has_encoder_inputs:        # ← 不分 load_kv_async，无脑进
    for rank in selected_dp: _try_schedule_encoder_inputs_for_rank(..., num_new_tokens=0)
    if num_new_tokens == 0: free + break   # ← 把请求提前跳出 waiting loop
```

带图 PD 请求首 prefill 时 `load_kv_async=True`、`num_new_tokens=0` 是 KV 异步加载的**正常状态**（KV 没传完，scheduler 不分配新 prefill token）。但无守卫的 encoder 分支 `num_new_tokens==0 → break`，请求永远到不了 async 分支（`if load_kv_async: ... WAITING_FOR_REMOTE_KVS ... continue`），KV 异步加载流程被截断、`num_computed_tokens` 永不推进、**所有**带图 PD 请求死循环。实测 diag 日志铁证（2026-07-16）：

```
It's a short req, selected_dp:[0], num_new_tokens:0
[diag-pre] nct=0 n_tokens=141 load_kv_async=True nect=140 nnt BEFORE=0
[encoder-sched] skip req ... (mm=True): ... will retry next step.
```

每帧重复，请求永不进 running。**此卡死与 2779 无关**（是 GPT 修复引入的设计顺序错误），但**阻止 2779 验证**：请求走不到"被抢重排 prefill"，无法观察 2779 是否被消。必须先修此卡死。patch1 在 GPT 上（无 async KV，`load_kv_async` 恒 False）无害；移植到 GLM PD 路径（patch2）即激活共病。

---

## 3. 问题解决方法

### 3.1 修复演进 patch1 → patch2 → patch3

| patch | 角色 | 核心改动 | 解决根因 A | 解决根因 B | 缺陷 |
|---|---|---|---|---|---|
| **patch1**（`patch1-gpt方案.patch`，~18 KB，GPT 骨架） | per-rank 框架 | per-rank `self.encoder_cache_managers`、`_try_schedule_encoder_inputs_for_rank`、本地 `_preempt_request`、running+waiting 双补全、`SchedulerOutput(idx)` per-rank、两处回退 free | 是 | 是（single→per-rank） | 无 `and not load_kv_async` 守卫、无 ORDER 注释、无 WARN；GPT 上无害，PD 上激活共病 |
| **patch2**（`patch2-glm.patch`，~19 KB，GLM 变体） | patch1 骨架 + 可观测性 | patch1 骨架 + 缺口 1 ORDER 注释 + 缺口 2 `[encoder-sched] WARN` | 是 | 是 | **仍无 `and not load_kv_async` 守卫 → 共病**：所有带图 PD 请求死循环 |
| **patch3**（`encode_cache_miss_fix.patch`，~20 KB，**最终推荐**） | 干净 HEAD 完整版 | patch1 骨架 + 缺口 1 ORDER 注释 + 缺口 2 `and not load_kv_async` **治本守卫** + `[encoder-sched] WARN` 文案修正 + 缺口 4 回退 free | 是 | 是 | 无（clean production merge） |
| **`online_crash_reproduce_and_fix.patch`**（~24 KB） | patch3 + repro 一体 | patch3 全量修复 + `encode_cache_miss.patch` 复现埋点（`flagg=1`/`new_blocks=None`/`[repro]` 日志）合并为单一可应用 diff | 是 | 是 | 含调试代码，非 production；用于线上复现+修复一体 |
| **`encode_cache_miss.patch`**（~5 KB）/ **`repro_recompute_preempt.patch`**（~4 KB） | DEBUG-ONLY 复现 harness | 强制抢占 `flagg=1`/`new_blocks=None`、放宽抢占候选、`[repro] PREEMPTED` 日志（cross_dp / recompute 两条路径） | — | — | DEBUG ONLY，须验证后清除；确认 crash 在两条路径都复现，证明修复应落在 scheduler 层 |

> **patch3 性质（报告 4 §13.6）**：是"让 encoder 骑文本抢占骨架"的**正确性适配**，非多模态优化。patch3 只在 `free` 和 `rerank` 两个点让 encoder 镜像 KV，不改抢占骨架；回答"怎么让 encoder 不崩"，不回答"怎么让多模态抢占不贵不 OOM"（后者属 patch4 方向，见 §4.4）。

### 3.2 patch3 关键改动逐项（带 diff 片段）

下述 hunk 行号引自报告 1 对 `encode_cache_miss_fix.patch`（cross_dp_scheduler 基线 `d590b5d..5b69a1c`；scheduler 基线 `6cef209..5ce0a6f`）的逐 hunk 分析。

**(1) per-rank `encoder_cache_managers` 初始化**（`@@ -227,6 +227,20 @@`，`__init__`）——根因 B 核心：单 manager → 每 rank 一份，并 alias `[0]` 兼容基类：

```diff
+        encoder_cache_manager_cls = (
+            EncoderDecoderCacheManager
+            if self.is_encoder_decoder
+            else EncoderCacheManager
+        )
+        encoder_cache_size = self.encoder_cache_manager.cache_size
+        self.encoder_cache_managers = [
+            encoder_cache_manager_cls(cache_size=encoder_cache_size)
+            for _ in range(self.cp_world_size)
+        ]
+        self.encoder_cache_manager = self.encoder_cache_managers[0]
```

**(2) per-rank 辅助方法**（`@@ -261,6 +275,47 @@`）：新增 `_encoder_cache_ranks`（返回 `request.cp_ranks or request.prev_cp_ranks`）、`_free_encoder_cache_for_request`（逐拥有 rank 释放）、`_free_encoder_inputs_for_rank`、`_try_schedule_encoder_inputs_for_rank`（转发基类并传该 rank 的 manager）、`reset_encoder_cache`：

```diff
+    def _try_schedule_encoder_inputs_for_rank(
+        self, request, rank, num_computed_tokens, num_new_tokens, encoder_compute_budget,
+    ) -> tuple[list[int], int, int, list[int]]:
+        return self._try_schedule_encoder_inputs(
+            request, num_computed_tokens, num_new_tokens, encoder_compute_budget,
+            shift_computed_tokens=1 if self.use_eagle else 0,
+            encoder_cache_manager=self.encoder_cache_managers[rank],
+        )
```

**(3) 本地 `_preempt_request` + ORDER CONSTRAINT**（`@@ -783,7 +838,23 @@`）——缺口 1 + 2779 崩点中心修复。不调 `super`，内联以保证 free encoder cache 在 `cp_ranks` 仍存活时执行；`num_computed_tokens=0` 本身 load-bearing（被抢带图请求若以 `num_computed>0` 恢复但无 cache 项，仍会对已落 computed 窗口的 `mm_position` miss）：

```diff
+        self.kv_cache_manager.free(request)
+        # ORDER CONSTRAINT: _free_encoder_cache_for_request must run while
+        # request.cp_ranks is still populated (it frees the per-rank encoder
+        # cache bookkeeping for exactly the ranks this request occupies).
+        # Clearing cp_ranks / saving prev_cp_ranks must happen AFTERWARDS.
+        self._free_encoder_cache_for_request(request)
+        request.status = RequestStatus.PREEMPTED
+        request.num_computed_tokens = 0
+        if request.spec_token_ids:
+            request.spec_token_ids = []
+        request.num_preemptions += 1
+        if self.log_stats:
+            request.record_event(EngineCoreEventType.PREEMPTED, timestamp)
+        self.waiting.prepend_request(request)
         request.kv_transfer_params = None
```

**(4) finished / connector 路径 rank-scoped**（`@@ -323,7 +378,7 @@` / `@@ -359,7 +414,7 @@`）：`_free_encoder_inputs` → `_free_encoder_inputs_for_rank(request, scheduler_output.cp_rank)`；`self.encoder_cache_manager.free(request)` → `self._free_encoder_cache_for_request(request)`。

**(5) per-rank `scheduled_encoder_inputs` / `encoder_compute_budgets`**（`@@ -841,9 +912,14 @@`）：

```diff
-        # # Encoder-related.
-        scheduled_encoder_inputs: dict[str, list[int]] = {}
-        encoder_compute_budget = self.max_num_encoder_input_tokens
+        scheduled_encoder_inputs: list[dict[str, list[int]]] = [
+            {} for _ in range(self.cp_world_size)
+        ]
+        encoder_compute_budgets = [
+            self.max_num_encoder_input_tokens for _ in range(self.cp_world_size)
+        ]
```

**(6) running loop 补全 encoder 调度**（`@@ -897,9 +973,34 @@`，替换 `:909` TODO 占位）：对每个 `rank in request.cp_ranks` 调 `_try_schedule_encoder_inputs_for_rank`，累积 per-rank 字典，`num_new_tokens==0` 时 `req_index += 1; continue`。

**(7) running loop per-rank 写入**（`@@ -1001,6 +1102,14 @@`）：KV 块分配后按拥有 rank 记账并提交 rank-local 预算：

```diff
+                input_ids = encoder_inputs_to_schedule.get(rank, [])
+                if input_ids:
+                    scheduled_encoder_inputs[rank][request_id] = input_ids
+                    for input_id in input_ids:
+                        self.encoder_cache_managers[rank].allocate(request, input_id)
+                    encoder_compute_budgets[rank] = new_encoder_compute_budgets[rank]
+                for input_id in external_encoder_inputs.get(rank, []):
+                    self.encoder_cache_managers[rank].allocate(request, input_id)
```

**(8) waiting loop encoder 块 + `and not load_kv_async` 守卫 + `[encoder-sched] WARN`**（`@@ -1222,6 +1331,54 @@`）——**缺口 2 治本**（消共病）+ 缺口 4 回退 free。守卫阻止 encoder 调度在 PD 异步 KV 加载阶段（`num_new_tokens` 故意为 0）运行，否则 `num_new_tokens==0` 分支会在 async-KV 分支前置 `WAITING_FOR_REMOTE_KVS` 之前 break，困死所有带图 PD 请求：

```diff
+                if request.has_encoder_inputs and not load_kv_async:
+                    # Guard `not load_kv_async`: while the remote KV for this
+                    # PD request is still being fetched asynchronously,
+                    # num_new_tokens is intentionally 0 ... Running the encoder
+                    # scheduling here would hit the `num_new_tokens == 0` path
+                    # below and `break` out of the waiting loop BEFORE the
+                    # async-KV branch ... stranding every multimodal PD request
+                    # in an infinite retry loop. Only schedule encoder work
+                    # once the KV is ready (real prefill).
+                    for rank in selected_dp:
+                        (input_ids, num_new_tokens, new_budget, external_input_ids) = self._try_schedule_encoder_inputs_for_rank(
+                            request, rank, num_computed_tokens, num_new_tokens, encoder_compute_budgets[rank],
+                        )
+                        ...
+                    if num_new_tokens == 0:
+                        for rank in selected_dp:
+                            self.encoder_cache_managers[rank].free(request)
+                        logger.warning(
+                            "[encoder-sched] skip req %s (mm=%s): "
+                            "encoder budget/cache reduced num_new_tokens to 0 "
+                            "on selected_dp=%s; will retry next step.",
+                            request.request_id, request.has_encoder_inputs, selected_dp,
+                        )
+                        break
```

**(9) `new_blocks is None` 回退 free**（`@@ -1236,6 +1393,11 @@`）——缺口 4 第二处：

```diff
+                    if request.has_encoder_inputs:
+                        for rank in selected_dp:
+                            self.encoder_cache_managers[rank].free(request)
                     break
```

**(10) waiting loop per-rank 写入**（`@@ -1320,6 +1482,15 @@`，running loop 的镜像）。

**(11) per-rank `free_encoder_mm_hashes` / `scheduled_encoder_inputs` 发射**（`@@ -1398,6 +1569,9 @@` / `@@ -1406,12 +1580,18 @@` / `@@ -1421,7 +1601,7 @@` / `@@ -1429,7 +1609,7 @@`）：`free_encoder_mm_hashes = [manager.get_freed_mm_hashes() for manager in self.encoder_cache_managers]`；给空输出短路加 `and not free_encoder_mm_hashes[idx]`（避免仅释放 encoder hash 的步骤被塌缩成空 SchedulerOutput）；每 per-rank `SchedulerOutput` 喂 `scheduled_encoder_inputs[idx]` / `free_encoder_mm_hashes[idx]`。

**(12) 基类 `_try_schedule_encoder_inputs` 加 `encoder_cache_manager` 入参**（`scheduler.py @@ -1129,6 +1129,7 @@` / `@@ -1152,6 +1153,8 @@` / `@@ -1207,7 +1210,7 @@` / `@@ -1228,7 +1231,7 @@`）——A/B 桥接：默认 `None` 时用 `self.encoder_cache_manager`，内部三处 `self.encoder_cache_manager.check_and_update_cache(...)` / `.can_allocate(...)` 改用传入的 `encoder_cache_manager.*`，让 `CrossDPScheduler` 驱动某 rank 调度时不污染其他 rank 的 manager。

> 报告 5 实测当前 HEAD 的 `scheduler.py:1138-1145` 基类签名**不带** `encoder_cache_manager` 入参，证明该桥接**未落地**——patch3（含 patch1 桥接）整体仍 pending。

### 3.3 patch3 有效性路径

被抢请求 22（cp_ranks=[4]）重排到 rank3 → 对 rank3 调 `_try_schedule_encoder_inputs_for_rank(22, 3, ..., manager[3])`：22 的 `num_computed_tokens` 被抢时归零（新 prefill）→ rank3 独立账本 `check_and_update_cache` 返回 False → 22 进 rank3 `scheduled_encoder_inputs[3]` → DP3 worker `_execute_mm_encoder` 算 → `encoder_cache[61ef1e3b...]` 写入 → `_gather_mm_embeddings` 取得到 → **不崩 2779**。

异步 KV 路径（共病消除）：`load_kv_async=True` 时跳过 encoder 分支 → 继续到 `allocate_slots(delay_cache_blocks=True, num_external>0)` 成功 → 进 `if load_kv_async:` async 分支 → `WAITING_FOR_REMOTE_KVS` + `continue`，正常等 KV。验证依据（报告 2 §11.4）：`CrossDPKVCacheManager.allocate_slots` L425 `raise ValueError` 条件为 `num_new_tokens==0 and num_external==0`；async 分支 `num_external>0`（=nect=140）不触发，`delay_cache_blocks=True` 走 KV 接收缓冲路径返回非 None。

### 3.4 复现/调试 harness（DEBUG ONLY）

**`encode_cache_miss.patch`**（cross_dp 路径，`d590b5dbd0..fb1aa370ee`）：

- `@@ -798,6 +798,9 @@`：`schedule()` 起始注入 `flagg = 1` + `-------------------------new schedule---------------------` 日志
- `@@ -858,8 +861,10 @@`：`request_num` 计数器
- `@@ -938,16 +943,24 @@`：强制抢占——`len(self.running)>1 and flagg==1 and request_num==1` 时强制 `new_blocks=None`：

```diff
+                    if (len(self.running) > 1 and flagg == 1 and request_num == 1):
+                        new_blocks = None
+                        flagg = 0
+                    else:
+                        new_blocks = self.kv_cache_manager.allocate_slots(
                         request.cp_ranks, request,
-                        num_new_tokens,
+                        num_new_tokens ,
                         num_lookahead_tokens=self.num_lookahead_tokens,
                     )
```

- `@@ -964,10 +977,29 @@`：放宽抢占候选（`if candidate is not request:` 去掉 `any(共享 cp_rank)`）+ `[repro] PREEMPTED req_id=... mm_hashes=... cp_ranks=... prev_num_computed=... has_encoder_inputs=...` 日志

**`repro_recompute_preempt.patch`**（`vllm_ascend/core/recompute_scheduler.py`，`debd03f4..6db8d180`，注释 `# DEBUG ONLY — REMOVE BEFORE MERGE.`）：镜像同一强制抢占到 ascend recompute 路径（`@@ -351,16 +359,27 @@` `flagg=1`/`new_blocks=None`；`@@ -371,6 +390,18 @@` `[repro][recompute] PREEMPTED` 日志）。证明同一 crash 类在 recompute 路径也复现，验证修复应落在 scheduler 层而非 cross_dp 专属。

**`online_crash_reproduce_and_fix.patch`** = patch3 全量修复 + 上述 repro 埋点合并为单一可 apply diff。因 repro hunk 插在 patch3 各 hunk 之间，新侧行号**累计非均匀偏移 +3 → +5 → +32**（`flagg`/`request_num` 各 +3/+5；其后 938/964 两 repro hunk 再 +27），用于线上环境一次 apply 同时复现+修复。修复逻辑与 `encode_cache_miss_fix.patch` byte-identical，仅多 repro/instrumentation hunk。

`encode_cache_miss.patch` 另含第 5 个 hunk `@@ -1202,7 +1234,7 @@`（行尾空白清理，trivial）。环境变量 `VLLM_REPRO_MM_PREEMPT` 门控 repro 行为；复现产物 `reproduce-log-*.txt` / `log_decode_0/1.log` 不在落盘目录（落盘 `抢占逻辑优化/` 仅有 patch+结论 MD），原始日志在远端 `vllm-ascend-tools/kimi-k25/dycp/`（报告 4 §13 引用）；落盘 MD（方案结论.md:72-75 / 修复方案.md:77-80 / 线上crash:72-75）已内嵌关键日志帧，本文件 §1 表据此誊录。

---

## 4. 验证与状态

### 4.1 验证步骤（报告 2/3 §6 第 8-10 步，真实 PD 环境双场景）

| 步 | 场景 | 通过判据 |
|---|---|---|
| 8 | 用 patch3 跑能稳定复现的 bench（§1 强制抢占那套） | (a) 被抢请求重排时，新 rank 的 SchedulerOutput 的 `scheduled_encoder_inputs` **包含**它的 input_id；(b) 新 rank worker 日志里 `_execute_mm_encoder` 真算了该 mm_hash；(c) **不再崩 2779**，被抢请求正常完成；(d) 带图 PD 请求首 prefill 不死循环、`[encoder-sched]` WARN 不刷屏 |
| 9 | 长序列（CP 切多 rank）被抢场景 | 缺口 2 不触发（被抢长请求能整请求跳过/正常重算，不崩）；若 `[encoder-sched]` WARN 高频，提示 KV 就绪请求因 encoder 容量被跳过（自愈但需调 `max_num_encoder_input_tokens` / `encoder_cache_size`） |
| 10 | 正常多模态流量回归（无强制抢占） | per-rank 改造未引入正确性回归；带图请求正常 prefill+decode+complete |

> 原则（报告 2/3/4 一致）：修复进正式代码前必须在本双节点 PD 环境跑验证，不只靠静态分析。

### 4.2 线上 crash 验证结果

**报告 3（`修复方案.md`，2026-07-16 21:34，较晚的整合重写版）** 头部状态升格为："线上 crash 已稳定复现并闭环；最终修复 `encode_cache_miss_fix.patch` 已应用并验证成功修复复现问题。" 步骤 9 在测试机验证——`encode_cache_miss_fix.patch` 成功修复复现的崩溃。

**报告 4（`线上crash-多模态encoder适配-方案结论.md`，最大最新版 63,790 B，mtime 2026-07-22）** 头部仍为"待落地与验证"，但 §13.14 记载 patch3 "per-rank encoder 账本三轮表现正常无 miss"。变更日志（§9）延伸至 2026-07-21，期间根因图景从单一 B 扩展为缺陷链 A/B/C/D/E（见 §4.4）。

**两份文档对 patch3 本身的一致结论**：per-rank encoder 账本对消 2779 miss 有效；三轮实测无 miss、无死循环。

### 4.3 当前源码状态（报告 5 对磁盘 HEAD `3a1d3c4f4` 的逐行核对）

**判定：patch3 仍 PENDING（未 apply），当前源码为 buggy 基线。** 证据：

| 检查项 | patch3 应有 | 当前磁盘实测 | 结论 |
|---|---|---|---|
| `_try_schedule_encoder_inputs` 调用 | running+waiting 两处调 | 全文件 grep 零命中 | 未实现 |
| running loop encoder | 补全 | `:927-929` `TODO(AoChen): ... not implemented yet.` | 仍 TODO |
| waiting loop encoder | 补全 | `:1234-1236` 三行注释 | 仍注释 |
| `self.encoder_cache_managers`（复数） | 存在 | 零命中；仅单一 `encoder_cache_manager`（`:384` free / `:1577` get_freed_mm_hashes） | 仍单例 |
| `and not load_kv_async` 守卫 | 存在 | grep 零命中；`:347` 仅 `if request.has_encoder_inputs:` | 缺守卫 |
| `_free_encoder_cache_for_request` | 存在 | 零命中 | 缺失 |
| `_preempt_request` 本地实现 + 顺序约束 | 本地 + ORDER | `:807-809` 仅 `super()._preempt_request(...)` + `kv_transfer_params=None` | 仍 super |
| 基类 `_try_schedule_encoder_inputs` 入参 | 带 `encoder_cache_manager` | `scheduler.py:1138-1145` stock 签名无此参数 | 桥接未落地 |
| `maybe_save_ec_to_connector`（vllm-ascend） | —（缺口 3 未修，预期缺失） | 全仓 grep 零命中（仅 recv 侧 `maybe_get_ec_connector_output` `:1452`） | 缺口 3 确认未实现 |

当前 `0713/vllm` 工作区另有未提交改动：offload-adapt M4–M7 fork（`:1020-1105`）、RequestManager 幂等加固（`:116-186`）、per-rank token-budget assert（`:1482-1504`）——以及 **`encode_cache_miss.patch` 复现埋点正 applied 在工作区**（`flagg=1`/`request_num=0`/`new_blocks=None`/`logger.info('...new schedule...')`，强制抢占，**触及调度**，非"不触 encoder 路径"）。故磁盘 cross_dp_scheduler.py = 干净 HEAD + 复现埋点 + offload-adapt 叠加态。`maybe_localize_scheduler_output_for_mm_preprocess` 确认存在于 `pcp_utils.py:421-488`（save/restore `free_encoder_mm_hashes`，`:451`/`:484-486`）。

> **状态冲突说明**：报告 3 称 patch3"已应用并验证"，报告 4 称"待落地"，报告 5 实测磁盘仍 buggy。合理解释：报告 3 记录的是测试机一次性 apply+验证的成功记录，未回流到 `0713` 主工作区；`0713` 工作区的修复已 `git stash`（`stash@{1}: GPT-fix encoder cache rank-local (resume repro baseline)`；`stash@{0}` 为 `encode_cache_miss_fix` 更大的工作版本），复现调试代码散落在 `cross_dp_scheduler.py`，正式修复尚未 commit。**以报告 5 实测为准：当前干净 HEAD 仍是 buggy，patch3 待正式落地。**

### 4.4 残留与后续

**必须清除**：`cross_dp_scheduler.py` 中的 `flagg=1` / `new_blocks=None` 手动抢占开关、放宽的 `if candidate is not request:` 抢占条件、各处 `logger.info` / `[diag-pre]` / `[diag-post]` / `[repro]` 打印、`import os`。还原方式：`git checkout -- vllm/v1/core/sched/cross_dp_scheduler.py vllm/v1/core/sched/scheduler.py` 回干净 HEAD，再 apply patch3（patch3 是干净 HEAD 完整版，非增量，**不可叠加在 patch1/patch2 之上**）。

**缺口 3（ECConnector）**：当前 MooncakeConnector 不触发，留备忘；若以后开 ECConnector（跨节点共享 encoder）需复查 runner save 侧。

**patch3 未覆盖的独立缺陷（报告 4 §12/§13，存在干净与 patched 两版，属 patch4 方向）**：

| 缺陷 | 机制 | 与 patch3 关系 |
|---|---|---|
| **A**（CP comm shape-mismatch hang） | `_forward_decode_pcp_dcp`（`attention_cp.py:527-533`）每 decode 步整组 `all_gather(query,1)` 仅由 `dcp_size>1` 门控；CP 长请求 decode 抢占使某 rank `num_decodes`/`num_decode_tokens` 与组偏离 → shape mismatch → HCCL all-to-all 超时（~2min）→ `aivec error` → 全集群 Stuck 级联。裸 HEAD 固有 | patch3 未覆盖（仍 `free+cp_ranks=[]`，无 shape 对齐）。短请求 `cp_size=1` 不触发 A，patch3 对短请求**充分**；长请求**部分覆盖** |
| **C**（preempt-rerank OOM） | 崩点 `vllm_ascend/ops/fused_moe/comm_utils.py:32` MoE a2a `new_empty` → `RuntimeError: NPU out of memory (57.27/61.28 GiB)`。decode 阶段长 CP 带图请求（`prev_num_computed=7310`, `cp_ranks=[0..15]`）被抢 → `num_computed=0` → 降级为单 rank 全 7310-token prefill，激活 + 800MB MoE a2a recv + encoder 重算全压一张 KV 饱和 D 卡 | patch3 未覆盖；OOM ∝ rerank prefill token 数（1×7310→OOM；46–59×147–161→0 OOM，与多模态/抢占次数无关） |
| **D**（preempt=CP→单 rank 不可逆降级） | `_preempt_request`（干净 HEAD `:785` / patch3 post-image `~:838`）模态无关 `free+num_computed=0+cp_ranks=[]`；rerank waiting loop `:1201-1202` 永久 `specify_dp=True` → 单 rank → `:1245` 固化 → 永不回 CP。`:1223` "short req" 是单 rank 放置**非短序列**（07-21 全部 46 条 "short req" 均被抢降级长请求，0 真短请求） | patch3 未改骨架，D 保留 |
| **E**（fresh-CP encoder 跨 rank 复制） | fresh 长 CP prefill 时 per-rank 包装只换 manager；`check_and_update_cache` miss 返回 False 不登记 → 16 rank 独立 miss → 16 rank 全排同一图 → 一图算/存至多 16× | 代码坐实，但 PD 配置下 D 只做 CP decode（`num_new_tokens=0/1`）不做 fresh prefill，**不触发** |

**patch4 治本方向（报告 4 §13.14/§13.15）**：① 抢占候选过滤——跳过 decode 阶段长 CP 请求（`len(cp_ranks)>1 and num_computed>=num_prompt_tokens`），一箭双雕防 C+A，最轻止血；② 长请求降级保护——recompute-free 等（KV 延迟回收、`num_computed` 不归零、status=WAITING）；③ activation budget gating——rerank 前 `num_new_tokens+encoder_tokens` can-allocate 门控；④ 缺口 E 优化（可选，非 PD）。建议先上 ① + 日志探线上 A 频率，再定 ②/③。encoder 专项方案族 6 个（①不 free encoder+rerank 优先落持图 rank / ②一次算+跨 rank 复制 / ③生命周期解耦 preempt / ④rerank 不降级保 CP 重切 / ⑤activation budget / ⑥候选过滤），分阶段路径：Phase 1 止血=⑥；Phase 2 治本=③+①；Phase 3 可选=②/⑤/④。

---

## 5. 关键文件索引

### 5.1 落盘修复文件（`D:/xym/落盘/抢占逻辑优化/`）

| 文件 | 角色 | 落盘路径 | 大小 / 日期 |
|---|---|---|---|
| `encode_cache_miss_fix.patch` | **patch3 最终推荐**（干净 HEAD 完整版） | `D:/xym/落盘/抢占逻辑优化/encode_cache_miss_fix.patch` | 19,689 B / Jul 16 20:21 |
| `patch1-gpt方案.patch` | patch1 GPT per-rank 骨架 | 同目录 | 17,923 B / Jul 16 |
| `patch2-glm.patch` | patch2 GLM 变体（含共病） | 同目录 | 19,203 B / Jul 16 |
| `online_crash_reproduce_and_fix.patch` | patch3 + repro 一体（线上复现+修复） | 同目录 | 24,262 B / Jul 16 20:57 |
| `encode_cache_miss.patch` | cross_dp DEBUG-ONLY 复现 harness | 同目录 | 4,786 B / Jul 16 |
| `repro_recompute_preempt.patch` | recompute 路径 DEBUG-ONLY 复现 harness | 同目录 | 4,211 B / Jul 24 |
| `方案结论.md` | 初版结论（2026-07-16 20:23） | `D:/xym/落盘/抢占逻辑优化/方案结论.md` | — |
| `修复方案.md` | 整合重写版（2026-07-16 21:34，状态升格"已应用并验证"） | `D:/xym/落盘/抢占逻辑优化/修复方案.md` | ~21 KB / 334 行 |
| `线上crash-多模态encoder适配-方案结论.md` | 最大最新版（2026-07-22 17:10，含 A/C/D/E 缺陷链） | `D:/xym/落盘/抢占逻辑优化/线上crash-多模态encoder适配-方案结论.md` | 63,790 B / Jul 22 |

> 远端副本：`encode_cache_miss_fix.patch-mine.patch` @ `A3_jump_vpn:/sfs_turbo/hw/xym/patch/`。同目录另有未列入上表：`脚本.txt`（3,903 B，复现 runner 脚本）、`offload_adapt.rar`（offload-adapt 压缩归档）、`tmp/`（4 个工作 patch）。offload-adapt 为**独立后续 workstream**（`offload_adapt/`，M0–M13，Jul 25–30，含 `M5-preempt-fork.patch` / `M6-M7-combined.patch`），与本 crash 链无关，本文档不展开。

### 5.2 源码关键行号速查（干净 HEAD `3a1d3c4f4`；磁盘工作区为 HEAD+未提交改动，行号偏移见 §1，括注为磁盘 dirty 行号）

| 位置 | 说明 |
|---|---|
| `vllm/v1/worker/gpu_model_runner.py:2779` | **崩点** `assert encoder_output is not None`（`.get` 在 `:2778`；该文件干净/dirty 一致；落盘文档多误记 `:2780`，本文件纠正 `:2779`） |
| `:503` | `self.encoder_cache: dict[str, torch.Tensor] = {}`（worker 进程局部） |
| `:2566-2717` | `_execute_mm_encoder`（写 `encoder_cache[mm_hash]`） |
| `:2719-2826` | `_gather_mm_embeddings`（取 `encoder_cache[mm_hash]`） |
| `:2523-2564` | `_batch_mm_inputs_from_scheduler`（整片消费 `scheduled_encoder_inputs`，无 cp_rank 去重） |
| `vllm/v1/core/sched/cross_dp_scheduler.py:901` | buggy running loop encoder TODO 占位（磁盘 dirty `:927-929`） |
| `:1108` | buggy waiting loop encoder 注释占位（dirty `:1234-1236`） |
| `:785` | buggy `_preempt_request`（仅 super + kv_transfer_params=None；dirty `:807-809`） |
| `:1432` | buggy SchedulerOutput 用全局 `encoder_cache_manager.get_freed_mm_hashes()`（dirty `:1577`） |
| patch3 post-image `~:838` | `_preempt_request` 修复目标（free KV + ORDER free encoder + num_computed=0 + cp_ranks=[] + 切 waiting）——patch3 后才有，非当前 HEAD |
| `:1201-1202` | `kv_consumer and PREEMPTED → specify_dp=True`（降级触发；dirty `:1253-1254`） |
| `:117-128` | `select_dp` specify_dp 单 rank 分支 |
| `:108` | fresh-long → 16-rank 分支 |
| `:1245` | `request.cp_ranks = selected_dp`（降级固化；dirty `:1390`） |
| `:1223` | "It's a short req" logger（07-21 全为被抢降级长请求，非真短请求；dirty `:1368`） |
| `vllm/v1/core/sched/scheduler.py:208-212` | 单一 `encoder_cache_manager` 创建（根因 B 源） |
| `:966-986` | 基类 `_preempt_request` |
| `:1125-1286` | `_try_schedule_encoder_inputs`（patch3 加 `encoder_cache_manager` 入参；当前 HEAD 无此入参→桥接未落地） |
| `:423` / `:695` | 基类 running/waiting loop 调 `_try_schedule_encoder_inputs`（被 CrossDP 重写后不触达；dirty `:428`/`:708`） |
| `vllm/v1/core/encoder_cache_manager.py:91-117` | `check_and_update_cache`（hit 判定 + 加引用） |
| `:119-178` | `can_allocate`（容量 + 挤兑 evict） |
| `:242-266` | `free` / `get_freed_mm_hashes` |
| `vllm/v1/core/cross_dp_kv_cache_manager.py:425` | `allocate_slots` `raise ValueError` 条件 `num_new_tokens==0 and num_external==0`（async 路径不触发） |
| `vllm-ascend/vllm_ascend/worker/pcp_utils.py:371-372` | **Ascend CP 崩点** `assert encoder_output is not None`（`gather_mm_embeddings_for_pcp` 内） |
| `:421-488` | `maybe_localize_scheduler_output_for_mm_preprocess`（save/restore `free_encoder_mm_hashes`，`:451`/`:484-486`） |
| `vllm-ascend/vllm_ascend/worker/model_runner_v1.py:1070` | `common_pcp_size <= 1` 时 `super()` 短路 |
| `:1073-1075` / `:1088` | `get_local_schedule_layout()` None 时 super，否则派发 `pcp_manager.gather_mm_embeddings_for_pcp` |
| `:1452` | `maybe_get_ec_connector_output`（ECConnector recv 侧；**save 侧 `maybe_save_ec_to_connector` 全仓未实现**） |
| `vllm-ascend/vllm_ascend/ops/fused_moe/comm_utils.py:32` | **OOM 崩点** MoE a2a `new_empty`（缺陷 C，patch3 未覆盖） |