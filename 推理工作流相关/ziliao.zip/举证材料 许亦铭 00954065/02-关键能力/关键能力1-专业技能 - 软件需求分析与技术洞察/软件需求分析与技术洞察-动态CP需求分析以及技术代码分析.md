# DyCP（动态 Context Parallel）代码处理路径分析

## 需求背景与业务价值

本人围绕大模型推理长短序列混合场景，参与动态上下文并行（DyCP）方案设计、需求讨论及上线维护，承担多模态抢占相关模块的问题分析与开发工作。本项工作以客户对长上下文处理能力、混合负载服务效率和多模态业务连续性的要求为出发点，将业务诉求转化为请求调度、资源管理、状态一致性及异常恢复等软件需求，并通过代码路径分析、缺陷复现和修复方案设计，建立业务需求与模块实现之间的对应关系。

### 一 需求背景与客户使用场景

随着大模型应用向更复杂的文本与图文任务发展，客户对长上下文推理的需求持续增强。长文档理解、长对话处理及图文信息分析等典型场景，要求推理服务在接收较大规模输入的同时，持续、稳定地生成结果。客户关注的不仅是模型能够接收的最大输入长度，还包括请求能否及时开始响应、生成过程是否流畅，以及高负载下服务是否能够持续运行。

实际业务请求具有明显的长度差异。同一服务中可能同时存在64K长序列和不足1K的短序列，不同请求的KV缓存规模、计算开销和资源占用时间存在显著差别。长请求需要足够的计算与存储资源，短请求则对额外调度和通信开销更为敏感。因此，推理框架需要在统一资源池中兼顾长请求处理效率与短请求响应体验，避免个别长请求造成局部资源拥塞，影响整体服务能力。

在PD分离部署及多模态输入场景下，请求还需要经历跨节点KV传输、图片编码、缓存读取及多个执行rank之间的协同。当资源不足触发抢占时，请求可能重新进入等待队列，并被调度至其他rank。对客户而言，抢占属于框架内部资源管理行为，不应造成图片信息丢失、请求异常中断或服务崩溃。因此，支持抢占后的正确恢复，是多模态业务稳定运行的必要条件。

### 二 现有处理方式的不足与改进必要性

固定DP策略将请求分配至独立执行域。长短请求混合时，部分执行域可能集中承担长请求，其KV访问和计算压力较高，而其他执行域仍有空闲资源。这种不均衡使整体资源利用受到局部瓶颈制约，难以充分发挥已有计算资源的处理能力。

统一CP策略能够通过多个执行域协同分担长请求处理开销，但短请求也会承担跨rank通信、序列切分及相关处理成本。当短请求自身计算量较小时，附加开销可能抵消并行收益。因此，单一固定策略难以同时满足长请求加速和短请求低开销处理的要求，需要根据请求特征灵活选择执行方式。

多模态抢占问题进一步暴露出资源管理方面的需求缺口：worker的encoder缓存属于进程本地资源，而调度侧全局缓存记录无法准确表示各rank的实际缓存状态。若请求迁移后仍依据其他rank的缓存命中结果进行判断，新rank可能缺少图片embedding，导致执行失败。这表明，动态调度不仅要考虑负载分配，还必须保证任务派发、缓存归属与请求恢复的一致性。

### 三 核心软件需求与适用边界

**1. 按请求特征选择并行方式。** 长短序列应依据可配置阈值判定，短请求采用单执行域DP处理，长请求利用多个执行域进行CP协同。阈值需要结合模型、业务请求分布和运行环境确定；后文出现的具体阈值属于分析场景配置，不作为所有客户场景的统一标准。

**2. 支持混合负载下的资源协调。** 同一批次中的长短请求应使用各自对应的调度、KV访问和计算路径。执行域选择需要考虑可用预算与请求分布，在提高长请求处理效率的同时，控制对短请求的额外影响，并在资源不足时保持请求级处理一致性。

**3. 保证多模态输入处理正确。** 请求实际运行的各rank必须具备所需的encoder结果。调度侧应按rank检查缓存可用性，向缺少结果的目标rank派发必要的encoder任务，不能以其他rank命中缓存替代本地可用性判断。

**4. 支持抢占及异常后的可恢复执行。** 抢占处理应覆盖KV释放、encoder引用回收、计算进度重置和执行域变更。资源释放应在原rank归属仍有效时完成；部分rank预算不足或分配失败时，应暂缓整请求并清理本轮分配产生的引用，避免状态不一致和资源残留。

**5. 保持PD异步传输与结果一致性。** 远端KV未就绪时，应保留正常等待状态，在就绪后继续调度，避免新增处理分支阻断请求推进。多个rank协同处理同一请求时，应保证局部计算结果正确合并、采样状态一致，并最终向上层返回一份有效输出。

### 四 业务价值与交付目标

**提升长上下文业务承载能力。** DyCP通过在需要时为长请求分配多个执行域，支持长上下文任务与日常短请求共同运行。其价值目标是使服务能够适应请求长度变化，为客户使用长输入、复杂上下文等能力提供推理侧支撑。

**改善计算资源利用与整体服务效率。** 根据请求特征选择DP或CP，有助于缓解固定DP下的局部负载集中，并减少短请求承担的不必要通信开销。目标是在既定资源条件下提高有效处理能力，为吞吐提升和资源配置优化提供依据，降低单纯依靠增加资源缓解局部瓶颈的需求。

**兼顾长短请求的响应体验。** 长请求的优化重点包括生成阶段逐token时延，短请求的优化重点包括控制附加开销和排队影响。因此，方案价值需要通过混合负载下长短请求各自的时延与整体吞吐共同评估，确保长请求获得改善的同时，短请求仍满足业务要求。

**保障多模态服务连续性。** 按rank管理encoder缓存并完善抢占恢复，旨在消除请求迁移后缺少图片embedding的故障路径，降低由内部资源调度引发的请求中断风险，使多模态输入在资源竞争和长时间运行条件下仍能得到正确处理。该项能力是DyCP由性能方案走向稳定交付的重要基础。

**提高维护效率与交付可验证性。** 明确请求状态、缓存归属、资源释放顺序和失败回退条件，有助于缩小异常排查范围，减少对偶发日志和单一路径验证的依赖。将需求对应到模块、用例和观测指标，也为版本回归、部署检查和后续维护建立一致的判断依据。

### 五 需求到实现与验收的对应关系

围绕“请求进入、执行域选择、KV准备、混合批次执行、结果回传、抢占恢复”的完整流程，将需求分解为可实现、可观察和可验证的模块要求。


| 需求及价值目标                   | 模块设计要求                                         | 验收关注点                                                   | 本文技术依据                        |
| -------------------------------- | ---------------------------------------------------- | ------------------------------------------------------------ | ----------------------------------- |
| 长短请求混合处理，兼顾效率与响应 | 可配置长短阈值，按请求选择DP或CP，合理分配执行域预算 | 同等资源和负载下比较吞吐、TTFT、TPOT；分别观察长短请求表现   | 第3节调度核心、第7节端到端流程      |
| 长请求跨rank协同，保证输出正确   | KV分片、局部结果合并与采样状态保持一致               | 对照既定正确性标准验证输出，检查跨rank状态及单份回传         | 第4至第6节运行时、Attention与KV传输 |
| 多模态请求迁移后仍可执行         | 按实际rank管理encoder缓存并派发任务                  | 抢占后切换rank，确认新rank执行encoder且可读取embedding       | 第8节缺陷根因与修复方案             |
| 资源不足时保持可恢复状态         | 在清空rank归属前释放资源，失败分配时回收引用         | 覆盖部分rank预算不足、分配失败及重复抢占，检查引用与恢复状态 | 第8节补丁与缺口分析                 |
| PD传输与计算衔接正常             | 区分异步KV等待与真实计算，保护正常状态转换           | 带图请求等待KV后能够继续推进，无异常分支提前阻断             | 第6节KV传输、第8.7节异步守卫        |
| 满足稳定交付与持续维护要求       | 明确部署配置、验证范围及调试代码清理要求             | 真实PD双节点验证、正常多模态回归及长稳运行记录               | 第10节风险与验证要求                |

性能验收需固定模型、资源规模、请求分布、并发、请求速率及输出长度，避免将配置差异或输出截断误判为收益。TTFT用于观察首token响应时间，TPOT用于观察生成阶段逐token耗时，并结合吞吐、失败请求及异常记录评价整体效果。具体指标门槛以客户需求或版本验收要求为准。

### 六 本人承担的需求分析工作与方案意见

本人从客户混合负载和多模态连续运行需求出发，梳理正常执行与抢占恢复用例，并将性能、正确性和可靠性要求对应到调度及缓存管理模块。在方案讨论与问题分析中，重点提出四方面完善意见：一是以长短请求混合场景评价并行策略，兼顾整体吞吐和分类请求时延；二是使encoder缓存账本与worker本地缓存作用域一致；三是将抢占恢复作为包含资源释放和执行域变更的完整流程设计；四是统一处理多rank分配失败，并保护PD异步KV等待路径。

针对实际暴露的encoder cache miss问题，通过分析调度器、调度输出和模型执行器之间的调用关系，将“客户请求不能因抢占而异常中断”的业务要求，细化为按rank派发encoder任务、按归属回收缓存引用和正确处理异步状态等实现约束，并据此形成修复方案与验证要求。该过程体现了从业务诉求识别、需求分解到代码实现分析和验收设计的衔接。

本节所述性能改善与业务价值为需求及验收目标；具体收益、修复有效性和交付结论以实际验证记录为依据。本文记录的patch3仍需完成第10.5节所列真实PD双节点验证，相关待验证事项纳入交付前检查。

---

## 技术分析范围与引用说明

## 1. 概述

DyCP（动态 Context Parallel）是 vLLM 在 PD 分离部署下的一种调度策略：**长序列**请求被切分到同一 domain 内的所有 CP ranks 上并行计算（`cp_size = cp_world_size > 1`），**短序列**请求则落到单 rank 上以 DP 方式运行（`cp_size = 1`）。长短判定由 `long_request_threshold` 阈值控制——在本场景中设为 100，即 prefill tokens ≥ 100 的请求走 CP 多路切分，< 100 的走单路 DP（vllm/v1/core/sched/request_queue.py:235-238）。

PD 分离部署拓扑如下：

- **Prefill 引擎（kv_producer）**：`dp=2, tp=8`，两节点中的 P 节点。负责长序列的 CP prefill 切分（`prefill_dycp_size = dycp_size`），计算完成后通过 Mooncake 将 KV 传输给 decode 侧（vllm_ascend/worker/model_runner_v1.py:317-320）。
- **Decode 引擎（kv_consumer）**：`dp=32, tp=1`，两节点中的 D 节点。`dp_per_domain=16` → 每 domain 16 个 rank 构成一个 `CrossDPScheduler`（共 2 个 domain），`cp_world_size=16`。decode 侧将 KV cache 按 DyCP rank 分片存储（vllm_ascend/worker/pcp_utils.py:92-97）。

该实现对应两个参考 PR（功能映射，见第 9 节归属表与访问说明）：

- **PR #44967**（vllm 上游）：引入 `CrossDPScheduler`、`LongShortRequestQueue`、`dp_per_domain`、`cp_kv_cache_interleave_size`、dycp/pcp/dcp 进程组、`CrossDPKVCacheManager` 等调度与并行态基础。
- **PR #10225**（vllm-ascend）：将 Ascend NPU 栈（CP attention、ACL graph、Mooncake KV transfer、PCPManager）适配到 DyCP 框架，新增 `dycp_sampling` 确定性采样与 `num_dycp_reqs` graph key。

两个 PR 配套：#10225 消费 #44967 提供的调度器/并行态原语（`get_dycp_group`/`dp_per_domain`/`prefill_dycp_size`/`num_dycp_reqs`/`cp_kv_cache_interleave_size` 以及 `CrossDPScheduler` 输出的 `scheduler_output.num_cp_request`）。

## 2. 启动配置对比（dycp vs baseline）

### 2.1 关键发现：磁盘上文件名与内容互换

经 `grep`/`md5sum`（shell 直接按文件名读取，**权威**）核实，磁盘上两个主脚本文件名与其实际配置角色**反转**。注意：通过文件路径 Read 两个中文近名文件时存在内容串档现象（Read `dycp脚本.txt` 实际返回了 `baseline脚本.txt` 的内容），故一切判断以 shell grep/md5 为准：


| 磁盘文件名             | md5                                         | 实际内容                                                                                                                                                                                                |
| :--------------------- | :------------------------------------------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `tmp/dycp脚本.txt`     | `5ca4785a1f63019fd8d5406e5c753b1b`          | **Baseline / KV-offload** 配置（`MultiConnector` + `RecomputeCPUOffloadConnector`，`recompute_scheduler_enable:true`，无 `--long-request-threshold`，日志 `log_decode_baseline_${NODE_RANK}.log`） |
| `tmp/baseline脚本.txt` | `f8481f25524aafc186a02728af808386`          | **DyCP** 配置（单一 `MooncakeConnectorV1`，`--long-request-threshold 100`，注释掉的 `VLLM_REPRO_MM_PREEMPT`，日志 `log_decode_${NODE_RANK}.log`）                                                   |
| `tmp/开KV卸载脚本.txt` | (3903B，与`dycp脚本.txt` 同尺寸同内容角色) | **Baseline / KV-offload** 配置（"开KV卸载"即启用 CPU KV offload，与 `dycp脚本.txt` 磁盘内容一致）                                                                                                    |

> 操作 hazard：任何部署/自动化若按"文件名=角色"执行，会把 baseline 配置当作 DyCP 启动（反之亦然）。下表按**实际配置角色**列出差异，文件引用使用实际磁盘路径。

### 2.2 差异 flag 对照表


| Flag / 字段                              | Baseline 配置（磁盘`dycp脚本.txt` / `开KV卸载脚本.txt`）                                                                                                                                                                                      | DyCP 配置（磁盘`baseline脚本.txt`）                                                              | 含义与代码引用                                                                                                                                                                                                                                                                                                                                                                                        |
| :--------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------------------------------------------------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `recompute_scheduler_enable`             | `true`（:78）                                                                                                                                                                                                                                   | **缺失**（:81 仅有 `multistream_overlap_shared_expert:true`）                                   | Baseline 经`platform.py:476-480` 把 `scheduler_config` 换成 `RecomputeSchedulerConfig`、选 `RecomputeScheduler`（recompute_scheduler.py:78 起为 `class RecomputeSchedulerConfig(SchedulerConfig)`，`scheduler_cls` 字段在 :79-95；`class RecomputeScheduler(Scheduler)` 在 :118）。DyCP 因 `dp_per_domain>1` 硬编码走 `CrossDPScheduler`（vllm/v1/engine/core.py:136-140），该 swap 无效。 |
| `--long-request-threshold`               | **缺失**（默认 1024，vllm/config/scheduler.py:153）                                                                                                                                                                                             | `100`（:85）                                                                                     | DyCP 长短判定阈值。prefill tokens ≥100 → long → 全 CP rank 切分；<100 → short → 单 rank（vllm/v1/core/sched/cross_dp_scheduler.py:245，request_queue.py:235-238）。Baseline 不跑`CrossDPScheduler`，此 flag 无意义。                                                                                                                                                                             |
| `--num-cp-seqs`                          | 缺失                                                                                                                                                                                                                                            | 缺失（**须在 common.sh/部署环境确认**，见 §3.2、§10.2）                                        | `num_cp_seqs` 默认 0 → `max_long_requests=0`；但实测 2780 崩溃发生在 `cp_ranks=[4]` 的长请求上 → 部署环境实际 `num_cp_seqs>0`。                                                                                                                                                                                                                                                                |
| 顶层`kv_connector`                       | `MultiConnector`（:84）→ 被 `AscendMultiConnector` 覆盖（kv_transfer/**init**.py:22-27）                                                                                                                                                     | `MooncakeConnectorV1`（:88）→ `MooncakeConnector`（**init**.py:30，mooncake_connector.py:812） | Baseline 用复合连接器（Mooncake + CPU offload）；DyCP 仅 P→D 单一 Mooncake 传输。                                                                                                                                                                                                                                                                                                                    |
| `RecomputeCPUOffloadConnector` 子连接器 | 存在（:111）：`cpu_bytes_to_use_per_rank=4294967296`（4GB，:114）、`enable_offload_prefix_caching:false`（:115）；脚本写名 `RecomputeCPUOffloadConnector`，实际类为 `RecomputeCPUOffloadConnectorV1`（recompute_cpu_offload_connector.py:43） | 不存在                                                                                           | Baseline 的 CPU KV offload 抢占恢复（recompute_cpu_offload_connector.py:43-82；manager.py:88-165）。DyCP 丢弃，抢占后 KV 需从 P 节点重拉或重算。                                                                                                                                                                                                                                                      |
| `use_layerwise`                          | `false`（:88）                                                                                                                                                                                                                                  | 缺失                                                                                             | 仅`AscendStoreConnector` 消费（ascend_store_connector.py:75,81），对两个实际子连接器均无效。                                                                                                                                                                                                                                                                                                         |
| `VLLM_REPRO_MM_PREEMPT`                  | 缺失                                                                                                                                                                                                                                            | 注释：`# export VLLM_REPRO_MM_PREEMPT=1`（:13-14）                                               | 强制抢占复现工具钩子（recompute_scheduler.py:257 镜像 cross_dp_scheduler 的复现逻辑）。当前未激活（被注释）。                                                                                                                                                                                                                                                                                         |
| `DATA_PARALLEL_HEAD_ADDRESS`             | `33.182.141.223`（:27）                                                                                                                                                                                                                         | `333.182.141.223`（:30，`333` 非合法 IPv4 octet，疑似笔误）                                     | DP head node IP，纯环境差异。                                                                                                                                                                                                                                                                                                                                                                         |
| 日志文件                                 | `log_decode_baseline_${NODE_RANK}.log`                                                                                                                                                                                                          | `log_decode_${NODE_RANK}.log`                                                                    | 文件名角色的强信号——印证互换。                                                                                                                                                                                                                                                                                                                                                                      |
| JSON 结构                                | `connectors[]` 数组（:87-119）                                                                                                                                                                                                                 | 扁平顶层 Mooncake 字段（:87-107）                                                                | `MultiConnector` 需 `connectors` 数组；单连接器内联字段。                                                                                                                                                                                                                                                                                                                                          |

**两脚本相同项**（非差异）：`DATA_PARALLEL_SIZE=32`、`TENSOR_PARALLEL_SIZE=1`、`DATA_PARALLEL_SIZE_LOCAL=16`、`--max-num-seqs 18`、`--max-model-len 262144`、`--max-num-batched-tokens 8192`、`--block-size 128`、`--gpu-memory-utilization 0.90`、`--no-enable-prefix-caching`、`--enable-expert-parallel`、`--quantization ascend`、`--tool-call-parser kimi_k2`、`--compilation-config`、`--distributed-executor-backend mp`、`--cp-kv-cache-interleave-size 128`、`--port 8200`、`kv_role:kv_consumer`、`kv_port:20002`、`kv_parallel_size:2`、`kv_rank:1`、`use_ascend_direct:true`、Mooncake `prefill{dp2,tp8}`/`decode{dp32,tp1}`。

**差异含义简述**：DyCP 配置通过移除 `recompute_scheduler_enable` 与 CPU offload 子连接器、引入 `--long-request-threshold 100`，将调度路径从 `RecomputeScheduler` + CPU KV 保留的抢占恢复模型，切换为 `CrossDPScheduler` 的 DP/CP rank 负载均衡 + 纯 Mooncake KV 传输路径。DyCP 以更低的内存开销和更简单的连接器栈，换取了"无 CPU KV 保留"的代价——被抢占请求的 GPU KV 除非从 P 节点重拉，否则丢失。

## 3. 调度核心路径（vllm）

### 3.1 CrossDPScheduler 选型与实例化

调度器选型入口在 `vllm/v1/engine/core.py:136-140`：

```python
if vllm_config.parallel_config.dp_per_domain > 1:
    from vllm.v1.core.sched.cross_dp_scheduler import CrossDPScheduler, AsyncCrossDPScheduler
    Scheduler = AsyncCrossDPScheduler if self.vllm_config.scheduler_config.async_scheduling else CrossDPScheduler
else:
    Scheduler = vllm_config.scheduler_config.get_scheduler_cls()

```

即 **`dp_per_domain > 1` 时硬编码使用 `CrossDPScheduler`**，绕过 `get_scheduler_cls()`，不论 `scheduler_cls` 配了什么。`CrossDPScheduler` 继承自基类 `Scheduler`（cross_dp_scheduler.py:58,207），实例化在 engine/core.py:155-162。

### 3.2 cp_world_size 与初始化

`CrossDPScheduler.__init__`（cross_dp_scheduler.py:207-284）关键设置：

- `cp_world_size = parallel_config.dp_per_domain`（:228）——**DyCP 复用 DP-per-domain 组作为 CP 组**。
- KV cache manager 替换为 `CrossDPKVCacheManager`，传入 `cp_world_size`（:231-241）。
- `max_cp_tokens = scheduler_config.num_cp_seqs`（:242），`graph_size_for_cp = num_cp_seqs`（:243），断言 `max_cp_tokens >= graph_size_for_cp`（:244）。
- `long_request_threshold = scheduler_config.long_request_threshold`（:245）。
- `waiting = LongShortRequestQueue(threshold, max_long_requests=max_cp_tokens)`（:247-250）。
- `RequestManager(cp_world_size, ...)` 维护 `num_req_per_dp[rank]`、`num_long_req_per_domain`、`req_id_to_ranks`（:251-255）。

**`num_cp_seqs` 陷阱（须上线前确认）**：`num_cp_seqs` 默认 0（vllm/config/scheduler.py:149）→ `max_long_requests=0` → `LongShortRequestQueue.pop_request` 在 `running_long_count(0) >= max_long_requests(0)` 恒真时**跳过所有 long 请求**（request_queue.py:263-265）。两个本地脚本与本地不存在的 `common.sh`（脚本 `source ../../common.sh`，本仓库内未提供）均未见显式 `--num-cp-seqs`。但是——**实测 2780 崩溃正是发生在被抢占的 `cp_ranks=[4]` 长请求上**（见 §8.3），证明部署环境 long 请求确实在调度（即 `num_cp_seqs>0`，应由部署 `common.sh` 或环境注入）。结论：代码默认值有"long 全被跳过"的退化语义，**必须在部署 common.sh 显式设置 `--num-cp-seqs>0`**，并回归确认。

### 3.3 LongShortRequestQueue 长短判定

`vllm/v1/core/sched/request_queue.py:201-368` 定义长短期请求队列。

**`is_long_request`（:235-238）：**

```python
num_prefill_tokens = request.num_tokens - request.num_output_tokens
return num_prefill_tokens >= self.long_request_threshold

```

即 **prefill tokens（不含 output）≥ threshold 即为 long**。T=100 时，N≥100 → long，N<100 → short。

**`pop_request`（:244-273）**：线性扫描，遇到 long 且 `running_long_count >= max_long_requests` 或 `not has_slot_for_long_request` 时跳过继续找；short 直接弹出。`peek_request`（:293-321）逻辑相同但全部被堵时返回 `None`。

### 3.4 schedule() 预算数学

`cross_dp_scheduler.py:811-870` 中 `schedule()` 的预算核心：

**rank_budgets（:843-847）——按 kv_role 区分：**

```python
kv_role = getattr(self.vllm_config.kv_transfer_config, "kv_role", None)
if kv_role == 'kv_producer':
    rank_budgets = [self.max_num_scheduled_tokens // self.cp_world_size] * self.cp_world_size
else:
    rank_budgets = [self.max_num_scheduled_tokens] * self.cp_world_size

```

- **Producer（P 节点）**：每卡预算 = `max_num_scheduled_tokens // cp_world_size`（均分）。
- **Consumer（D 节点）**：每卡预算 = `max_num_scheduled_tokens`（满额）。

**`_get_effective_budget`（:849-860）：**

- 无 `cp_ranks`：long 且 `not specify_dp` → `min(rank_budgets) * cp_world_size`（CP 摊还）；否则（short 或 long+specify_dp）→ `max(rank_budgets)`（单卡）。
- 给定 `cp_ranks`：`cp_size > 1` → `min(rank_budgets[r] for r in cp_ranks) * cp_size`；`cp_size == 1` → `rank_budgets[cp_ranks[0]]`。

**`_deduct_budget`（:862-867）：**

```python
cp_size = len(cp_ranks)
per_rank_cost = (num_tokens + cp_size - 1) // cp_size   # ceil(num_tokens/cp_size)
for r in cp_ranks: rank_budgets[r] -= per_rank_cost

```

每个参与 rank 扣 `ceil(num_tokens/cp_size)`；long（cp_size=cp_world_size）每卡只扣 1/cp_size，short（cp_size=1）全扣单卡。

### 3.5 候选 rank 选择 / cp_size 设置

`RequestManager.select_dp`（cross_dp_scheduler.py:91-114）是 placement 核心：

```python
def select_dp(self, request, is_long, specify_dp, num_new_tokens, rank_budgets):
    if len(request.cp_ranks) > 0:                      # 已有 cp_ranks (running 续跑)
        if self._has_capacity(request.cp_ranks) and all(rank_budgets[r] >= num_new_tokens for r in request.cp_ranks):
            return request.cp_ranks
        return None
    if is_long and not specify_dp:                     # long 且未指定 DP
        if not self._has_capacity(list(range(self.cp_world_size))):
            return None
        return [i for i in range(self.cp_world_size)]  # 全部 ranks
    # short (或 long+specify_dp): 选预算最多、请求数最少的单 rank
    candidates = [rank for rank in range(self.cp_world_size)
                  if self.num_req_per_dp[rank] < self.max_num_seqs
                  and rank_budgets[rank] >= num_new_tokens]
    if not candidates: return None
    return [max(candidates, key=lambda rank: (rank_budgets[rank], -self.num_req_per_dp[rank]))]

```

在 waiting 循环中调用后（:1351-1357）：

- `request.cp_ranks = selected_dp`（:1390）
- **`req_id_to_cp_size[request.request_id] = len(selected_dp)`**（:1392）——long 得 `cp_size=cp_world_size>1`，short 得 `cp_size=1`。
- 每个 rank 记 `cp_rank_to_req_id[dp_rank].append(req_id)`（:1394-1395）。

**特例**：`kv_consumer` 且 `status==PREEMPTED` 时 `specify_dp=True`（:1253-1254/1337-1338），即便 long 也走单 rank DP 分支；但 offload-adapt M6 反转（:1263-1266/1346-1349）：若 connector 持有该被抢占请求的 CPU 状态，则 `specify_dp=False` → 全 CP 宽度 re-CP。

### 3.6 抢占与 re-spread

抢占触发在 running 循环 `allocate_slots` 内层 `while True`（:967-1116）。当 `allocate_slots` 返回 None：

1. 倒序扫 `self.running`（:1001-1010），取最新的非自身 running 请求，`self.running.pop(i)`。
2. `request_manager.free_req(preempted_req)` + `_unmark_long_running` + 刷新 `has_slot_for_long_request`（:1016-1018）。
3. offload-adapt M5 fork（:1020-1106）：非 producer 且 connector 有 `update_state_before_preempt` 钩子时，在 `_preempt_request` **之前**按 `preempted_req.cp_ranks` 逐 rank 镜像 KV 到 CPU（all-or-nothing，失败则 `discard_preempt_state` 回滚）。
4. `self._preempt_request(preempted_req, scheduled_timestamp)`（:1107）——本地实现（:807-809）仅 `super()._preempt_request(...)` + `request.kv_transfer_params = None`。
5. **`preempted_req.prev_cp_ranks = preempted_req.cp_ranks; preempted_req.cp_ranks = []`**（:1111-1112）——清空 cp_ranks，使下次 `select_dp` 走"无 cp_ranks"分支重选。

**re-spread**：被抢占请求重新进 waiting，下次 schedule 的 waiting 循环中 `status==PREEMPTED`：

- 正常 `kv_consumer` PREEMPTED → `specify_dp=True` → 单 rank DP，**可能落到与原先不同的 rank**。
- offload-adapt M6：若 connector 持有 CPU 状态 → `specify_dp=False` → 全 CP 宽度 re-CP。
- 在 :1452-1459 按 `rank in request.prev_cp_ranks` 区分 `scheduled_resumed_reqs`（同 rank）vs `scheduled_new_reqs`（新 rank）。

**关键断言**（:1504）：`total_scheduled <= max_num_running_reqs * cp_world_size`——调度器侧的 rank-slot 约束。（memory 中"2780 assert"昵称指上游 vllm `gpu_model_runner.py:2779` 的 `assert encoder_output is not None`，见 §8；这里是调度器侧的另一约束，仅昵称相近。）

### 3.7 Encoder 调度（磁盘版本：schedule() 内完全未实现）

**当前磁盘代码：`CrossDPScheduler.schedule()` 完全没有实现 encoder inputs 调度。** 基类 `Scheduler`（vllm/v1/core/sched/scheduler.py）的 `_try_schedule_encoder_inputs`/`_free_encoder_inputs` 等方法仍然存在，但 `CrossDPScheduler` 重写了 `schedule()` 后**从不调用它们**——这是根因 A 的关键（见 §8.2）。

- `encoder_compute_budget = self.max_num_encoder_input_tokens` 在 :871 设置，但**从不被消费/递减**。
- `scheduled_encoder_inputs: dict = {}`（:870）始终为空，原样塞进 `SchedulerOutput`（:1569）。
- waiting 循环中 `_try_schedule_encoder_inputs` 的调用被注释掉（:1234-1236），上方有 TODO（:927-929）：`"Encoder inputs scheduling is not implemented yet."`
- running 循环同样 TODO（:927-929），无 encoder 调用。
- 对比基类 `scheduler.py:419-553`（running）与 `667-848`（waiting）：基类两个循环都调 `_try_schedule_encoder_inputs`。`CrossDPScheduler` 重写 `schedule()` 后这套机制全丢。

`encoder_cache_manager.free(request)` 仅出现在 `_free_request`（:384，finish/abort 正常释放路径），抢占走 `_preempt_request` 不走 `_free_request`，**preempt 时不 free encoder cache**。

这是导致多模态抢占 encoder-cache-miss 崩溃的根因 A——详见第 8 节。

### 3.8 load_kv_async 守卫

waiting 循环 :1238-1241——远程 KV 异步加载时 `num_new_tokens=0`；后续 `allocate_slots(..., delay_cache_blocks=load_kv_async)`（:1379）；加载请求在 :1426-1437 被 `add_req` 计数、`prepend` 回 waiting 头、置 `WAITING_FOR_REMOTE_KVS` 跳过。`build_connector_meta` 在 :1591-1599 对每个 scheduler_output 调用一次。

### 3.9 调试残留

`cross_dp_scheduler.py` 残留大量调试输出（详见 §10.1）：

- `logger.info("-------------------------new schedule [cross dp scheduler]---------------------")`（:823）
- **`flagg = 1`（:824）及强制抢占（:968-971）**——最危险的调试残留。
- 各处 `logger.info`（:968, :979, :982, :985, :1366, :1368）。
- `request_queue.py:262`：裸 `print(f"running_long_count: ...")`。
- `cross_dp_scheduler.py:1`：`from ast import Set`（误导入，未使用）。

## 4. Worker / 运行时落地（vllm-ascend）

### 4.1 CP 组拓扑与 PD 角色绑定

`model_runner_v1.py:308-360` 将三种 CP 风格统一到一个 `cp_world_size`：

```
dycp_size = parallel_config.dp_per_domain            # DyCP 复用 DP-per-domain 组
dycp_rank = get_dycp_group().rank_in_group
cp_world_size = dycp_size; cp_rank = dycp_rank       # (model_runner_v1.py:313-316)

dcp_size/dcp_rank  ← get_dcp_group()                 # decode-context-parallel (:309-310)
pcp_size/pcp_rank  ← get_pcp_group()                 # 静态 prefill-context-parallel (:311-312)

common_pcp_size = prefill_dycp_size if prefill_dycp_size > 1 else pcp_size   # (:336-337)

```

**PD 特化（:317-323）：** `dycp_size > 1 and kv_role == 'kv_producer'` 时 `prefill_dycp_size = dycp_size`（producer 将 prefill 切分到所有 DyCP rank）；否则（consumer 或非 PD）`prefill_dycp_size = 1`——**consumer 不在 DyCP rank 间切分 prefill**，只参与 decode CP。

由此推导：

- `use_prefill_cp = pcp_size > 1 or prefill_dycp_size > 1`（:462）
- `use_cp = common_pcp_size * dcp_size * dycp_size > 1`（:458）
- `PCPManager` 仅在乘积 > 1 时构造（:342-358）

### 4.2 PCPManager 与 pcp_utils

`vllm_ascend/worker/pcp_utils.py:56` 的 `PCPManager` 负责 Prefill Context Parallel 的元数据与缓冲区管理。

**DualChunkSwap 策略（:517-811 `update_tokens_for_pcp`）：** 每个 prefill 请求的（padded）序列被切成 `2 * pcp_world_size` 等份，rank `r` 取 chunk `r`（head）+ chunk `2*ws-1-r`（tail），交错分配以平衡负载（:627-649）。per-rank token 数 = `padded // pcp_world_size`（:608），positions 重写为本地 chunk 偏移（model_runner_v1.py:746-755）。

调度器的 per-request `cp_size` 通过 `req_id_to_cp_size` 落实：`num_cp_request = scheduler_output.num_cp_request`（model_runner_v1.py:700-704），`_update_batch_req_cp_sizes`/`build_batch_req_id_to_cp_size`（pcp_utils.py:36-53）将每个请求映射到其 cp_size。`cp_size == 1` 的请求位于 `num_cp_request` 之后，不参与切分。

**CpuGpuBuffers 与 allgather-restore（:863-897 `get_restore_hidden_states`）：**

1. DP（非 CP）token 从尾部切出（:872）。
2. CP token 通过 `get_dycp_group().all_gather`（dycp>1）或 `get_pcp_group().all_gather`（:874-881）跨 CP 组 allgather。
3. 用 `pcp_allgather_restore_idx`（`argsort()` 预计算于 :663-668）通过 `torch.index_select` 恢复原始请求顺序（:882-883）。
4. CP 恢复 + DP 尾部拼接（:884）。

**exit-fa-scatter / unpad：** 混合 attention（qwen3_next）路径（:888-897）用 `pcp_enter_fa_restore_idx`（:760-771）和 `pcp_exit_fa_scatter_idx`（:780-797）。unpad mask（`pcp_unpad_mask_cpu`，:601-607）标记 real vs pad slots。

### 4.3 decode_dycp 特化

`PCPManager.__init__`（pcp_utils.py:91-97）：

```python
if self.dycp_world_size > 1 and kv_role == 'kv_consumer':
    self.decode_dycp_word_size = self.dycp_world_size
    self.decode_dycp_world_rank = self.dycp_world_rank
else:
    self.decode_dycp_word_size = 1
    self.decode_dycp_world_rank = 0

```

**kv_consumer 将 decode KV cache 跨 DyCP rank 分片**，decode 时 per-rank context length 需除以 `decode_dycp_word_size`。在 `generate_pcp_metadata`（def :1085，CP block :1104-1129）中，local seq-len tensor 形状为 `[num_dycp_reqs * decode_threshold, pcp_world_size, dcp_world_size * decode_dycp_word_size]`（:1113），`_get_cp_local_seq_lens`（:1061-1083）以 `decode_dycp_word_size` 作为 dcp 轴分区 `context_lens`。Producer（及非 PD）路径 `decode_dycp_word_size = 1`，decode KV 不跨 DyCP 分片。

### 4.4 cp_size=1 请求的 CP 绕过

两层绕过：

- **DyCP decode/short 请求**从不进入 CP 切分。`num_cp_request` 只计 CP 指定（long-prefill）请求，decode/short-prefill 位于 `>= num_cp_request` 索引。`init_batch_info` 记录 `self.num_dycp_dp_tokens = num_scheduled_tokens[num_dycp_reqs:].sum()`（:210），`update_tokens_for_pcp` 只触及 `num_scheduled_tokens[:num_dycp_reqs]`（:572）。
- **CP 区域内的 decode 请求**（batch 混合 decode + prefill 时，`num_scheduled_tokens == 1 < decode_threshold`）：`update_tokens_for_pcp` 在所有 `pcp_world_size` rank 上**复制**该 token（:582-584），unpad mask 只保留 rank 0 的副本（:604-607），allgather 后只存活一份——等效无 CP 切分，仅冗余计算 + gather（此为机制推断，行为已核验）。

### 4.5 dycp_sampling（跨 rank 确定性采样）

`vllm_ascend/worker/dycp_sampling.py`：`DyCPSampleSeed` NamedTuple（:32-34）+ `make_dycp_sample_seed`（:37-47）使用 **BLAKE2b** 哈希从 `(model_seed, req_id, sample_pos, phase)` 派生 per-(req,pos,phase) 种子，确保所有 CP rank 对同一请求采样出相同 token。`iter_dycp_sample_seeds` 生成迭代器。上下文管理器在 model_runner_v1.py:475-507。

### 4.6 parallel_state 组与环境变量

进程组定义在上游 vllm（vllm-ascend 自身 `parallel_state.py` 仅定义 TP/MoE 子组，不含 dcp/dycp/pcp）：

- `get_dcp_group`（vllm/distributed/parallel_state.py:1224）
- `get_pcp_group`（:1275）
- `get_dycp_group`（:1282）

**唯一相关环境变量**：`VLLM_ASCEND_ENABLE_CONTEXT_PARALLEL`（vllm_ascend/envs.py:93）。无 DYCP/DCP/PCP 专用环境变量。`ascend_forward_context.py:47-73` 将 `num_dycp_reqs`（:66/:73）等传入 forward context。

### 4.7 Encoder cache miss 崩溃点

`PCPManager.gather_mm_embeddings_for_pcp`（pcp_utils.py:371-372）：

```python
encoder_output = encoder_cache.get(mm_hash)
assert encoder_output is not None, f"Encoder cache miss for {mm_hash}."

```

由 `model_runner_v1._gather_mm_embeddings`（model_runner_v1.py:1084-1100，`common_pcp_size > 1` 守卫）调用。memory 中"2780 assert"指上游 vllm `gpu_model_runner.py:2779` 的基类路径 `assert encoder_output is not None, f"Encoder cache miss for {mm_hash}."`，此处是其在 Ascend CP 特化的对应崩点。

`maybe_localize_scheduler_output_for_mm_preprocess`（pcp_utils.py:421-488）将全局 `scheduler_output` 重写为 rank-local，延迟释放仍被活跃请求使用的 mm hash（:478-486），缓解了 free 时序问题，但 per-rank cache 填充在抢占下的缺口仍存在——详见第 8 节。

## 5. CP Attention 计算（vllm-ascend）

Ascend CP attention 实现位于 `vllm_ascend/attention/context_parallel/`，由四个文件组成：


| 文件              | 行数 | 角色                                                                                                                                                                                                                                 |
| :---------------- | :--- | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `common_cp.py`    | 185  | 共享元数据 dataclass（`AscendPCPMetadata` :9-37、`CPChunkedContextMetadata` :40-62 等）+ 跨 rank `(out, LSE)` 合并原语（`_process_attn_out_lse` :99-118、`_npu_update_dycp_attn` :121-155、`_npu_attention_update` :158-184） |
| `attention_cp.py` | 1005 | 标准 MHA/MQA CP attention                                                                                                                                                                                                            |
| `mla_cp.py`       | 1592 | MLA（Multi-Latent Attention）CP                                                                                                                                                                                                      |
| `sfa_cp.py`       | 478  | SFA（Sparse Flash Attention）CP，qwen3-next 类混合模型                                                                                                                                                                               |

后端在注册期由 `enable_cp()` 选 CP impl：`prefill_context_parallel_size>1 or decode_context_parallel_size>1 or dp_per_domain>1`（attention/utils.py:58-62），dispatch 钩子在 attention_v1.py:78-90 / mla_v1.py:79-94 / sfa_v1.py:81-96。**全路径无 ring-attention（无 P2P send/recv KV block）**；唯一的集合通信是 `all_gather`（PCP/DCP/DYCP 组）、`all_to_all_single`（DCP 组）以及 `npu_attention_update(_v2)` kernel——后者把每 rank 的 `(output, LSE)` 对按 online-softmax 合并。

### 5.1 切分模型：DualChunkSwap（Q-split / KV-replicated for prefill；KV-split for decode）

`PCPManager.update_tokens_for_pcp`（pcp_utils.py:517-811）按 **DualChunkSwap** 把每个 prefill 请求的 token 数 pad 到 `2*pcp_world_size` 的倍数（:576-578），切成 `2*pcp_world_size` 等份；rank `r` 取 chunk `r`（head）+ chunk `2*ws-1-r`（tail）（:595-596, 627-649）。per-rank token 数 = `padded // pcp_world_size`（:608）。物理布局 padded：`num_actual_tokens_pcp_padded = total_num_pcp_scheduled_tokens * pcp_world_size`（pcp_utils.py:1100-1101），`pcp_unpad_mask` 标 real vs pad（:601-607），`num_pcp_pads` 记每请求 pad 数（:587）。Decode 请求不切分——token 在所有 PCP rank 上复制，仅 rank 0 副本有效（:582-584, 604-607）。

关键区分（修正一处常见误述）：**prefill-CP 是 Q-split / KV-replicated，无需跨 rank 输出归约**；**decode-CP 是 KV-split，需跨 rank `(out, LSE)` 合并**。

### 5.2 标准 CP attention（attention_cp.py）

- **`AscendAttentionCPImpl.forward_impl`（:886-1005）** 是对外入口（文件内无独立 `def forward`）。
  - **Decode（`has_decode`, :903-909）** → `_forward_decode_pcp_dcp`（:527-603）：Q 在 `dcp_size>1` 时经 `get_dcp_group().all_gather`（:532）；KV 本地读，`actual_seq_lengths_kv = num_computed_tokens_of_pcp_dcp[:, pcp_rank, dcp_rank]`（:550-552，由 pcp_utils.py:1061-1083、1112-1149 构造的 `[bs, pcp_size, dcp_size]` 切分）；跨 rank `(out, LSE)` 经 `_process_attn_out_lse` + `_npu_attention_update` 合并（:601-602）。`dcp_size==1 and pcp_size==1` 时集合通信被跳过（common_cp.py:107,114）、合并退化为单元素——decode 在有无 CP 下行为一致。
  - **Prefill-CP（`has_prefill`, :910-1004）**：CP 头/尾路径由 `self.pcp_size > 1` 选（:940）。KV 在 `reshape_and_cache` 中 `all_kv = get_pcp_group().all_gather(cat([key,value]))` 后 `index_select(all_kv, 0, pcp_allgather_restore_idx)` 恢复全序（:768-773）；本地 head/tail Q 由 `q_head_idx`/`q_tail_idx` 选（:463-471），head/tail 各跑一次 attention，`_forward_prefill_cp_post` 用 `q_full_idx` **拼接+重排**（:514-520, 980-984）——**head/tail 是不相交 token 切片，拼接即足，无需 LSE 合并**。hybrid（qwen3_next）路径经 `pcp_enter_fa_restore_idx` 恢复 fused QKV（:816-828），FA-exit 用 `pcp_exit_fa_scatter_idx` 重排 allgather 后的 prefill 输出（:998-1000）。`pcp_size==1`（仅 DCP）走 plain `npu_fused_infer_attention_score`（:946-962）。

### 5.3 MLA CP attention（mla_cp.py）

- **`AscendMlaCPImpl`（:307，继承 `AscendMLAImpl`）**。MLA 有 absorb 阶段（`q_a_proj`→latent `q_c`；`kv_a_proj_with_mqa`→`kv_no_split=[kv_c, k_pe]`）与 restore 阶段（`q_proj`/`kv_b_proj`→`q_nope`/`k_nope`/`value`、RoPE、attention、`v_up_proj`+`o_proj`）。
  - **absorb 在 CP 切分之前运行、其输出跨 rank 复制**：`q_c`、`kv_no_split` 由 `_mla_preprocess`（:689-718）在每 rank 产出。CP 切分施加在吸收后的 latent：`prefill_q_c = q_c[num_decode_tokens:num_actual_tokens]`，`num_actual_tokens = (num_actual_tokens_pcp_padded - common_pcp_size*num_decode_tokens)//common_pcp_size + num_decode_tokens`（:802-805）——**Q-latent 切分，KV-latent 复制**。
  - **absorbed KV 跨 CP 组 allgather+restore**：`get_dycp_group().all_gather(prefill_kv_c_k_pe, 0)`（:826）或 `get_pcp_group().all_gather(...)`（:828，DyCP vs 静态 PCP），再 `kv_b_proj` 物化全 `k_nope`/`value`（:844-848）。
  - **qk-rope 位置**：`q_pe` rope 在 `mla_preprocess_prefill`（:811），`k_pe` 在 :819-821；decode 中 `decode_q_pe` rope（:859），`exec_kv_decode` 把 rope 烤进 cache 写（mla_v1.py:1167-1193）。RoPE 在 CP 切分**之后**对本地 Q slice 施加（Q 局部），在 KV allgather-restore **之后**对全 KV 施加（KV 全局）。
  - **输出归约**：**prefill-CP 无跨 rank 输出归约**（Q-split/KV-replicated，每 rank 输出即其 Q slice 的 attention 结果，`v_up_proj`→`o_proj` 写本地 slice；全序列 hidden-state 还原在模型层 `PCPManager.get_restore_hidden_states`，pcp_utils.py:863-897）。**decode-CP** 每 rank 持不同 KV slice，算出 partial `(out, LSE)`，经 `_npu_update_dycp_attn`（:1161-1168，DYCP 路径）或 `_process_attn_out_lse`+`_npu_attention_update`（:1171-1172，PCP 路径）合并后再 `v_up_proj`。
  - **CP vs DP 分流**（forward :665-671）：DYCP 请求走 CP 路径，DP 请求走 `dp_metadata`（`pcp_metadata=None`，:1466）。prefill CP 路径门控为 `self.common_pcp_size > 1 and num_dycp_reqs > 0`（:799, 894），`common_pcp_size = dycp_size if (dycp_size>1 and kv_producer) else pcp_size`（:104, 359），`prefill_dycp_size > 1` 决定走 DYCP 还是静态 PCP 组（:352-358）。

### 5.4 SFA CP attention（sfa_cp.py）

- **`AscendSFACPImpl`（:139，继承 `AscendSFAImpl`）** 用 **allgather-KV**（paged-block 级，非 ring）模式。`gather_kv_cross_cp`（:303-316）沿 block dim 0 先 DCP 后 PCP allgather KV cache（:308-311），`block_table` 偏移 `block_arange * block_num` 指向拼接后的 block pool（:312-315）；prefill 与 decode 都调用（:191-192, 354）。
  - **无跨 rank LSE 归约**（KV 复制，每 rank 对全 KV 算本地 Q slice，输出自洽）。head/tail 各跑一次 SFA（`_execute_sparse_flash_attention_process` :182-257，:228-250），用 rank-specific `head/tail_attn_nomask_seqlens`（:227, 240，:126-127 构造），`q_full_idx` 拼接重排（:253），`_align_to_graph_bucket_tokens`（:259-280）仅零填充到 graph bucket。
  - indexer 路径 `indexer_select_post_process`（:318-412）/`_get_full_kv`（:471-478）对 `key`/`kv` 跨 PCP allgather（:354, 476）供 `npu_lightning_indexer` top-k。`exec_kv`（:443-469）跨 PCP allgather 吸收后 `kv_c_k_pe` 并经 `pcp_allgather_restore_idx` restore（:462-463）再写 paged cache。`pcp_size==1` decode 短路回父类（:194-198, 356-359, 472）。注意：`sfa_cp.py:36` 注明 **sfa pcp prefill 不支持 mlapo**。

### 5.5 跨 rank `(out, LSE)` 合并原语（common_cp.py）

- **`_process_attn_out_lse`（:99-118）**：decode 跨 rank 合并原语。`[out, lse]` 末维拼接（:106）→ permute 到 `[H, D+1, S]` → DCP 组 `all_to_all_single`（:109-112，把 head 维换到 batch 维）→ PCP 组 `all_gather`（:116），得 `[PCP*S, DCP*H, D+1]`。
- **`_npu_update_dycp_attn`（:121-155）**：DYCP 变体——DYCP 组 `all_gather` `[out,lse]`（:137）→ reshape `[dycp_size, S, H, D+1]`（:140）→ `npu_attention_update_v2`（:150）合并 `dycp_size` 个 partial。
- **`_npu_attention_update`（:158-184）**：PCP/DCP decode 终步——reshape→permute `[PCP, DCP, S, H, D+1]`（:168-172）→ unbind 成 N=pcp\*dcp 个 rank 列表 → `npu_attention_update`（:182）合并，输出 `[-1, H, D]`。在线 softmax 公式 `LSE_final = logsumexp(LSE_i); O_final = Σ exp(LSE_i − LSE_final) · O_i`（attention_cp.py:606-613 纯 torch 等价实现）。

### 5.6 统一模式 / dispatch 总结

1. **Q 切分 vs KV 复制**：prefill-CP Q-split（DualChunkSwap head/tail）/ KV-replicated（allgather+restore），无跨 rank 输出归约；decode-CP KV-split（interleaved）+ 跨 rank `(out,LSE)` 经 `npu_attention_update` 合并。SFA 例外：decode 也 allgather KV，故无需合并。
2. **集合通信**：仅 `all_gather`（PCP/DCP/DYCP）、`all_to_all_single`（DCP）、`npu_attention_update(_v2)` 合并 kernel。无 ring、无 attention 内 `reduce_scatter`。
3. **MLA-absorb vs SFA**：MLA 在压缩 latent 空间操作后 allgather 吸收 KV（split 点在 absorb 与 restore 之间）；SFA 直接 allgather paged KV（block 级）后 index_select restore。
4. **Dispatch**：`enable_cp()`（utils.py:58-62）选后端；`attention_cp.forward_impl`（:886）decode (:903-909) / prefill-CP 门控 `pcp_size>1`（:940）；MLA 门控 `common_pcp_size>1 and num_dycp_reqs>0`（:799,894）。`_build_attn_state`（model_runner_v1.py:1112-1141）分类 DecodeOnly/SpecDecoding/ChunkedPrefill，`with_prefill`（:692-693）控制 PCP re-split 是否运行。

### 5.7 TODO / 未完成 / stubbed 分支（上线关注）

- `mla_cp.py:686-687`：`return output_padded` 后跟不可达 `return output`（dead code）。
- `mla_cp.py:766-768`、`attention_cp.py:297`、`mla_cp.py:520`：`# FIXME: temporary hack … update args for each layer's attention op in the graph` —— graph 捕获/回放 token 数不匹配的启发式补丁。
- `mla_cp.py:1462-1465`：DP 分支复用 DYCP `chunked_context` 且 `pcp_metadata=None` —— **DP split 元数据部分 stub**，DP 分支不进 CP 特化 prefill 路径。
- `sfa_cp.py:36`：**sfa pcp prefill 不支持 mlapo**（`enable_mlapo` 被读但 CP prefill 路径绕过）。
- `pcp_utils.py:1332-1341`：长序列 nomask 切 16k chunk 是 `_npu_ring_mla` 算子 perf workaround（`# of the _npu_ring_mla operator are not proportional, so we split …`），rank0 与其他 rank 走不同分支，较脆弱。
- `attention_cp.py:157-160, 167-168`：chunked-context KV inverse/recover 索引在仅 DCP 时 stub 为 `None`，`_update_chunk_attn_out_lse_with_current_attn_out_lse`（:627-635）对仅 DCP 被跳过。

## 6. KV 传输 / PD 分离 handoff

### 6.1 连接器类与注册

`MooncakeConnectorV1` 是注册的连接器名（vllm_ascend/distributed/kv_transfer/**init**.py:30），绑定到模块 `vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_connector`，类 **`MooncakeConnector`**（mooncake_connector.py:812）。

> 注意：两个脚本均设 `kv_connector_module_path: "vllm_ascend.distributed.mooncake_connector"`，但该路径不存在（`distributed/` 下无此文件）。注册路径才是 `kv_p2p` 下的实际模块；配置中的 module path 是残留/被忽略。

`MultiConnector` 在 Ascend 被 `AscendMultiConnector` 覆盖（kv_transfer/**init**.py:22-27, ascend_multi_connector.py:16），将每个 scheduler hook 扇出到两个子连接器并仲裁请求归属。

### 6.2 kv_producer ↔ kv_consumer

`MooncakeConnector` 按 `kv_role` 分派后台线程（mooncake_connector.py:1304-1331）：

- **kv_producer（prefill 引擎, dp=2/tp=8）** → `KVCacheSendingThread`（:1305-1314）。`request_finished`（:1076-1122）延迟释放 prompt KV block，发布 `remote_block_ids[:num_prompt_blocks]`、`remote_engine_id`、`remote_host`、`remote_port`、`remote_pcp_size`、`remote_dcp_size`、`remote_dycp_ranks` 等元数据。不主动 push，等待 consumer 的 `DONE_RECVING` ack（`DONE_RECVING_MSG` 定义于 :64，处理于 :264-265）。
- **kv_consumer（decode 引擎, dp=32/tp=1）** → `KVCacheRecvingThread`（:1316-1331）。`get_num_new_matched_tokens`（:967-1001）返回完整未 prefill 的 prompt 长度；`update_state_after_alloc`（:1003-1029）记录 `local_block_ids`；`start_load_kv`→`_get_kv_split_metadata`（:1364-1651）计算 P→D block/port 映射并执行 `batch_transfer_sync_read`（:544）。

### 6.3 Rank 映射

Prefill/decode 的 dp_size/tp_size 从 `kv_connector_extra_config.prefill`/`decode` 读取（:1220-1238）。`pd_tp_ratio = prefill_tp // decode_tp` 在 ascend_config.py:92-99 计算（此处 8/1=8）。

- P↔D 握手端口：`kv_port + data_parallel_rank * tp * pp * pcp`（:1180-1196）。
- DyCP 下：`domain_port_base = kv_port + domain_parallel_rank * tp * pp * dp_per_domain`（:1188-1194）。
- Block→remote-rank 拆分在 `_get_kv_split_metadata`/`get_local_remote_block_port_mappings`（:1450-1501）；head-group CP 映射在 `kv_transfer/utils/utils.py:122-255`（`get_head_group_mapping`）。

Prefill dp2/tp8 + decode dp32/tp1：32 个 decode rank 各自从匹配的 prefill rank 拉取 head/block 分片。

### 6.4 kv_parallel_size / kv_rank

`kv_parallel_size=2, kv_rank=1`（baseline脚本.txt:92,95；dycp脚本.txt:95,97）是 `KVTransferConfig` 字段，表示 2 引擎 KV-transfer 组中的引擎身份（rank 0 = prefill/producer，rank 1 = decode/consumer）。在 V1 `MooncakeConnector` 中**不用于** block/port 计算——映射由 `prefill`/`decode` 尺寸 + `cp_ranks` 驱动（:1364-1651）。

### 6.5 use_ascend_direct / use_layerwise

- **`use_ascend_direct`**：两个脚本 Mooncake 子配置中均设 `true`（baseline脚本.txt:97；dycp脚本.txt:99）。grep 全仓无 `.py` 消费者——穿透/遗留 flag，在当前 `MooncakeConnector` 代码路径中无效。
- **`use_layerwise`**：仅 `AscendStoreConnector` 消费（kv_pool/ascend_store/ascend_store_connector.py:75,81）及其 pool_worker/pool_scheduler。只有 Baseline 设 `false`（dycp脚本.txt:88），但两个实际子连接器均不读——惰性。

### 6.6 cp-kv-cache-interleave-size 128

设置 `parallel_config.cp_kv_cache_interleave_size`。

- **断言**（vllm-ascend/.../platform.py:490-499）：`pcp*dcp > 1` 时 `cp_kv_cache_interleave_size == cache_config.block_size`（此处 block_size=128，满足）。
- **机制**（pcp_utils.py:1061-1083 `_get_cp_local_seq_lens`）：`base = seq_lens // interleave // total_ws * interleave; remainder = clip(remainder - rank*interleave, 0, interleave)`（:1075-1080），按 `(pcp,dcp)` rank 重塑（:1082）。Interleave=128 意味着 CP 以 block 粒度分区 KV cache（每 rank 每次 128-token block 轮转），使传输分片始终为整 block——简化 P→D 传输并与 `block_size` 对齐。

### 6.7 MultiConnector + RecomputeCPUOffload（Baseline）vs 单 Mooncake（DyCP）

**Baseline (`AscendMultiConnector`)** 扇出 hook 到两个子连接器：

- `get_num_new_matched_tokens`（ascend_multi_connector.py:34-54）给予 `RecomputeCPUOffloadConnectorV1` 优先权（其 unhashed partial block 无法被 prefix-cache 连接器恢复）。
- per-rank 扇出 hook（:56-125）支持 CrossDP 下的 offload 子连接器。

**`RecomputeCPUOffloadConnectorV1`**（recompute_cpu_offload_connector.py:43）+ `RecomputeCPUOffloadScheduler`（manager.py:88）提供 **CPU 侧 KV 跨抢占保留**：

- 抢占时 KV block D→H 拷入 per-rank CPU pool（manager.py:355-376）。
- 恢复时 H→D 还原，`get_num_new_matched_tokens` 返回已保存 token 数以跳过重算（:289-323）。
- CPU 预算 `cpu_bytes_to_use_per_rank=4294967296`（4GB），`enable_offload_prefix_caching:false` → 每 block 请求私有。DYCP 下按 `cp_world_size` 分区 per-rank pool（manager.py:126-165）。

**DyCP（单一 MooncakeConnectorV1）** 完全丢弃 offload 子连接器，仅有 P→D Mooncake KV 传输，无 CPU KV 保留。被抢占请求的 GPU KV 除非从 P 节点重拉或重算，否则丢失。

### 6.8 recompute_scheduler_enable 为何在 DyCP 中被丢弃

`recompute_scheduler_enable` 通过 `platform.py:476-480` 将 `scheduler_config` 替换为 `RecomputeSchedulerConfig`（recompute_scheduler.py:78 起），进而选 `RecomputeScheduler`（class :118）。但 DyCP 下 `dp_per_domain > 1` → `engine/core.py:136-140` 硬编码选 `CrossDPScheduler`，此 swap 无效。DyCP 依赖 `CrossDPScheduler` 自身的 DP/CP rank 负载均衡 + 抢占路径 + 纯 Mooncake KV 传输。`RecomputeScheduler.__init__` 的 MLA-spec 注册在 CrossDP 下被显式跳过（manager.py:45-52）。

## 7. 端到端处理流程

### 7.1 ASCII 数据流图

```
                              ┌──────────────────────────────────────────────┐
                              │              API Server (port 8200)           │
                              └──────────────────┬───────────────────────────┘
                                                 │ request
                    ┌────────────────────────────▼────────────────────────────┐
                    │           Prefill Engine (kv_producer)                   │
                    │  dp=2, tp=8,  dp_per_domain>1 → CrossDPScheduler         │
                    │  prefill_dycp_size = dycp_size (全 CP rank 切分 prefill)  │
                    │                                                           │
                    │  long(N≥100): select_dp → [0..cp_world_size-1]           │
                    │    CP token split: per_rank = ceil(N/cp_size)            │
                    │    DualChunkSwap head/tail → CP attention (mla_cp/sfa_cp)│
                    │    K/V allgather → output restore                        │
                    │  short(N<100): select_dp → [single_rank]                 │
                    │    cp_size=1, no CP split                                 │
                    └────────────────────────────┬────────────────────────────┘
                                                 │ KV transfer (Mooncake)
                    ┌────────────────────────────▼────────────────────────────┐
                    │  MooncakeConnector: P→D block/port mapping               │
                    │  remote_block_ids, remote_dycp_ranks, pcp/dcp sizes      │
                    │  cp-kv-cache-interleave-size=128 (block-granular shard)  │
                    └────────────────────────────┬────────────────────────────┘
                                                 │ KV pull (batch_transfer_sync_read)
                    ┌────────────────────────────▼────────────────────────────┐
                    │           Decode Engine (kv_consumer)                     │
                    │  dp=32, tp=1, dp_per_domain=16 → CrossDPScheduler×2      │
                    │  cp_world_size=16, decode_dycp_word_size=16              │
                    │                                                           │
                    │  ┌── load_kv_async: num_new_tokens=0, WAITING_FOR_REMOTE │
                    │  │   _KVS, allocate_slots(delay_cache_blocks=True)       │
                    │  │                                                      │
                    │  ├── KV ready → schedule prefill (token append)          │
                    │  │   long: CP split across 16 ranks                      │
                    │  │   short: single rank DP                               │
                    │  │                                                      │
                    │  ├── decode step: cp_size=1 (no CP split)                │
                    │  │   decode KV sharded across decode_dycp_word_size       │
                    │  │   _get_cp_local_seq_lens partitions context_lens      │
                    │  │                                                      │
                    │  ├── dycp_sampling: BLAKE2b seed per (req,pos,phase)     │
                    │  │   → all CP ranks sample identical tokens              │
                    │  │                                                      │
                    │  └── output → API Server                                 │
                    └─────────────────────────────────────────────────────────┘

```

### 7.2 长多模态请求处理流程

**(a) 长多模态请求（N≥100，含图片）：**

1. **API → Prefill Engine**：请求到达 P 节点（kv_producer, dp=2/tp=8）。
2. **CrossDPScheduler.schedule()**：`is_long_request` 判定 N≥100 → long。`select_dp(is_long=True, specify_dp=False)` 返回 `[0..cp_world_size-1]`，`req_id_to_cp_size[req_id] = cp_world_size > 1`（cross_dp_scheduler.py:91-114, 1392）。
3. **producer 预算**：每 rank 预算 = `max_num_scheduled_tokens // cp_world_size`（:844-845），per-rank 扣 `ceil(N/cp_size)`（:862-867）。
4. **Worker prefill CP**：`model_runner_v1.py` 读 `num_cp_request`（:700-704）。`PCPManager.update_tokens_for_pcp`（pcp_utils.py:517）DualChunkSwap 切分：rank r 取 head[r] + tail[2\*ws-1-r]（:627-649）。
5. **Encoder 计算**：P 节点为该请求跑 `_execute_mm_encoder`，写入 `encoder_cache[mm_hash]`。多模态 feature positions 交集按 rank-local 重写（pcp_utils.py:421-488）。
6. **CP attention**：`mla_cp.py`/`sfa_cp.py`/`attention_cp.py` 对本地 Q slice 计算 attention。prefill-CP 是 **Q-split / KV-replicated**：KV 跨 CP 组 allgather+restore（吸收 KV：mla_cp.py:826-828；原始 KV：attention_cp.py:768-773），各 rank 输出即其 Q slice 结果，head/tail 用 `q_full_idx` 拼接重排（attention_cp.py:514-520），**无需跨 rank 归约**。decode-CP 才是 KV-split + 跨 rank `(out,LSE)` 经 `npu_attention_update` 合并（见 §5.2/§5.5）。
7. **Allgather + restore**：`get_restore_hidden_states`（pcp_utils.py:863-897）跨 CP 组 allgather → `pcp_allgather_restore_idx` index_select 恢复原始顺序 → 拼接 DP 尾部。
8. **KV 传输**：`request_finished` 时 producer 延迟释放 prompt KV block，发布 `remote_block_ids` + `remote_dycp_ranks` 等元数据（mooncake_connector.py:1076-1122）。等 consumer `DONE_RECVING` ack（:64, :264-265）。
9. **Consumer 接收**：D 节点 `KVCacheRecvingThread` 拉取 KV，`_get_kv_split_metadata`（:1364-1651）按 `cp-kv-cache-interleave-size=128` block 粒度映射 P→D。
10. **Decode Engine CrossDPScheduler**：`load_kv_async=True`，`num_new_tokens=0`，`allocate_slots(delay_cache_blocks=True)` → `WAITING_FOR_REMOTE_KVS`（cross_dp_scheduler.py:1238-1241, 1426-1437）。
11. **KV 就绪后 prefill append**：token 追加到 decode 序列。decode 步 `cp_size=1`（CP 绕过），decode KV 跨 `decode_dycp_word_size=16` rank 分片，`_get_cp_local_seq_lens` 分区 context_lens（pcp_utils.py:1104-1129）。
12. **dycp_sampling**：BLAKE2b 派生种子确保跨 rank 确定性采样（dycp_sampling.py:32-47）。
13. **Output → API**。

### 7.3 短请求处理流程

**(b) 短请求（N<100）：**

1. **API → Prefill Engine**：P 节点接收。
2. **CrossDPScheduler.schedule()**：`is_long_request` 判定 N<100 → short。`select_dp(is_long=False)` 走 candidate 分支，返回**预算最大且活跃请求最少**的单 rank（cross_dp_scheduler.py:107-114），`cp_size=1`。
3. **single-rank DP**：无 CP 切分。token 全扣单卡（`per_rank_cost = ceil(N/1) = N`）。
4. **KV 传输**：同长请求，producer 发布 remote 元数据。
5. **Consumer 接收**：同长请求。
6. **Decode**：`cp_size=1`，位于 `num_cp_request` 索引之后，`update_tokens_for_pcp` 不触及（pcp_utils.py:572）。decode 走标准 DP 路径。
7. **Output → API**。

**关键差异**：长请求的 prefill 被 DualChunkSwap 切到全部 16 个 CP rank（每 rank 算 1/16），短请求全在单 rank。decode 阶段两者均为 `cp_size=1`（CP 绕过），但 long 的 decode KV 跨 16 rank 分片（`decode_dycp_word_size=16`），short 的不分片。
