# 交叉DP调度器多模态抢占 Encoder Cache Miss 修复方案

> 落盘时间：2026-07-16
> 代码基线：`D:\xym\Code\ant\0713\vllm`（HEAD `3a1d3c4f4`，PD 分离 / Ascend / Mooncake / kimi-k2.5-w4a8）
> 状态：**线上 crash 已稳定复现并闭环**；修复方案已分析，待落地与验证。

---

## 0. 一句话结论

`CrossDPScheduler` 的多模态 encoder 调度与 cache 记账是**全局共享单例**，但 runner 的 `encoder_cache` 是**每个 GPU worker 进程局部**的 dict。被抢的带图请求换 rank 重排 prefill 时，新 rank 的 runner 从没算过这张图的 encoder，scheduler 又没把它派给新 rank 重算 → `_gather_mm_embeddings` 取 `encoder_cache[mm_hash]` 得到 None → 崩 `gpu_model_runner.py:2780` 的 `assert encoder_output is not None`。

最优修复 = **encoder 账本与派活全部 rank-local 化**（采纳 GPT 修复骨架）+ 追补两个边界缺口 + 在真实 PD 环境双场景验证。

---

## 1. 背景

- 部署：2 节点 × 16 卡 D 节点，`data-parallel-size=32`，`dp-per-domain=16` ⇒ 2 个 domain = 2 个独立 `CrossDPScheduler` 实例，每个 domain = 16 个 DP rank（调度器视角 `cp_world_size=16`）。
- PD 分离：P 节点 `kv_producer`（2DP×8TP），D 节点 `kv_consumer`（32DP×1TP）。
- 动态 CP 特性：长序列走 CP 切分（切 16 路），短序列走 DP 切分（单路）。
- 线上现象：D 节点 running 队列调度中，某 request `allocate_slot` 无法分配 `new_blocks` 时触发抢占，被抢的带图 request 重新走 prefill 时崩在 `gpu_model_runner.py:2769/2780`：
  ```python
  encoder_output = self.encoder_cache.get(mm_hash, None)
  assert encoder_output is not None, f"Encoder cache miss for {mm_hash}."
  ```

---

## 2. 根因

两个根因叠加，都在 buggy 代码（HEAD `3a1d3c4f4`）里：

### 根因 A：CrossDPScheduler 的 running/waiting loop 根本没实现 encoder input 调度

- `cross_dp_scheduler.py:909` running loop：
  ```python
  """
  TODO(AoChen): Encoder inputs scheduling is not implemented yet.
  """
  ```
- `cross_dp_scheduler.py:1169-1171` waiting loop 三行全注释：
  ```python
  # encoder_inputs_to_schedule = None
  # external_load_encoder_input = []
  # new_encoder_compute_budget = encoder_compute_budget
  ```
- 基类 `scheduler.py:_try_schedule_encoder_inputs` 用全局 `self.encoder_cache_manager` 单例。

**后果**：被抢请求重排进 waiting、再被调度为 prefill 时，scheduler **不把它放进任何 rank 的 `scheduled_encoder_inputs`** → 没有哪个 D worker 会为它算 encoder → 它重排落到的那个 rank 的 `encoder_cache` 里没有它的 mm_hash。

### 根因 B：账本全局共享，但 encoder tensor 是 GPU 进程局部的

- `gpu_model_runner.py:2778` `encoder_cache.get(mm_hash)` 是该 worker 进程的本地 dict（`self.encoder_cache: dict[str, Tensor]`，`gpu_model_runner.py:503`）。
- scheduler 侧：
  - `cross_dp_scheduler.py:1453` `scheduled_encoder_inputs=scheduled_encoder_inputs`（单一 dict 喂给全部 16 个 rank 的 SchedulerOutput）
  - `cross_dp_scheduler.py:1461` `free_encoder_mm_hashes=self.encoder_cache_manager.get_freed_mm_hashes()`（单一 manager）
  - 单一 `self.encoder_cache_manager`（基类 `Scheduler.__init__`，`scheduler.py:208-212`）

**后果**：scheduler 的全局记账无法区分"这个 cache hit 是哪个 rank 的 worker 真持有的 tensor"。被抢请求从 rank4 换到 rank3，rank3 的 runner 从没算过这张图，scheduler 全局账本却可能因别处 hit 就不重算 → rank3 上 miss。

**核心矛盾**：encoder tensor 是 GPU 进程局部的，账本却是 scheduler 全局的，跨 rank 抢占重排时记账/派活没对上。

---

## 3. 复现证据（已闭环）

复现方式：手动强制抢占 + 完整日志（见本目录 `reproduce-log-*.txt` 或主线对话记录）。关键帧（单次成功复现）：

| 时刻 | 日志 | 含义 |
|---|---|---|
| 03:24:33.533 | `len(self.running):2 → new_blocks:None → get in premmpt` | running 队列触发抢占 |
| 03:24:33.533 | `[repro] PREEMPTED req_id=...-22-968e7db4 preempted_by=...-30-8d74a230 mm_hashes=['61ef1e3b...'] cp_ranks=[4] prev_num_computed=141 has_encoder_inputs=True` | 队尾带图请求22被抢，已decode到141tok，占rank4 |
| 03:24:33.533之后 | `_preempt_request` 置 `num_computed=0`，重入 waiting，重新 prefill | 释放已算KV，重走prefill |
| 03:24:33.668 | `Worker_Domain0_DP3_EP3 ... AssertionError: Encoder cache miss for 61ef1e3b...` | 崩在 DP3 |

**闭环判定**：崩的 mm_hash `61ef1e3b...` == 被抢请求22的 `mm_hashes[0]`，且请求22被抢时在 rank4、崩在 DP3（换 rank 了）→ 崩的就是被抢请求自身，重排到新 rank 取不到 encoder。与线上描述逐字一致。

> 复现用的手动抢占 / 调试日志为临时代码，见 §7，验证修复后必须还原。

---

## 4. GPT 修复版做了什么（stash@{0}）

核心：**encoder 账本与派活全部 rank-local 化**。对照 buggy：

| Buggy | GPT 修复 | 对应根因 |
|---|---|---|
| 单一 `self.encoder_cache_manager` | `self.encoder_cache_managers = [EncoderCacheManager(...) for _ in range(cp_world_size)]` | B |
| running loop TODO 占位 | 补全：对每个 cp_rank 调 `_try_schedule_encoder_inputs_for_rank`，`allocate` | A |
| waiting loop 注释占位 | 补全：对 `selected_dp` 调 `_try_schedule_encoder_inputs_for_rank`，写 `scheduled_encoder_inputs[rank]` | A（重排路径！消崩的关键） |
| `scheduled_encoder_inputs=...`（全局dict喂全16路） | `scheduled_encoder_inputs=scheduled_encoder_inputs[idx]`（per-rank） | B |
| `free_encoder_mm_hashes=...get_freed_mm_hashes()`（全局） | `free_encoder_mm_hashes=free_encoder_mm_hashes[idx]`（per-rank） | B |
| `_preempt_request` 调 super（全局free） | 本地实现 + `_free_encoder_cache_for_request`（按 `cp_ranks or prev_cp_ranks` 逐rankfree） | B |
| `_try_schedule_encoder_inputs` 硬编码全局mgr | 加 `encoder_cache_manager` 入参，各rank传自己的 | A/B桥接 |
| `_free_encoder_inputs`（全局） | `_free_encoder_inputs_for_rank(request, cp_rank)` | B |
| —（无回退free） | waiting loop 在 `num_new_tokens==0` / `new_blocks is None` 回退时 `for rank in selected_dp: encoder_cache_managers[rank].free(request)` | 探测引用回收（必要补丁） |

新增辅助：
- `_encoder_cache_ranks(request) -> list[int]`：`return request.cp_ranks or request.prev_cp_ranks`
- `_free_encoder_cache_for_request(request)`：对上述每个 rank 调 `encoder_cache_managers[rank].free(request)`
- `_free_encoder_inputs_for_rank(request, rank)`：按 `num_computed_tokens` 判定 decoder KV 是否已接管该 encoder 输入，再丢弃该 rank 的引用
- `_try_schedule_encoder_inputs_for_rank(...)`：转发到基类 `_try_schedule_encoder_inputs`，传该 rank 的 manager
- `reset_encoder_cache()`：逐 rank reset

**对你的 2780 路径有效性**：被抢请求22重排时，对重排落到的 rank3 调 `_try_schedule_encoder_inputs_for_rank(22, 3, ...)`；22 `num_computed_tokens` 被抢时归零、是新 prefill，rank3 的独立账本 `check_and_update_cache` 返回 False → 22 进 rank3 的 `scheduled_encoder_inputs` → DP3 worker 收到 → `_execute_mm_encoder` 算 encoder → `encoder_cache[61ef1e3b...]` 写入 → `_gather_mm_embeddings` 取得到 → **不崩**。

**结论**：GPT 修复方向正确，对复现路径能消崩。

---

## 5. 修复合理性 / 发现的缺口

GPT 修复方向对，但有以下缺口需补：

### 缺口 1（记账顺序约束，必须写死）

`_free_encoder_cache_for_request` 依赖 `request.cp_ranks`（兜底 `prev_cp_ranks`）。预emption 路径执行顺序必须是「先 `_free_encoder_cache_for_request`（此时 `cp_ranks` 还在）→ 再 `cp_ranks=[]`、`prev_cp_ranks=原cp_ranks`」。修复版 `_preempt_request` 自带实现且顺序正确，但**无注释约束**，后人改动易引入泄漏。需写死顺序注释。

### 缺口 2（长序列多rank重排的边界，潜在新崩点）

复现的是短请求（cp_ranks=[4]，单 rank）。线上还有**长序列 CP 切多 rank** 被抢重排的情况。修复版 waiting loop 对 `selected_dp` 逐 rank 算 encoder 并 `allocate`，看似覆盖。

**但**：`encoder_compute_budgets[rank]` 每 rank 独立 = `max_num_encoder_input_tokens`。16 个 rank 各自重算同一张大图 encoder，若某 rank 预算不足 → 该 rank `can_allocate` 返回 False → `num_new_tokens=0` → 该 rank 不算 encoder → 该 rank SchedulerOutput 不含此 mm_hash → **该 rank runner `_gather_mm_embeddings` 仍可能 miss**。

修复版对 `num_new_tokens==0` 是 `break`/跳过该请求整体，短期避开，但被抢长请求可能因此卡住或再次异常。**这个边界要单独验证 + 加 WARN 日志便于线上抓。**

### 缺口 3（ECConnector 联动未 rank-local，当前不触发）

`gpu_model_runner.py:2715` `maybe_save_ec_to_connector(self.encoder_cache, mm_hash)` 与 ECConnector 路径修复版未动 runner 侧。当前用 MooncakeConnector（KV 层）不触发；若以后开 ECConnector（跨节点共享 encoder）需复查。**当前环境不受影响，留备忘。**

### 缺口 4（回退 free 补丁，正确且必要，保留）

修复版在 `num_new_tokens==0` / `new_blocks is None` 回退时 `encoder_cache_managers[rank].free(request)`，因为 `check_and_update_cache` 探测时会加引用。**必须保留**，否则泄漏引用、破坏后续 cache 记账。

---

## 6. 最优修复方案

### 必做（采纳 GPT 修复骨架）
1. per-rank `encoder_cache_managers`，`_free_encoder_cache_for_request` 按 `cp_ranks or prev_cp_ranks` 释放。
2. running loop + waiting loop 双补全 `_try_schedule_encoder_inputs_for_rank`，per-rank 写 `scheduled_encoder_inputs[rank]`。
3. `SchedulerOutput(idx)` 改用 `scheduled_encoder_inputs[idx]` / `free_encoder_mm_hashes[idx]`。
4. `_try_schedule_encoder_inputs` 加 `encoder_cache_manager` 入参。
5. 保留回退路径的 `free` 探测引用补丁（缺口4）。

### 建议追加（覆盖缺口）
6. **缺口2 处理**：waiting loop 里若被抢重排请求对某 rank 因 `encoder_compute_budget`/`can_allocate` 不足导致该 rank 不算 encoder，应**整请求跳过这一帧**（避免部分rank有encoder、部分没有），并打印 `WARN`（含 req_id / rank / mm_hash / 原因）便于线上定位。确认长序列场景严格落实 `break`。
7. **缺口1 强化**：`_preempt_request` 内固定调用顺序「free encoder cache（cp_ranks还在）→ cp_ranks=[]、prev_cp_ranks=原cp_ranks」，写死注释约束。

### 验证（真实 PD 环境双场景）
8. 用 GPT 修复版跑能稳定复现的 bench（§3 强制抢占那套），确认：
   - 被抢请求重排时，新 rank 的 SchedulerOutput 的 `scheduled_encoder_inputs` **包含**它的 input_id；
   - 新 rank worker 日志里 `_execute_mm_encoder` 真算了该 mm_hash；
   - **不再崩 2780**，被抢请求正常完成。
9. 再跑**长序列（CP切多rank）被抢**场景，确认缺口2 不触发（被抢长请求能整请求跳过/正常重算，不崩）。
10. 回归：正常多模态流量（无强制抢占）跑通，确认 per-rank 改造未引入正确性回归。

> 原则：修复要进正式代码前，必须在本双节点 PD 环境跑验证，不只靠静态分析。

---

## 7. 复现用的临时调试代码（验证后必须还原）

当前 `0713/vllm` 工作区有两类改动混在一起，**都不应进正式分支**：

- **GPT 修复**：已 `git stash`（`stash@{0}: GPT-fix encoder cache rank-local (resume repro baseline)`）。
- **复现调试代码**（在 `cross_dp_scheduler.py`）：
  - 手动抢占开关：`with record_function_or_nullcontext("schedule: allocate_slots")` 内 `len(self.running)>1 and flagg==1 and request_num==1` 时强制 `new_blocks=None`；
  - 抢占条件放宽：`if candidate is not request:`（去掉 `any(共享cp_rank)`）；
  - 各处 `logger.info` 打印（`new schedule` / `len(self.running)` / `new_blocks` / `get in premmpt` / `candidate` / `self.running` / `[repro] PREEMPTED ...`）；
  - `import os`（仅为读 env，修复后可去除）。

还原方式（验证修复后）：
```bash
cd D:/xym/Code/ant/0713/vllm
git checkout -- vllm/v1/core/sched/cross_dp_scheduler.py   # 丢弃所有调试改动, 回干净 HEAD
# 然后应用最终修复 patch
git stash pop   # 或重新 apply 修复版, 解决与新调试残留的冲突(保留修复, 删调试)
```

---

## 8. 关键文件 / 行号速查（HEAD `3a1d3c4f4` 基线）

| 位置 | 说明 |
|---|---|
| `vllm/v1/core/sched/cross_dp_scheduler.py:909` | buggy running loop encoder TODO 占位 |
| `:1169-1171` | buggy waiting loop encoder 注释占位 |
| `:1453 / :1461` | buggy SchedulerOutput 用全局 encoder dict / freed hashes |
| `:947-1004` | running loop allocate_slots + 抢占分支（手动抢占注入点） |
| `vllm/v1/core/sched/scheduler.py:208-212` | 单一 `encoder_cache_manager` 创建 |
| `:966-986` | 基类 `_preempt_request`（free encoder + num_computed=0 + 重入waiting） |
| `:1125-1286` | `_try_schedule_encoder_inputs`（修复版加 `encoder_cache_manager` 入参） |
| `vllm/v1/core/encoder_cache_manager.py:91-117` | `check_and_update_cache`（hit 判定+加引用） |
| `:119-178` | `can_allocate`（容量+挤兑 evict 进 freed） |
| `:242-266` | `free` / `get_freed_mm_hashes` |
| `vllm/v1/worker/gpu_model_runner.py:2780` | **崩点** `assert encoder_output is not None` |
| `:2566-2717` | `_execute_mm_encoder`（写 `encoder_cache[mm_hash]`） |
| `:2719-2826` | `_gather_mm_embeddings`（取 `encoder_cache[mm_hash]`） |
| `:2523-2564` | `_batch_mm_inputs_from_scheduler`（遍历 `scheduled_encoder_inputs` 整片消费） |
| `:503` | `self.encoder_cache: dict[str, Tensor] = {}`（worker 进程局部） |

---

## 9. 变更记录

| 日期 | 内容 |
|---|---|
| 2026-07-16 | 初版落盘：根因、复现闭环、GPT 修复分析、缺口、最优方案 |
| 2026-07-16 | 产出两份 patch：`patch1-gpt方案.patch`、`patch2-我的修改方案.patch`，均已在干净 HEAD `3a1d3c4f4` 上 `git apply --check` + 实际 apply + 语法校验通过 |
| 2026-07-16 | **重大更正**：实测发现 GPT 修复（patch1/patch2 共病）在 PD 分离 + 异步 KV 加载路径上有致命缺陷——详见 §11；产出 `patch3`（核心修正 `and not load_kv_async` 守卫） |
| 2026-07-17 | 新增 §12：本地 bench（`input_len=6000`，CP 长请求）触发 NPU MoE all-to-all hang，定位为**独立缺陷 A（CP 通信组撕裂）**，bare HEAD 固有、patch3 未覆盖；与 encoder miss（B）区分建档 |
| 2026-07-17 | §12.0 机理修正：经 vllm-ascend 源码坐实，A 精确机理为"CP decode 抢占致各 rank `num_decode_tokens` 失配 → 全组 all_gather 形状错配 → hang"，非笼统"撕通信组"；CP 通信组为部署期固定全组。新增 §12.0.1（线上触发面/可观测性判据）、§12.7（patch3 对长请求覆盖边界）。结论：patch3 对短请求彻底充分，对长请求 B 覆盖、A 不覆盖；是否需 patch4 取决于线上 A 频率 |
| 2026-07-21 | 本次会话分析（原散于 §13–§22，已整合为单一 §13，子节 §13.1–§13.16）：① **缺陷 C** 多模态长请求抢占重排 OOM（07-20 实测，崩点 `comm_utils.py:32` MoE a2a `new_empty(800MB)`，§13.1–13.2）；② **缺陷 D** 抢占=CP→单 rank 不可逆降级核心机制（code+log 双重坐实，"short req" 实为单 rank 放置非短序列，§13.3–13.4）；③ 干净代码多模态原貌 + patch3 改动边界（`git show HEAD` 复核，patch3 仅改 encoder 记账，CP 切分/降级/重排全未碰，C/D 在干净与 patched 中均存在，§13.5）；④ patch3 定性="让 encoder 骑文本抢占骨架"（正确性适配非优化）+ 修 B 解锁 C（§13.6–13.7）；⑤ 多模态 vs 长文本抢占可复用性（骨架同、encoder 层异；照搬 4 问题：B miss/C OOM 放大/重算浪费/PD 丢 encoder，§13.8）；⑥ **缺陷 E** fresh CP 多模态 encoder 跨 rank 复制（code 坐实，但 PD 配置下 D 不做 prefill 故不触发，§13.9）；⑦ 同尺寸请求 P-D 正常 vs 抢占 OOM 三因素（P-TP8 分布 vs D-TP1 单卡集中 / P 卡干净预算 vs D 卡 KV 饱和 / num_computed=0 切断 P 全量重做，§13.10）；⑧ 三轮日志对照 + OOM 边界判据=正比于降级单 rank 重排 prefill token 数（§13.11）；⑨ 纯文本 256k 抢占 OOM 边界（§13.12）；⑩ C 本质非 encoder 乃"分布式 prefill 退化成单卡饱和重做"+ 与 A/B 关系（§13.13）；⑪ patch4 C/D 治本方向（候选过滤/降级保护/激活预算门控，§13.14）；⑫ encoder 专项方案族 6 个 + 分阶段路径（Phase1 ⑥止血 / Phase2 ③+①治本 / Phase3 ②/⑤/④可选）+ 编码落点（§13.15）；⑬ 关键代码行号速查（§13.16）。对 patch3 结论无修订：per-rank encoder 账本三轮表现正常无 miss |

---

## 11. 重大更正：PD 异步 KV 守卫缺口（patch1/patch2 共病，patch3 修正）

> 这一节是对 §5 缺口分析的重要补充——此前分析（§5）只盯"被抢重排/长序列多rank"，**漏了 PD 分离异步 KV 加载这条最基本路径上的致命缺陷**。实测（2026-07-16，diag 日志铁证）暴露。

### 11.1 实测现象
应用 patch2 后跑 PD 多模态 bench，**所有带图请求首 prefill 全部死循环卡死**（不止被抢重排的），症状：
```
It's a short req, selected_dp:[0], num_new_tokens:0
[diag-pre] nct=0 n_tokens=141 load_kv_async=True nect=140 nnt BEFORE=0
[encoder-sched] skip req ... (mm=True): ... will retry next step.
```
每帧重复，请求永不进 running。

### 11.2 真因（diag 闭环）
带图 PD 请求首 prefill 时 `load_kv_async=True`、`num_new_tokens=0`——这是 KV 异步加载的**正常状态**（KV 还没传完，scheduler 不分配新 prefill token）。但 GPT 修复把 encoder 处理分支插在 waiting loop 里、**在 `load_kv_async` 的 async 分支（置 `WAITING_FOR_REMOTE_KVS` 等 KV）之前**：
```python
if request.has_encoder_inputs:        # ← 不分 load_kv_async，无脑进
    for rank in selected_dp: _try_schedule_encoder_inputs_for_rank(..., num_new_tokens=0)
    if num_new_tokens == 0: free + break   # ← 把请求提前跳出 waiting loop
```
`num_new_tokens=0` 时该分支 `break`，请求永远到不了 async 分支（`if load_kv_async: ... WAITING_FOR_REMOTE_KVS ... continue`），于是 KV 异步加载流程被截断、`num_computed_tokens` 永不推进、死循环。影响**所有**带图 PD 请求。

### 11.3 与 2780 的关系
**此卡死与 2780 修复无关**——它是 GPT 修复引入的设计顺序错误（encoder 分支不该在 async 分支之前对 `load_kv_async=True` 的请求生效）。但它**阻止了 2780 修复的验证**：请求走不到"被抢重排 prefill"，无法观察 2780 是否被消。必须先修此卡死，让带图 PD 请求能正常 prefill+decode，才谈得上验证 2780。

### 11.4 patch3 修正
在 encoder 分支加 `and not load_kv_async` 守卫：
```python
if request.has_encoder_inputs and not load_kv_async:   # ← 只在KV就绪后才调度encoder
    ...
    if num_new_tokens == 0: free + WARN + break
```
- `load_kv_async=True` 时跳过 encoder 分支 → 继续到 `allocate_slots(delay_cache_blocks=True, num_external>0)` 成功 → 进 `if load_kv_async:` async 分支 → `WAITING_FOR_REMOTE_KVS` + `continue`，正常等 KV。
- `num_new_tokens==0` 的 break/WARN 只在 KV 就绪后真做 prefill 时触发（那时 0 才可能是 encoder 容量不足，break 才有意义），文案不再误报。
- 验证依据：`CrossDPKVCacheManager.allocate_slots` L425 的 `raise ValueError` 条件是 `num_new_tokens==0 and num_external==0`，async 分支 `num_external>0`(=nect=140) 不触发；`delay_cache_blocks=True` 走 KV 接收缓冲路径返回非 None。

### 11.5 patch3 = GPT 修复全量 + 缺口1 + 缺口2(治本守卫) + WARN 文案修正
完整基于干净 HEAD `3a1d3c4f4` 生成，含三处相对 GPT 版的增量：
1. 缺口1：`_preempt_request` 顺序约束注释
2. **缺口2 治本**：`and not load_kv_async` 守卫（核心，治 PD 异步 KV 卡死）
3. 缺口2：`[encoder-sched]` WARN 文案修正（仅 KV 就绪后触发）
校验：干净 HEAD `git apply --check` + apply + 语法通过；守卫落地确认。

> **重要**：patch3 是干净 HEAD 的完整版（非 patch2 增量）。应用前必须 `git checkout --` 还原干净基线，不要叠加在 patch1/patch2 之上。手加的 diag 日志也会被一并清除。

---

## 12. 独立缺陷 A：CP 通信组撕裂导致 NPU all-to-all hang（bare HEAD 固有，patch3 未覆盖）

> 本地 bench（2026-07-17，`log_decode_0/1.log`）跑 CP 长请求（`--random-input-len 6000`）+ 调试抢占代码触发，稳定复现 NPU 集群级联崩溃。日志铁证表明这是与 encoder cache miss（B）**独立的另一条缺陷**，本文档单独立项。

### 12.0 机理修正（2026-07-17 vLLM-Ascend 源码坐实）

> 初版 §12 将 A 归因为"preempt 撕裂 DYCP 通信组"。经 `vllm_ascend/attention/context_parallel/attention_cp.py` + `model_runner_v1.py` 源码坐实，精确机理应修正为：**CP decode 阶段抢占导致各 rank 当帧 decode 批大小失配 → 全组 all_gather 形状错配 → hang**，而非笼统的"撕通信组"。

源码证据：
- `_forward_decode_pcp_dcp`（`attention_cp.py:527-533`）每步 decode 只要有 decode 请求就发起 `get_dcp_group().all_gather(query, 1)`，门控 `dcp_size>1`（部署恒真=16），**全组 16 rank 同步参与**。
- `forward_impl`（`attention_cp.py:898,908`）：`has_decode = num_decodes > 0` 即走 CP decode all_gather——**不要求该 decode 请求是 CP 请求**，只要当帧 batch 里有 decode 请求就走。
- all_gather 的 tensor 长度由 `num_decode_tokens`（=各 rank 自己的 decode 批）决定。各 rank decode 批大小若不一致 → all_gather 形状错配 → 某些 rank 发/收长度对不上 → Notify 永久等不到 → 全组 timeout。
- `model_runner_v1.py:926` `num_dycp_reqs = num_cp_request`：CP decode 路径对 batch 内 CP 请求那部分特殊对齐，隐含"各 rank CP decode 请求数需一致"的约束。

**修正后的精确触发条件**：CP 长请求 decode 阶段被丢掉某 rank 上的一个 CP 请求，导致该 rank 当帧 `num_decodes` / `num_decode_tokens` 与其他 rank 失配，全组 all_gather 形状错配 → hang。

**与"撕通信组"说法的区别**：通信组本身是部署期固定的全组（`dcp_size=16` 常驻），preempt 不"拆组"，而是**破坏了当帧各 rank 对 decode 批的形状共识**。修正后机理指向更窄的修复面（见 12.6）。

### 12.0.1 线上触发面与可观测性（关键判据）

- **机理成立**：bare HEAD 下，CP 长请求 decode 被抢若造成跨 rank decode 批失配即触发 A。短请求（cp_size=1）被抢**不**触发 A（不参与 CP 全组 all_gather 对齐）。
- **现地证据不足**：手头仅有本地 bench 日志，且 bench 是复现 patch **必触发**的 manufactured 场景，不能代表线上频次。线上真实长稳日志不可及，`coord.log`（81MB）未排查。
- **已知线上表现**：仅短请求 assert（B）被明确上报；CP 长请求 A 未作为独立现象被识别。两种可能：(a) 线上 CP decode 被抢频率低；(b) 真发生时被归因为"NPU 集群超时/故障"，未联系到调度抢占。
- **结论**：A 是"机理成立 + 线上未明确观测"的**潜在隐患**，而非已证实的线上故障。是否加急修取决于线上 CP 长请求占比与历史 hang 事件复盘。

### 12.1 复现现象

bench：`bench_image.sh`（`--random-input-len 6000 --num-prompts 32 --max-concurrency 32`，全部走 CP 16-rank）+ 调试抢占代码（`flagg` 强制 `new_blocks=None` + 放宽抢占条件）。结果 32 个请求全部成功返回，但服务随后崩溃。

关键日志帧（`log_decode_0.log`）：
- `02:33:50.462` Domain0 `[repro] PREEMPTED req_id=...-24-8c9958e2 cp_ranks=[0..15] prev_num_computed=7310 has_encoder_inputs=True`
- `02:33:50.526` Domain1 同样抢占一个 16-rank、7310-tok CP 请求
- `02:36:09` 集群心跳异常：`33.182.143.182/3`、`33.182.143.54/2/3` 同时 `Stuck Occurred`
- `02:38:51` `Worker_Domain0_DP8` 报 `Communication_Error_Timeout(EI0002): The wait execution of the Notify register times out. Reason: The Notify register has not received the Notify record from remote rank: [0]. ... tag:[ALLTOALLV_group_name_265] ... rankSize:32, blockDim:32` → `AclrtSynchronizeStreamWithTimeout error code 507034` → `Vector core execution timed out` → `aivec error`（芯片级）
- `02:39:31~34` 其余 worker 陆续 `aivec error` 级联
- `02:39:41` `EngineCore_DP1` `RuntimeError: cancelled`（mq 读端取消）；`corrupted size vs. prev_size`
- `02:40:06` `Worker_DP0` `Connection closed by peer [33.182.143.54]:26013`（Gloo all_reduce）

**注意**：被抢请求 `prev_num_computed=7310` 远超 prompt 长度，是 **decode 阶段**被抢，不是 prefill。

### 12.2 根因：preempt 在 decode 中途撕裂 DYCP 通信组

铁证（基于干净 HEAD `3a1d3c4f4`，不带 patch3、不带调试）：

**① preempt 路径只动 KV/账本，零 CP 通信组处理**（`cross_dp_scheduler.py:981-986`）：
```python
self._preempt_request(preempted_req, scheduled_timestamp)  # super(): kv_cache_manager.free + encoder_cache_manager.free + num_computed=0
for rank in preempted_req.cp_ranks:
    preempted_reqs[rank].append(preempted_req)
preempted_req.prev_cp_ranks = preempted_req.cp_ranks
preempted_req.cp_ranks = []      # ← 通信组归属直接抹掉，无 drain/barrier
```

**② `kv_cache_manager.free` 只归还 block，不碰通信**（`cross_dp_kv_cache_manager.py:512`）：
```python
def free(self, request):
    for request_rank in request.cp_ranks:
        for manager in self.cross_dp_single_type_managers[request_rank]:
            manager.free(request_id)   # 纯 block 归还
```

**③ preempt 链路全文 grep `drain/barrier/finalize/cp_group/dycp_group` 零命中**——没有任何对 CP 通信组的同步或延迟释放。

**④ CP 通信组是部署期固定的全组**（`dcp_size=dp_per_domain=16` 常驻，见 §12.0 修正），**不是 per-step 动态组网**。每步 decode 只要 `num_decodes>0` 就对全组发起 `all_gather(query)`，全 16 rank 必须以**一致的 `num_decode_tokens` 形状**参与。

机理时序（已按 §12.0 修正）：
```
NPU 当帧 decode forward：各 rank 按各自 num_decode_tokens 发起全组 all_gather(query)
  ↓ 同一调度步 scheduler 决定 preempt 某 rank 上的 CP 请求：
    kv_cache_manager.free(req)     # CPU 释放 block
    request.cp_ranks = []          # CPU 抹掉通信组归属
    请求回 waiting
  ↓ 该 rank 当帧/下一帧 num_decodes 与其他 rank 失配（被摘的 CP 请求未对齐）
  → 全组 all_gather 形状错配 → 某些 rank 发/收长度对不上 → Notify 永久等不到
  → HCCL all-to-all timeout（默认 1800s，实测 ~2min）→ aivec error → 全集群 Stuck 级联
```

日志 `ALLTOALLV ... not received Notify from remote rank [0]`、`rankSize:32` 正好对应 CP 通信面，逐字吻合。

### 12.3 与 encoder cache miss（B）的关系——两个独立缺陷，A 先于 B 触发并掩盖 B

| 缺陷 | 触发条件 | 表现 | bare HEAD | patch3 |
|---|---|---|---|---|
| **A** CP 通信组撕裂 | **decode 阶段**抢 CP 请求（线上长稳真实主路径，running 队列 decode 占绝对多数，FCFS 抢队尾必是 decode 中的 CP 请求） | NPU hang → 全集群级联崩溃 | 固有 | **未覆盖** |
| **B** encoder cache miss | 被抢重排 prefill 取 `encoder_cache[mm_hash]` → None（短/长请求同链路，长请求 16 rank 任一 miss 即崩） | assert 崩 `gpu_model_runner.py:2779` | 固有 | **已修** |

关键判定：
- 短请求 `cp_size=1`，**无 CP 通信组**，被抢只触发 B 不 hang——这正是线上已闭环复现、本文档 §3 描述的场景（`cp_ranks=[4]` 是单 rank 短请求）。
- CP 长请求 `cp_size=16`，decode 被抢**先触发 A**（NPU hang），根本走不到 B 的 encoder 重排 prefill 路径。所以**线上若 CP 长请求 decode 被抢，会以 A（集群 hang）而非 B（assert）形式表现**，很可能被当成一般性 NPU 故障忽略。

### 12.4 patch3 对 A 无效

patch3 只改 encoder 账本（per-rank `encoder_cache_managers`）与 encoder 派活，`_preempt_request` 仍是同样的 `kv_cache_manager.free` + `cp_ranks=[]`，不碰 CP 通信组生命周期。**打 patch3 后 CP 长请求 decode 被抢仍会 hang。**

### 12.5 本地复现与验证策略

- **复现 A（线上真实长请求问题）**：当前 bench（`input_len=6000`）+ 任意抢占触发即可，已稳定复现。注意被抢的是 decode 阶段 CP 请求。**这是 HEAD 长请求的"可能出现的问题"——不是 encoder miss，是通信组撕裂 hang。**
- **复现 B（长请求 encoder miss，验证 patch3）**：必须绕开 A 才能观察，二选一：
  1. 抢 **prefill 阶段**的 CP 请求（`candidate.num_computed_tokens < candidate.num_prompt_tokens`）；prefill 期 CP 仍有跨 rank 通信，可能偶发 hang，需把 cp_size 调小降通信面。
  2. 或 cp_size 调到 2（最小非 1）：通信面降到最小，encoder miss per-rank 派活语义不变，hang 概率大幅降低——观察 B 最干净的办法。
- 对照验证：bare HEAD + 复现条件 → 应崩 L2779 assert；patch3 + 同条件 → 不崩，且日志显示重排落到的 rank 各自收到 `scheduled_encoder_inputs`、各自算 encoder。

### 12.6 修复方向（A，独立工作量，先立项不急修）

A 是 bare HEAD 固有的 CP decode 抢占形状对齐缺陷，不在 encoder cache 这条修复线上。按 §12.0 修正后的机理，修复面比"通信组生命周期"更窄、更聚焦：

- **方向1（调度侧避抢，最轻）**：preempt 选候选时跳过"decode 阶段的 CP 请求"（`len(cp_ranks)>1 and num_computed_tokens>=num_prompt_tokens`），只允许抢 prefill 阶段 CP 或短请求。不碰 worker/通信。代价：极端 KV 紧张时若无候选可抢可能饿死新请求；prefill 期 CP 仍有全组 all_gather（prefill 路径 `dcp_size>1` 也恒发起），抢 prefill CP 仍有失配风险，需配合方向2。
- **方向2（形状对齐，中职）**：preempt 后**所有 rank 同步丢弃同一批的对应 CP 请求**，保证当帧各 rank `num_decodes`/`num_decode_tokens` 一致。本质是让 preempt 成为"跨 rank 原子操作"——某 rank 决定抢某 CP 请求，广播给组内所有 rank 同步从 batch 摘除。需 scheduler↔worker 或 scheduler 间同步原语。
- **方向3（延迟释放 pending-preempt，重）**：被抢 CP 请求标记 pending，当帧照常参与通信，下一帧 update_from_output 后再真正 free + 摘除。保证当帧形状不变。需引入 pending 状态机 + 多 rank 顺序一致，验证成本高。

> 推荐：先上**方向1 + 日志**止血（patch4 候选），把 A 的真实线上频率探明后再决定是否上方向2/3 治本。

### 12.7 patch3 对长请求的覆盖边界（回应"短请求补丁能否解长请求抢占"）

- **B（encoder miss）**：patch3 对长请求**覆盖**。per-rank encoder 账本 + per-rank 派活对 `cp_size=16` 适用——被抢后 16 rank 各自 free、重排后各自 `_try_schedule_encoder_inputs_for_rank` 重算、各自 `scheduled_encoder_inputs[idx]` 发放。与短请求同构。
- **A（CP decode 抢占 hang）**：patch3 **不覆盖**。`_preempt_request` 仍是 `kv_cache_manager.free + cp_ranks=[]`，无形状对齐/延迟释放。
- **结论**：
  | 长请求被抢场景 | patch3 |
  |---|---|
  | prefill 阶段被抢 → 重排遇 encoder miss | ✅ 修（A 未触发，B 修了） |
  | decode 阶段被抢（线上主路径）→ CP 形状失配 hang | ❌ 修不了，A 先于 B 触发 |
- 短请求 `cp_size=1` 无 CP 全组 all_gather，被抢只 B 不 A，故 patch3 对短请求**彻底充分**；对长请求**部分覆盖**。
- **是否需要 patch4 取决于线上 A 频率**（见 12.0.1）：若线上 CP 长请求占比低、无历史 hang 归因，patch3 对当前已知线上问题（短请求 assert）已充分，A 作为潜在隐患用方向1+日志跟踪即可，暂缓治本。

> 注：调试抢占代码（`encode_cache_miss.patch`）把候选条件从「只抢共享 cp_rank 的请求」放宽到「队尾任意请求」，导致误抢 decode 中的 CP 长请求必触发 A。这是**调试代码配置问题，非 HEAD 新增 bug**——但 A 本身在 bare HEAD 下对真实线上 CP decode 抢占同样成立，只是线上有"共享 cp_rank"过滤、发生更稀疏。

---

## 10. Patch 文件清单与使用说明

两份 patch 均基于干净 HEAD `3a1d3c4f4`（`D:\xym\Code\ant\0713\vllm`，PD 分离 / Ascend / Mooncake 基线），改两个文件：
- `vllm/v1/core/sched/cross_dp_scheduler.py`
- `vllm/v1/core/sched/scheduler.py`

### `patch1-gpt方案.patch`（GPT 修复原样）
- 来源：`git stash@{0}`（"GPT-fix encoder cache rank-local"）原样导出。
- 内容：encoder 账本与派活全部 rank-local 化（§4 全部改动表）。
- 对复现路径有效性：能消掉被抢短请求换 rank 重排的 2780 崩溃。

### `patch2-我的修改方案.patch`（最终推荐）
- = GPT 修复骨架 + 我追补的两个缺口：
  - **缺口1**：`_preempt_request` 内加 `ORDER CONSTRAINT` 注释，写死「free encoder cache（cp_ranks 还在）→ cp_ranks=[]、prev_cp_ranks=原」的调用顺序，防后人改动引入泄漏。
  - **缺口2**：waiting loop 里 `num_new_tokens==0` 因 encoder 预算/cache 不足整请求跳过时，补 `[encoder-sched] WARN` 日志（含 req_id / 是否带图 / selected_dp），便于线上抓"被抢重排请求卡在 encoder 调度"。
- 相对 Patch1 的增量经 diff 验证：**只有缺口1/2 两处**，`scheduler.py` 与 Patch1 完全相同，无意外差异。
- 缺口3（ECConnector 联动）当前环境不触发，未改 runner，留备忘。

> 注：缺口2 的"整请求跳过"逻辑 Patch1 已有（`break` + 回退 free），Patch2 只增可观测性日志，不引入未验证的新调度逻辑——降低风险。

### 校验状态
- 两份 patch 均在干净 HEAD `3a1d3c4f4` 上：`git apply --check` 通过、实际 `git apply` 成功、`python -c "import ast; ast.parse(...)"` 语法校验通过。

### 使用方式（验证时）
```bash
cd D:/xym/Code/ant/0713/vllm

# 0. 先把工作区调试代码还原到干净 HEAD(丢弃手动抢占/日志等)
git checkout -- vllm/v1/core/sched/cross_dp_scheduler.py

# 1. 应用最终方案(Patch2)
git apply "D:/xym/落盘/抢占逻辑优化/patch2-我的修改方案.patch"
# 或若想先验证纯 GPT 方案:
# git apply "D:/xym/落盘/抢占逻辑优化/patch1-gpt方案.patch"

# 2. 跑双节点 PD 环境 + 强制抢占 bench 验证(见 §6 第8-10步)
#    重点: 被抢请求重排时新 rank 的 SchedulerOutput.scheduled_encoder_inputs
#          含该 input_id → 该 worker _execute_mm_encoder 算出 → 不再崩 2780
#    再跑长序列(CP切多rank)被抢场景, 确认缺口2 不触发(或 WARN 可见但不崩)

# 3. 验证通过后正常 commit; 验证不通过回退:
# git checkout -- vllm/v1/core/sched/cross_dp_scheduler.py vllm/v1/core/sched/scheduler.py
```

### 还原主工作区调试代码（验证修复前务必做）
当前 `0713/vllm` 工作区 `cross_dp_scheduler.py` 含复现用的手动抢占/调试日志（§7），不属于任何 patch。应用 patch 前必须先 `git checkout --` 还原到干净 HEAD，否则 patch 会与调试代码冲突。

---



## 13. 多模态长请求抢占重排 OOM（缺陷 C）及相关机制全分析

> 2026-07-21 会话新增。基于 07-20 OOM 实测（72×72 图 / ~7310 prompt / threshold 4096，日志 `vllm-ascend-tools/kimi-k25/dycp/log_decode_0.log` 08:54 那轮，关键帧分析时已抓取落盘；该轮日志后被 07-21 新跑覆盖）、`git show HEAD`（干净基线 `3a1d3c4f4`）代码复核、三轮日志对照，对多模态长请求抢占重排 OOM（缺陷 C）及其相关机制——抢占降级（D）、encoder 跨 rank 复制（E）、patch3 改动边界与定性、P-D vs 抢占对比、patch4 方案——做完整分析。与缺陷 A（CP hang）、B（encoder miss）独立建档。

### 13.1 崩点确认与内存构成
两节点 08:54:27 同报 OOM，崩在同一处：
```
vllm_ascend/ops/fused_moe/comm_utils.py:32  async_all_to_all
    a2a_out = input_.new_empty(...)        # ← NPU out of memory
RuntimeError: NPU out of memory. Tried to allocate 800.00 MiB
(57.27 GiB already allocated / 61.28 GiB total, 仅剩 ~300 MiB)
```
调用链：`execute_model → _model_forward → acl_graph.__call__ → self.runnable(...)`（**eager 回退路径**，非 cudagraph）`→ kimi_k25.forward → deepseek_v2.forward → fused_moe.forward_impl → token_dispatcher.token_combine → async_all_to_all → new_empty`。OOM 帧 forward 的 `SchedulerOutput`（`dump_input.py:79`）证实跑的是单 rank 上一个 **7310-token 带图（72×72，mm_position offset=6 length=1296）prefill**。内存构成：

| 项 | 量级 | 说明 |
|---|---|---|
| LM prefill 激活 | 数 GB（主因） | 7310 token × hidden × bf16 × 层数 + MoE 中间激活，eager 无 cudagraph 静态复用 |
| MoE a2a recv buffer | **800 MB（直接触发点）** | `comm_utils.py:32 new_empty`，按 token×expert×hidden 分配 |
| encoder tensor | ~18 MB/张/卡 | 72×72→1296 embed，零头 |
| KV cache | 已占大头但固定 | 启动即分配，与本次无关 |

### 13.2 根因：抢占降级单 rank 全量重排
被抢请求 `-15`：`prev_num_computed=7310`、`cp_ranks=[0..15]`、`has_encoder_inputs=True`——已 decode 到 7310 的长 CP 带图请求。`_preempt_request` 把 `num_computed=0`、回 waiting → 一个每步只激活 1 token 的 decode 请求**阶跃成一次 7310-token 全量长 prefill**。重排日志证实它以单 rank prefill 重新进调度：
```
It's a cp req selected_dp:[0..15] num_new_tokens:1   # 重排前还在 16 路 CP decode
... preempt ...
It's a short req selected_dp:[0] num_new_tokens:7310  # 降级单 rank 全量重排 prefill
```
崩在重排后那帧的 MoE a2a `new_empty`。降级机制本身见 13.3。

### 13.3 核心机制（缺陷 D）：抢占 = CP→单 rank 不可逆降级
> C 的根因，patch4 设计判据。code + log 双重坐实。

**机制（code）**：`_preempt_request`（`cross_dp_scheduler.py:836-858`）模态无关：`kv_cache_manager.free` + `num_computed=0` + `cp_ranks=[]` + `status=PREEMPTED` + `kv_transfer_params=None`（切断 P）+ 回 waiting。重排 waiting loop（`:1266`）：
```python
if kv_role == 'kv_consumer' and request.status == RequestStatus.PREEMPTED:
    specify_dp = True        # ← 抢占后永久贴上
```
`select_dp`（`:117`）specify_dp 分支返回单 rank → 长请求从 16 路 CP 降级为单 rank。`:1439 request.cp_ranks = selected_dp` 固化，后续永远 `specify_dp=True`、**不可逆回 CP**。

**"short req" 标签实为单 rank 放置（log 坐实）**：日志判定（`:1355`）`if len(selected_dp)>1: "cp req" else: "short req"`——与序列长短无关，只看 rank 数。07-21 新跑实测：cp req 32 条 specify_dp **全 False**；short req 46 条 specify_dp **全 True**（全是被抢降级的长请求，0 条真短请求）。**结论：日志 "short req" 是"单 rank 放置"，非"短序列"。**

### 13.4 干净代码抢占全流程（trigger→候选→free 16 卡→降级单卡重排）
- **触发**（`:945`）：`allocate_slots(request.cp_ranks,...)` 返回 None（某 rank 满）→ 抢占。
- **选候选**（`:958` FCFS）：`for i in range(running-1,-1,-1): if candidate is not request and any(r in request.cp_ranks for r in candidate.cp_ranks): pop`——选**共享 ≥1 cp_rank 的最新请求**，整个请求弹出。
- **`_preempt_request`**（`:785→super`）：`kv_cache_manager.free(request)` + `encoder_cache_manager.free` + `num_computed=0` + `status=PREEMPTED` + `waiting.prepend` + `kv_transfer_params=None`。`CrossDPKVCacheManager.free`（`vllm/v1/core/cross_dp_kv_cache_manager.py`）遍历 `request.cp_ranks`（此时仍 16）逐 rank free——docstring "Free the blocks across all CP ranks" → **16 张卡 KV 全 free**。
- **清空归属**（`:981`，preempt 之后）：`prev_cp_ranks=cp_ranks; cp_ranks=[]`。
- **重排**（下一帧 `:1201`）：`kv_consumer+PREEMPTED → specify_dp=True → select_dp 单 rank → "It's a short req" → num_computed=0 全量 prefill`。
- **校正**：抢占以**整个 CP 请求**为单位（1 个请求同时占 16 卡，非 16 个 per-rank 子请求）；16 卡 shard 随整个请求一起 free，重排非"拼回分片"而是同请求对象归零后在 1 卡从零重算。

### 13.5 干净代码多模态原貌 + patch3 改动边界
> 基于 `git show HEAD:`（HEAD `3a1d3c4f4`）复核，澄清"patch 改了什么 vs 原生有什么"。

**干净代码多模态处理**：
- 长请求判定 `request_queue.py:235`（patch3 未触碰）：`num_prefill_tokens = num_tokens - num_output_tokens ≥ threshold`，总 prefill token（文本+图像 placeholder），无 mm 分支。
- CP 切分 `select_dp`（`:91`）`is_long and not specify_dp → 全 16 rank`；`_get_effective_budget`（`:819`）。**与 patched 逐字一致**——多模态长请求在干净代码即被 CP 切 16 路，与纯文本同逻辑。
- **encoder 调度（干净核心差异 → 缺陷 B 根源）**：running loop `:901 TODO: not implemented`；waiting loop `:1108-1110` 三行全注释；`:845 scheduled_encoder_inputs={}` 永不填充；基类 `scheduler.py:208` 单一全局 `encoder_cache_manager`；SchedulerOutput `:1424` 单一空 dict 喂全 16 rank；`_preempt_request:785→super` + `:362 self.encoder_cache_manager.free`（全局 free）。**后果**：`scheduled_encoder_inputs` 永空 → 无 worker 跑 `_execute_mm_encoder` → `encoder_cache[mm_hash]` 永空 → 需 encoder 时 `_gather_mm_embeddings` 取 None → **assert 2780**（缺陷 B）。
- **抢占降级（缺陷 D，干净原生）**：waiting loop `:1201-1202` `kv_consumer+PREEMPTED → specify_dp=True`——patch3 未引入未改。

**patch3 改动边界（仅 encoder 记账，不碰切分）**：
| 逻辑 | 干净代码 | patch3 改? |
|---|---|---|
| 多模态长请求 → CP 16 路切分 | ✅ | **否** |
| `is_long_request` 阈值判定 | ✅ | **否** |
| 抢占 `specify_dp=True` 降级单 rank | ✅ 原生 | **否**（D 仍在） |
| `_preempt_request` num_computed=0 重排 | ✅ 原生 | **否**（C/D 仍在） |
| encoder 调度派活 | ❌ TODO/注释（B） | **是** ← 修这里 |
| encoder cache 账本 | 单一全局（B） | **是** ← per-rank |
| PD 异步 KV 守卫 | ❌ 缺（§11 卡死) | **是** ← `and not load_kv_async` |

**一句话**：patch3 只补 encoder 这条线（per-rank 账本+派活+异步 KV 守卫），没碰 CP 切分/降级；故 C( OOM)/D(降级) 在干净与 patched 中**都存在**，是 patch4 目标。

### 13.6 patch3 定性：encoder 骑文本骨架（正确性适配，非多模态优化）
纯文本抢占心智模型只有 KV：`preempt: kv_cache_manager.free(按cp_ranks逐rank) → num_computed=0 → 重排单rank全量prefill重算KV`。patch3 让 encoder **完全照搬此模型**，把 encoder 当"另一种 per-rank 状态"：

| 环节 | KV（文本本就如此） | encoder（patch3 镜像 KV） |
|---|---|---|
| preempt free | `kv_cache_manager.free` 遍历 cp_ranks | `_free_encoder_cache_for_request` 按 `cp_ranks or prev_cp_ranks` 逐 rank free |
| 状态归零 | `num_computed=0` | encoder 引用随之释放 |
| rerank 重算 | 降级单 rank 全量 prefill 重算 KV | waiting loop `for rank in selected_dp: _try_schedule_encoder_inputs_for_rank` 落点 rank 派活重算 |
| 跨 rank 一致 | per-rank block free/重算对齐 | per-rank manager free/重算对齐 |

patch3 **未改抢占骨架**，只在 free 与 rerank 两点让 encoder 跟着 KV 走——即"用纯文本抢占方式适配 encoder"。**后果**：一致性达标 → 不 miss（B 修）；但 encoder≠KV，故继承文本骨架的"钝"且被 encoder 放大——重算代价不对等（整图视觉前向 vs 廉价 KV 重算）、降级照搬（D 保留）、单 rank 重排 OOM 放大（C 保留）、PD 丢 encoder 照搬。**patch3 回答"怎么让 encoder 不崩"，patch4 回答"怎么让多模态抢占不贵不 OOM"——递进非替代。**

### 13.7 patch3 解锁 C：修 B 暴露 C
**降级机制干净代码原生（D），patch3 未引入未改**——"16 卡 → 1 卡全量 prefill"路径 patch3 前后都在。**patch3 是"解锁"OOM 的原因**：干净代码下重排 prefill 执行到 `_gather_mm_embeddings` 先崩 `assert 2780`（B，无人派 encoder），**走不到 prefill 激活那步，看不到 OOM**。patch3 修 B → 落点 rank 重算 encoder、重排 prefill **真能执行** → 长 prompt（7310）单卡全量 prefill 激活顶爆 → C OOM。短 prompt（128）单卡重排激活小 → 不 OOM。这是"修一个崩点暴露下一个崩点"的递进。

### 13.8 多模态 vs 长文本：切分处理异同与抢占可复用性
**切分处理骨架相同，仅 encoder 层不同**——调度骨架（长请求判定/CP 16 路分配/每帧 token 预算/抢占/重排降级）在两种模态是同一套代码，无 `if has_encoder_inputs` 分支：

| 环节 | 代码 | 文本 vs 多模态 |
|---|---|---|
| 长请求判定 | `request_queue.py:235` | 同 |
| CP 16 路分配 | `select_dp is_long and not specify_dp` | 同 |
| 每帧 token 预算 | `_get_effective_budget` | 同 |
| 抢占 | `_preempt_request:785→super` + `kv_cache_manager.free` 遍历 cp_ranks | 同 |
| 重排降级 | `kv_consumer+PREEMPTED → specify_dp=True → 单 rank` | 同 |

唯一差异：**encoder 层**。文本只有 KV 状态；多模态 = KV + encoder 输出（视觉 tower 整图前向结果，**按 mm_hash 存于每 rank worker 进程局部的 `encoder_cache` dict**），独立于 CP 切分存在。

**能否复用长文本抢占逻辑？骨架可复用，原样照搬必崩**。长文本抢占 = `free KV → num_computed=0 → 重排 prefill`，对文本足够（重排只重算 KV，无额外状态）。照搬多模态 4 个问题：
1. **encoder 状态 per-rank GPU 局部，重排换 rank 即 miss（缺陷 B 根因）**：preempt 清全局账本引用，但 `encoder_cache[mm_hash]` 张量在每 rank worker GPU 进程局部；重排落单 rank 从未算过该图；干净代码 loop 不实现 encoder 调度 → `scheduled_encoder_inputs` 永空 → 无人重算 → **assert 2780 崩**。文本无此层故不崩；patch3 核心即补这层。
2. **encoder 重算 = 完整视觉前向，代价远高于文本重排**：文本重排重算 KV（廉价）；多模态每次过一遍整图视觉 tower（72×72→5184 patch→1296 embed，数十层 ViT），不被 CP 摊薄。07-21 日志 46~59 次抢占 = 46~59 次整图重算。
3. **单 rank 重排吞"整图 encoder + 全量 prefill"，OOM 放大（缺陷 C）**：长文本降级单 rank 仅全量文本 prefill（无额外前向）；多模态同 rank 同时做全量文本 prefill + 完整整图 encoder + MoE a2a buffer，三者叠加。07-20（7310+72×72）→ OOM；纯文本同长度不 OOM。多模态 OOM 阈值远低于文本。
4. **PD 分离下切断 kv_transfer_params = 丢 P 算好的 encoder**：`_preempt_request` 置 None 切断 P；P 本是做 prefill+encoder 处。D 须自重算整图——回到问题 2/3。文本无此概念。

复用代价小结：
| 缺陷 | 照搬长文本逻辑 | patch3 后 | 多模态特有? |
|---|---|---|---|
| B encoder miss | **必崩** | ✅ 修 | 是 |
| C 单 rank 重排 OOM | 放大(+整图 encoder) | ❌ 未修 | 部分(文本同长度不 OOM) |
| D 降级不可逆 | 同 | ❌ 未修 | 否 |
| A CP decode hang | 同 | ❌ 未修 | 否 |
| encoder 重算浪费 | 每次抢占重算整图 | ❌ 未修 | 是 |

**结论**：长文本抢占骨架可/应复用（patch3 即骨架复用 + encoder 补丁）；"原样复用"对多模态不成立——须额外处理 encoder 的 per-rank 局部性与重算（patch3 治 B），重算本身又引入多模态独有 OOM/代价（C + 重算浪费，patch4 才能治）。

### 13.9 多模态 vs 纯文本 CP 下处理差异（三层）+ encoder 跨 rank 复制（缺陷 E）
**三层差异（code 坐实）**：
| 层 | 文本 | 图像 | 证据 |
|---|---|---|---|
| ① 长请求判定（threshold） | 计入总 token | 计入总 token，**同逻辑** | `request_queue.py:235` |
| ② LM/attention CP 切分 | 真正摊薄 1/16 | 图像 embed 区占连续段，落到覆盖该段的若干 rank | `attention_cp.py` `local_context_lens_allranks`（推断，非逐行坐实） |
| ③ 视觉 encoder 前向 | 无 | **不被 CP 摊薄，跨 selected_dp rank 复制** | 见下缺陷 E |

**缺陷 E：fresh CP 多模态 encoder 跨 rank 复制（多模态独有，code 坐实，但 PD 配置下不触发）**
机制：fresh 长 CP 请求 waiting loop（`:1373`）/ running loop（`:985`）`for rank in selected_dp`（fresh=16）调 `_try_schedule_encoder_inputs_for_rank`；该包装层（`:298`）仅换 `encoder_cache_managers[rank]`，overlap 判定（`scheduler.py:1163`）**完全请求级，无 rank 本地段收窄**；`check_and_update_cache`（`encoder_cache_manager.py:107`）miss 返回 False 且不登记 → 16 个独立 per-rank manager 首次全 miss → 16 rank `scheduled_encoder_inputs[rank]` 全填同一张图 → SchedulerOutput per-rank（`:1631`）→ 16 worker 各自 `_execute_mm_encoder`（`gpu_model_runner.py:2543`，无 cp_rank 去重）跑整图。**一张图 → encoder 跑最多 16 遍、存 16 份。**

适用边界（关键）：
| 路径 | specify_dp | selected_dp | encoder 倍数 | prefill 摊薄 |
|---|---|---|---|---|
| fresh CP prefill | False | 16 | **16× 复制**（E 触发面） | 文本摊薄 1/16 |
| preempted 降级重排 | True | 1 | 1× | **不摊薄，单 rank 全量**（C 触发面） |
| decode | — | — | 0×（image 已算） | — |
| **PD 分离 D 节点 fresh**（P 已 prefill） | False | 16 | **0×**（D 做 CP decode，num_new_tokens=0/1，不做 prefill 不跑 encoder） | — |

**PD 配置下"fresh CP 16× encoder"不触发**：D 收 P 传来的 KV 只做 CP decode（07-21 新跑 cp req num_new_tokens 全 0/1 证实）。encoder 只在抢占降级后单 rank 重排跑 1×。这是 07-21 两轮 0 OOM 主因之一。**与纯文本的内存分水岭**：纯文本 prefill 激活被 CP 等分摊薄到每 rank ~1/16，无额度外的整图前向；多模态视觉 encoder 整图、跨 rank 复制、不随 CP 摊薄——这是多模态拿不到纯文本 CP 收益的结构性原因。E 在 fresh-CP-prefill 路径（非 PD）会放大 encoder 内存/算力最多 16×。

### 13.10 为什么同尺寸请求 P-D 正常、抢占 OOM（三因素）
**配置铁证**（`start_prefill.sh` / `start_decode.sh`）：**P 节点 TP=8、DP=2；D 节点 TP=1、DP=32、CP=16**（kv_transfer_config：prefill tp_size=8、decode tp_size=1）。两条路径"7310 prefill 跑在哪、用多少并行度、卡片是否已满"完全不同——请求尺寸一样，prefill 承载方式天差地别。

**正常 P-D（不 OOM）**：
```
P(TP=8,DP=2)：做 7310 全量 prefill → 模型+激活按 TP=8 切到 8 张 P 卡,每卡~1/8 激活
              P 卡 prefill 专用、预算充足；encoder 也在 P 算(TP=8 分布)
              算完 KV 经 mooncake 传 D
D(TP=1,CP=16)：只做 CP decode → num_new_tokens=0/1(07-21 cp req 铁证)，每卡 1 token，D 从不跑大 prefill
→ 无单卡承载完整 7310 prefill 激活 → 不 OOM
```
**抢占路径（OOM）**：
```
D 正 CP decode(每卡1 token) → preempt: free 全16卡KV、num_computed=0、cp_ranks=[]
                              kv_transfer_params=None(切断P,丢弃P已算prefill+encoder)
→ 重排: specify_dp=True → 1 张 D 卡(TP=1,CP16→1降级) → num_computed=0 全量重做7310 prefill
   TP=1=整模型在1卡无TP切分; 降级=无CP摊薄; 同卡还要重算encoder(P已断)
→ 这1张D卡: 已被KV cache占~57GB(decode常态), 再背7310全量prefill激活+MoE a2a 800MB+encoder → OOM
```
**三个致命差异**：
| 维度 | 正常 P-D | 抢占重排 |
|---|---|---|
| 谁跑 prefill + 并行度 | P，**TP=8**（激活 1/8 分布） | D，**TP=1 单卡**（~8× 集中） |
| 卡片状态 | P 卡=prefill 专用、预算充足 | D 卡=decode 节点、KV 已占~57GB |
| 是否丢弃进度 | P 算一次即可 | `num_computed=0`+切断 P → 全量重做(含encoder) |

**一句话**：正常 P-D 把 7310 prefill 分布在 P 的 8 张干净卡上、D 只 decode；抢占把 P 的活儿**整个扔掉、塞给 1 张已被 KV 填满的 D decode 卡**（TP=1 无切分、CP 降级无摊薄）重做——同尺寸 7310 从"8 卡分布+干净预算"变成"1 卡集中+饱和预算"，外加重做 encoder。**不是请求变大，是 prefill 承载从分布式退化成单卡饱和重做。**

### 13.11 三轮日志对照实测 + OOM 边界判据
| 轮次 | 配置 | fresh CP | 抢占 | 降级单 rank 重排 | OOM | hang | 收尾 |
|---|---|---|---|---|---|---|---|
| 07-20 08:54 | 72×72, ~7310 prompt, thr=4096 | — | 1 次 | 1 次 ~7310 tok | **✅** | 级联 | 崩 |
| 07-21 06:22 | 40×40, 128 prompt, thr=100 | 32×(16路) | 59 次 | 59 次 ~147~159 tok | 0 | 无 | 干净 |
| 07-21 07:23 | 40×40, 128 prompt, thr=100 | 32×(CP decode) | 46 次 | 46 次 ~147~161 tok | 0 | 无 | 32 Completed |

07-21 新跑明细（node0，PID 515519）：32 全图文长请求；cp req 32 条（specify_dp 全 False）；short req 46 条（specify_dp 全 True）；PREEMPTED 46（首抢 size=16 共 14、降级后 size=1 共 32）；14 个不同请求被抢（各 ~3.3 次），18 个全程 CP；07:56:42 双 engine idle 干净收尾。

**OOM 边界判据钉死**：OOM 与抢占次数（46/59）、是否多模态无关，**只与降级单 rank 重排的 prefill token 数成正比**。46~59 次降级 0 OOM vs 1 次降级 OOM，差别纯粹是 prompt 长度（128 安全、7310 致命）。同为多模态、同为 CP、同为抢占降级，唯一变量是 prompt 长度。

### 13.12 纯文本长请求（256k）抢占 OOM 边界
- 同款 MoE a2a 激活 OOM：**不会**——纯文本无 encoder 跨 rank 复制，CP 把每 rank 本地段 prefill 激活摊薄到 ~1/16，单 rank 重排在合理批 token 下 a2a buffer 远小于 800MB。
- 但纯文本 256k 有**独立 OOM 风险**：KV 容量 `307,328 tokens`（≈18.8× 262144），256k 请求 KV 占满；preempt `num_computed=0` 全量重填 KV → **KV block 层 allocation 失败**（崩点在 register/allocate，非本次 MoE a2a）。属另一条线，与多模态/encoder cache 无关，裸 HEAD 同成立。
- 净：256k 纯文本抢占大概率 OOM，但崩点是多模态这次的**不同**层（KV 层 vs 激活层）。

### 13.13 C 的本质 + 与缺陷 A/B 的关系
C 的本质**不是 encoder，是"抢占把分布式 prefill 退化成单卡饱和重做"**——encoder 只是叠加项（且小，单图~十几 MB；主因是 7310 单卡全量 prefill 激活 + MoE a2a）。这也解释为何纯文本同长度抢占也不一定 OOM（无 encoder 叠加，阈值更高，但 TP=1 饱和卡上 7310 全量 prefill 仍是重压）。

与 A/B 关系：
| 缺陷 | 触发 | 表现 | 修复 |
|---|---|---|---|
| **A** CP hang | decode 抢 CP 长请求 → 各 rank num_decode_tokens 失配 → 全组 all_gather 形状错配 | NPU hang | patch3 未覆盖（§12） |
| **B** encoder miss | 被抢重排 prefill 取 `encoder_cache[mm_hash]`=None | assert 崩 2780 | patch3 ✅ |
| **C** 抢占重排 OOM（本章） | 降级单 rank 全量长 prefill 激活顶爆 | MoE a2a OOM | patch4 |

07-20 这轮：preempt 降级长请求 → C（OOM）先于 A（hang）触发。补正 §12.0.1 的"A 表现为集群 hang"——**长 CP 带图场景下真实首发症状是 C( OOM)，hang 是级联下游表现**。先解 C 才能让环境活到验证 A/B。

### 13.14 patch4 治理方向（C/D 治本）
> patch3（B）三轮表现正常无 miss，不修订。patch4 针对抢占降级导致的 C( OOM)/A(hang)。
**核心思路**：别让抢占触发"单卡全量重做"——降级重排前探测"单 rank 全量重排 prefill 激活预算"，超阈改走 recompute-free 等待，而非 `num_computed=0` 归零重排。
1. **preempt 候选过滤（最轻，止血）**：候选跳过"decode 阶段长 CP 请求"（`len(cp_ranks)>1 and num_computed>=num_prompt_tokens`），只允许抢 prefill 阶段 CP 或短请求。一箭双雕：防 C + 防 A。
2. **长请求降级保护（中职）**：被抢长请求若必须让位，优先 recompute-free 等待（KV 延迟回收、`num_computed` 不归零、`status` 置 WAITING 而非归零），下帧再排，避免阶跃式全量 prefill。
3. **激活预算门控**：waiting loop 重排长 CP 带图 prefill 前，按 `num_new_tokens + encoder_tokens` 对当帧剩余激活预算 can-allocate，超限整请求延后一帧。
4. **缺陷 E 优化（可选，非 PD 路径）**：fresh CP prefill 时 encoder 只在拥有图像段的 rank 调度、其余 rank 复用，省最多 16×。当前 PD 配置不触发，低优先。

> 推荐先上方向 1 + 日志止血，探明线上长 CP 请求 decode 抢占真实频率后，再决定方向 2/3 治本。

### 13.15 encoder 专项方案族 + 分阶段路径 + 编码落点
> encoder 问题 3 子问题：B miss（patch3 ✅）、重算浪费（❌ 每次抢占重算整图）、C OOM 放大（❌ 单 rank 吞整图 encoder+全量prefill）。结构性根因：encoder 输出 ①贵（整图视觉前向）②per-rank GPU 局部 ③生命周期绑在 preempt/KV 上（随 KV free）。patch3 解 ①一致性，未动 ②③。

**方案族（按"治哪个子问题"）**：
- **方案① 不 free encoder + 重排优先落持图 rank**（治重算浪费+削C）：preempt 只 free KV 不 free encoder；select_dp 优先选已持 `mm_hash` 的 rank（patch3 per-rank `cached[mm_hash]` 可查，需加 `ranks_holding` 接口）；持图 rank 满才 fallback 重算。常见情况零重算。代价：不改降级，单 rank 全量 prefill 文本激活仍在。侵入中。
- **方案② encoder 一次性计算 + 跨 rank 复制**（治 B 永久+重算浪费）：首次 prefill 算一次，broadcast 到全 16 rank `encoder_cache`；之后任何重排 cache hit，永不重算永不 miss。代价：16× 存储（单图~十几MB×16≈几百MB，可接受）+ 首次计算。即 §5 缺口3 ECConnector 节点内简化版。侵入中。
- **方案③ encoder 生命周期与请求挂钩、与 preempt 解耦**（概念最干净，①②基础）：encoder 生命周期=请求生命周期，不随 preempt free，只随 finish/abort free。代价：需配 LRU evict（已有 `freeable`）。侵入低-中。
- **方案④ 多模态长请求重排不降级、保持 CP 重切**（治 C/D）：preempted 多模态长请求重排不走 specify_dp 单 rank，保持 16 路 CP 重切；prefill 激活摊薄、encoder 只在拥有图像段 rank 各算一片。代价：重占 16 路 KV 可能再触发当初压力；跨 16 rank 需形状对齐（碰 A）。侵入中-高。
- **方案⑤ 重排前激活预算门控**（治 C，与 encoder 正交）：waiting loop 重排前估 `prefill_tokens+encoder_tokens` 对剩余预算 can-allocate，超阈整请求延后一帧（recompute-free 等待，num_computed 不归零）。侵入中。
- **方案⑥ preempt 候选过滤——不抢 decode 阶段长 CP**（最轻止血）：候选跳过 `len(cp_ranks)>1 and num_computed>=num_prompt_tokens`，绕开整类（C+A），encoder 根本不被触发。代价：KV 极紧无候选时可能饿死。侵入低。

**推荐分阶段路径**：
```
Phase 1 止血(低风险先上)：方案⑥ 候选过滤 → 绕开整类，探线上长CP decode 抢占频率
Phase 2 治本 encoder(主推方案③+①)：
  ③ encoder 生命周期解耦 preempt(不 free) + ① 重排优先落持图 rank
  → 消重算浪费、削 C 的 encoder 部分、B 永不复发；存储代价最小；持图 rank 满时 fallback 重算保 patch3 兜底
Phase 3 可选加强：
  重算仍贵 → 加方案② 复制(彻底零重算,付16×存储)
  OOM 仍现 → 加方案⑤ 激活预算门控
  想根治降级 → 方案④(碰A,最高成本,最后考虑)
```
主推③+①理由：直击结构性根因，在 patch3 per-rank 记账上扩展，侵入/存储代价最小，fallback 保正确性。

**编码落点（方案③+①）**：
| 改动 | 位置 | 内容 |
|---|---|---|
| encoder 不随 preempt free | `_preempt_request`（patch3 `:836`） | 移除 `_free_encoder_cache_for_request`；保留 KV free |
| encoder 随请求结束 free | `_free_request`（`:362` 路径） | 保留 finish/abort 时 free |
| 持图 rank 优先 | `select_dp`（`:91`） | PREEMPTED+has_encoder 分支：查 `ranks_holding(mm_hash)` ∩ 有容量 rank；空则 fallback |
| 查询接口 | 新增 helper | 遍历 `encoder_cache_managers` 返回 `mm_hash in mgr.cached` 的 rank |
| fallback 兜底 | waiting loop `:1373` | 持图 rank 无容量时落任意 rank + `_try_schedule_encoder_inputs_for_rank` 重算（=patch3 现行） |
| 容量保护 | encoder_cache eviction | 不随 preempt 回收 → 调 LRU evict 策略（已有 `freeable`） |

> 注：C 治理（方案⑥/④/⑤）与 encoder 专项（方案③+①/②）正交互补——前者治"单卡全量重做 OOM"，后者治"encoder 重算浪费/B 永久"。

### 13.16 关键代码行号速查（HEAD `3a1d3c4f4` + patch3）
| 位置 | 说明 |
|---|---|
| `cross_dp_scheduler.py:836-858` | `_preempt_request`（free KV + num_computed=0 + cp_ranks=[] + 切断 P） |
| `:1266 / :1201` | `kv_consumer and PREEMPTED → specify_dp=True`（降级触发点） |
| `:117-128` | `select_dp` specify_dp 单 rank 分支（降级落地） |
| `:108` | `select_dp` fresh 长 → 全 16 rank 分支 |
| `:945 / :958` | 抢占触发（allocate_slots None）+ FCFS 候选选择 |
| `:981` | `prev_cp_ranks=cp_ranks; cp_ranks=[]`（清空归属） |
| `:1355` | cp req / short req 日志判定（`len(selected_dp)>1`） |
| `:1373 / :985` | waiting/running loop `for rank in selected_dp/cp_ranks` encoder 调度 |
| `:1439` | `request.cp_ranks = selected_dp`（降级固化） |
| `:1631` | SchedulerOutput per-rank `scheduled_encoder_inputs[idx]` |
| `:298-315` | `_try_schedule_encoder_inputs_for_rank` 包装层（仅换 manager） |
| `cross_dp_kv_cache_manager.py`(vllm/v1/core/) | `free` 遍历 cp_ranks 全 free（docstring "across all CP ranks"） |
| `request_queue.py:235` | `is_long_request`（总 prefill token vs threshold） |
| `scheduler.py:1125-1290` | 基类 `_try_schedule_encoder_inputs`（请求级 overlap） |
| `scheduler.py:208` | 单一全局 `encoder_cache_manager`（干净代码，缺陷 B 根源） |
| `encoder_cache_manager.py:107` | `check_and_update_cache` miss 返回 False（→ 16× 复制根因） |
| `gpu_model_runner.py:2543-2564` | `_batch_mm_inputs_from_scheduler`（worker 无 cp_rank 去重） |
| `gpu_model_runner.py:2780` | encoder miss 崩点 `assert encoder_output is not None` |
| `vllm_ascend/ops/fused_moe/comm_utils.py:32` | **OOM 崩点** MoE a2a `new_empty` |
