# DyCP Decode 节点（kv_consumer）正常代码逻辑分析

> **范围（本文件）**：仅 **Decode 引擎（kv_consumer）** 的 DyCP **正常**调度 + 运行时 + attention + 采样 + KV 加载逻辑。
> **不含**：① Prefill 引擎（kv_producer）侧的 CP prefill 切分；② 抢占 / encoder-cache-miss / `gpu_model_runner.py:2779` assert / patch3 缺陷分析（见 `D:/xym/落盘/DyCP代码处理路径分析.md` §8 与 `抢占逻辑优化/方案结论.md`）。
> **行号约定**：均回读当前磁盘 HEAD 核对。
> 仓库：`D:/xym/Code/ant/0713/{vllm, vllm-ascend}`；模型 kimi-k2.5-w4a8（MLA + MoE）；启动脚本对应磁盘 `baseline脚本.txt`（DyCP 配置，见综合文档 §2 的文件名互换说明）。

## 1. 概述与拓扑（Decode 节点视角）

部署拓扑中 Decode 引擎为 **kv_consumer**：`data-parallel-size=32`、`tensor-parallel-size=1`、两节点 × 16 卡、`dp_per_domain=16` → 共 2 个 domain、每域 16 个 rank 构成 1 个 `CrossDPScheduler`（`cp_world_size=16`）。

PD 分工：Prefill 引擎（producer，dp=2/tp=8）算完 prompt KV 后经 Mooncake 推送给 Decode；**Decode 侧只做"加载远程 KV + 后续 decode 步"**。本文件只分析 Decode 这一侧。

**DyCP 在 Decode 节点的确切含义**（关键，常被误解）：

- Decode 节点 `kv_role == 'kv_consumer'` → `prefill_dycp_size = 1`（model_runner_v1.py:322-323）——**Decode 节点不在 DyCP rank 间切分 prefill**，`use_prefill_cp = pcp_size>1 or prefill_dycp_size>1 = False`（model_runner_v1.py:461-462）。DualChunkSwap 等 prefill-CP 机制在 Decode 节点不激活。
- DyCP 在 Decode 节点的作用是 **decode 阶段的 KV 跨 rank 分片协同**：长请求（prompt ≥ `long_request_threshold=100`）`cp_size=16` → 被放到全部 16 个 dycp rank，其 **decode KV cache 按 1/16 分片**存于各 rank（`decode_dycp_word_size=16`），每 rank 对自己 KV slice 算 partial attention，跨 16 rank 合并 `(out, LSE)` → 确定性采样保证 16 rank 同 token。
- 短请求（prompt < 100）`cp_size=1` → 单 rank 持全 KV、普通 decode、无跨 rank 合并。

**相位判定**：`decode_threshold = 1 + num_speculative_tokens`（pcp_utils.py:99；model_runner_v1.py:375）。`is_prefill = num_scheduled_tokens > decode_threshold`（pcp_utils.py:202）——≤ decode_threshold 即 decode 步（1 个 token，或 1+spec）。

## 2. 调度：CrossDPScheduler（Decode 侧）

### 2.1 选型与 cp_world_size

- 选型：`dp_per_domain > 1` → 硬编码 `CrossDPScheduler`（vllm/v1/engine/core.py:136-140），绕过 `get_scheduler_cls()`。
- `cp_world_size = parallel_config.dp_per_domain = 16`（cross_dp_scheduler.py:228）——DyCP 复用 DP-per-domain 组作为 CP 组。

### 2.2 kv_consumer 的 rank 预算（与 producer 不同）

```python
kv_role = getattr(vllm_config.kv_transfer_config, "kv_role", None)
if kv_role == 'kv_producer':
    rank_budgets = [max_num_scheduled_tokens // cp_world_size] * cp_world_size   # 均分
else:  # kv_consumer (Decode)
    rank_budgets = [max_num_scheduled_tokens] * cp_world_size                     # 每卡满额
```
（cross_dp_scheduler.py:843-847）Decode 每 rank 预算满额 `max_num_scheduled_tokens`（producer 才均分）。

### 2.3 长短判定

`LongShortRequestQueue.is_long_request`（request_queue.py:235-238）：
```python
num_prefill_tokens = request.num_tokens - request.num_output_tokens
return num_prefill_tokens >= self.long_request_threshold   # threshold=100
```
N≥100 → long，N<100 → short。`max_long_requests = num_cp_seqs`（cross_dp_scheduler.py:242,249）——`num_cp_seqs` 默认 0（vllm/config/scheduler.py:149），部署 `common.sh`（不在本仓库内）须显式 `--num-cp-seqs>0`，否则 long 全被跳过（request_queue.py:263-265）。实测 long 请求在跑（见 §10）→ 部署侧已注入 `>0`。

### 2.4 候选 rank 选择 / cp_size 设置

`RequestManager.select_dp`（cross_dp_scheduler.py:91-114）：

- **running 续跑**：已有 `cp_ranks` 的请求，若容量与预算够 → 返回原 `cp_ranks`（:92-94）。即 long 一直在 16 rank、short 一直在单 rank。
- **long 且 `not specify_dp`**（新请求）→ 若全域有容量，返回 `[0..cp_world_size-1]`（全部 16 rank）（:99-102）。
- **short**（或 long+specify_dp）→ 选"预算最大且 `num_req_per_dp` 最小"的单 rank（:107-114）。

waiting 循环调度后（:1390-1395）：`request.cp_ranks = selected_dp`；**`req_id_to_cp_size[req_id] = len(selected_dp)`**（long=16，short=1）；每 rank 记 `cp_rank_to_req_id[rank].append(req_id)`。

### 2.5 预算扣减（decode 步）

`_deduct_budget`（cross_dp_scheduler.py:862-867）：`per_rank_cost = ceil(num_new_tokens / cp_size)`，对每个参与 rank 扣。
- long（cp_size=16）decode 步 `num_new_tokens=1`（或 1+spec）→ 每卡扣 `ceil(1/16)=1`。
- short（cp_size=1）→ 单卡扣 `ceil(1/1)=1`。

running 循环把请求 append 到其所有 cp_ranks 的 `scheduled_running_reqs[rank]`（:1124-1125）——**long 请求每个 decode 步同时出现在 16 个 rank 的 SchedulerOutput 上**，short 只在 1 个。

### 2.6 num_cp_request（batch 内 long 请求数）

`SchedulerOutput.num_cp_request = sum(1 if cp_size>1 else 0 for ...)`（cross_dp_scheduler.py:1581）——**只数 long（cp_size>1）请求**；short 不计入。`SchedulerOutput` 还携带 `req_id_to_cp_size`（:1557）、`cp_rank_scheduled_tokens`（其中存 cp_size，:1129/1466）、`cp_rank_to_req_id`、`cp_rank`（当前 worker 的 rank）。

## 3. Worker 运行时落地（Decode 侧）

### 3.1 CP 组拓扑与 PD 特化

model_runner_v1.py:308-337：

```
dcp_size  = get_dcp_group().world_size         # Decode 节点 = 1（无独立 DCP）  (:309)
pcp_size  = get_pcp_group().world_size         # = prefill_context_model_parallel_size，纯 DyCP = 1 (:311, parallel_state.py:1788-1789)
dycp_size = parallel_config.dp_per_domain = 16 (:313)
cp_world_size = dycp_size = 16; cp_rank = dycp_rank  (:315-316)

kv_role=='kv_producer' → prefill_dycp_size=dycp_size   # 仅 producer
else (kv_consumer)      → prefill_dycp_size=1          # Decode 节点 (:322-323)

common_pcp_size = prefill_dycp_size if >1 else pcp_size  # Decode = 1 (:336-337)
```

派生属性（model_runner_v1.py:457-462）：
- `use_cp = common_pcp_size * dcp_size * dycp_size > 1` = `1*1*16>1` = **True**
- `use_prefill_cp = pcp_size>1 or prefill_dycp_size>1` = **False**

`PCPManager` 在 `common_pcp_size*dcp_size*dycp_size>1` 时构造（model_runner_v1.py:342-358），传入 common_pcp_size=1、dcp_size=1、dycp_size=16。

### 3.2 decode_dycp 特化（核心）

`PCPManager.__init__`（pcp_utils.py:91-97）：
```python
if self.dycp_world_size > 1 and kv_role == 'kv_consumer':
    self.decode_dycp_word_size = self.dycp_world_size   # = 16
    self.decode_dycp_world_rank = self.dycp_world_rank
else:
    self.decode_dycp_word_size = 1
```
**Decode 节点把 long 请求的 decode KV cache 跨 16 个 dycp rank 分片**。producer/非 PD 则 `=1`（不分片）。

### 3.3 num_dycp_reqs = num_cp_request（long 请求计数落地）

- 从 scheduler_output 读 `num_cp_request`（model_runner_v1.py:700-704）。
- `dycp_size>1 and num_cp_request>0` → `num_dycp_reqs = num_cp_request`（model_runner_v1.py:926-927）。即 batch 前 `num_cp_request` 个是 long（CP）请求，其后是 short（DP）请求。
- `init_batch_info` 记 `is_prefill = num_scheduled_tokens[:num_reqs] > decode_threshold`（pcp_utils.py:202）、`num_dycp_dp_tokens = num_scheduled_tokens[num_dycp_reqs:].sum()`（:210，short 请求 token 总和）。

### 3.4 short 请求绕过 CP

- `update_tokens_for_pcp` 只处理 `num_scheduled_tokens[:num_dycp_reqs]`（long 请求）（pcp_utils.py:572；model_runner_v1.py:738）。short 请求（`[num_dycp_reqs:]`）不进 PCP 切分/分片元数据。
- 同一 batch 可混合 long+short：前 `num_cp_request` 走 CP（16-rank KV 分片 + 合并），其后走单 rank DP。

## 4. Decode KV 分片机制（DyCP 在 Decode 节点的核心）

### 4.1 分片轴：dycp（decode_dycp_word_size=16）

`generate_pcp_metadata`（pcp_utils.py:1085-1149）由 `pcp_world_size*dcp_world_size*dycp_world_size > 1`（:1104，Decode=16>1）触发。构建每 rank decode KV 长度张量：

```
num_computed_tokens_of_pcp_dcp: shape =
  [num_dycp_reqs * decode_threshold,
   pcp_world_size,                         # =1（Decode 静态 PCP 关）
   dcp_world_size * decode_dycp_word_size] # =1*16=16  ← 16-way dycp 分片轴 (pcp_utils.py:1113)
```

`context_lens = [decode_context_lens, prefill_context_lens]`（:1106-1111），对每个 decode 帧 `decode_idx` 调 `_get_cp_local_seq_lens(context_lens - decode_idx, pcp_world_size=1, decode_dycp_word_size=16, cp_kv_cache_interleave_size=128)`（:1123-1129）填入张量。该张量随后供 attention 作 `actual_seq_lengths_kv`（每 rank 本地 KV 长度）。

### 4.2 _get_cp_local_seq_lens：按 128-token block 轮转分片

`_get_cp_local_seq_lens`（pcp_utils.py:1061-1083）：
```
base      = seq_lens // interleave // total_world_size * interleave
remainder = clip(remainder - rank*interleave, 0, interleave)      # interleave=128
local_len = base + remainder
```
`interleave = cp_kv_cache_interleave_size = 128 = block_size`。即 **decode KV 以 128-token block 粒度在各 dycp rank 间轮转分片**，每 rank 持约 1/16（按 block 对齐）。断言 `cp_kv_cache_interleave_size == block_size`（platform.py:490-499）保证传输分片恒为整 block。

### 4.3 decode token 跨 rank 复制

`update_tokens_for_pcp` 对 decode 请求（`num_scheduled_tokens ≤ decode_threshold`）说明："PCP does not split decode requests... duplicate the scheduled tokens across the pcp_world_size ranks"（pcp_utils.py:580-584）。在 Decode 节点 pcp_world_size=1，此处为 no-op；**真正的 16-rank 复制发生在调度层**——§2.5 long 请求每步被 append 到全部 16 个 rank 的 `scheduled_running_reqs`，即 16 个 worker 进程各自独立对该请求执行 decode 步、各自读自己的 1/16 KV slice。

> 结论：long 请求 decode = 16 个 dycp rank **各持 1/16 KV + 各算 partial attention + 跨 rank 合并 (out,LSE) + 确定性采样**；short 请求 decode = 单 rank 全 KV、无合并。

### 4.4 block_table / slot_mapping rank-local 重写

`compute_domain_slot_mapping(req_indices, positions_np, num_cp_request)`（model_runner_v1.py:707）按 domain（dycp rank）计算 slot mapping，使每 rank 只写自己 KV slice 的 block。`get_padded_slot_mapping`（pcp_utils.py:842-861）按 `pcp_unpad_mask` 把 real slot 散到 padded 位置、DP slot 追加其后。

## 5. Decode CP Attention（MLA 主路径，kimi-k2.5）

模型为 kimi-k2.5（MLA + MoE），Decode 节点 decode-CP 走 **`mla_cp.py`** 路径。

### 5.1 MLA decode-CP 流程

每 rank 持不同 KV slice，Q 跨 DCP allgather（Decode dcp=1 时 no-op），各算 partial `(out, LSE)`，跨 DYCP 组合并：

- `build_decode_metadata`（mla_cp.py:278-304）：`actual_seq_lengths_kv = num_computed_tokens_of_pcp_dcp[:, pcp_rank, dcp_rank]`（即 §4.1 张量中本 rank 的 KV 长度），`decode_meta.seq_lens_list` 在 `_forward_decode`（:1084）使用。
- `reorg_decode_q`（mla_cp.py:877-882）：Q 跨 DCP allgather（dcp=1 no-op）；**不跨 PCP allgather**——每 PCP/dycp rank 用同一 Q 对自己 KV slice 算 attention。
- **跨 rank `(out, LSE)` 合并**：`_npu_update_dycp_attn(num_dycp_reqs, attn_output, softmax_lse)`（mla_cp.py:1161-1168；common_cp.py:121-155）——DYCP 组 `all_gather` `[out, lse]`（common_cp.py:137）→ reshape `[dycp_size, S, H, D+1]`（:140）→ `npu_attention_update_v2`（:150）合并 16 个 partial。
- 在线 softmax：`LSE_final = logsumexp(LSE_i)`，`O_final = Σ exp(LSE_i − LSE_final)·O_i`（attention_cp.py:606-613 纯 torch 等价实现）。
- 合并后 `v_up_proj` → `o_proj` 出本 rank 的 decode 输出。

### 5.2 标准 attention decode-CP（非 MLA 模型用，参考）

`AscendAttentionCPImpl._forward_decode_pcp_dcp`（attention_cp.py:527-603）：Q 在 `dcp_size>1` 时 `get_dcp_group().all_gather`（:532）；KV 本地读 `actual_seq_lengths_kv = num_computed_tokens_of_pcp_dcp[:, pcp_rank, dcp_rank]`（:550-552）；跨 rank 合并经 `_process_attn_out_lse` + `_npu_attention_update`（:601-602；common_cp.py:99-184）。Decode 节点 pcp=dcp=1 时其 PCP/DCP AllGather 为 no-op、`_npu_attention_update` 退化为单元素——故 **标准 attention 的 16 路合并实际发生在 DYCP 组**（同 §5.1 机制，由 `_npu_update_dycp_attn` 承担）。dcp_size==1 且 pcp_size==1 且无 dycp 时（short 请求 / 非 CP），合并整体跳过、decode 行为与无 CP 一致。

### 5.3 short 请求 decode（cp_size=1，无 CP）

short 请求位于 batch 中 `num_cp_request` 之后、不进 `update_tokens_for_pcp`/`generate_pcp_metadata` 的 CP 分片；decode_dycp 对其有效 `=1`（单 rank 持全 KV），attention 走常规单 rank decode，无跨 rank 合并、无 dycp 采样协调。

### 5.4 集合通信清单（Decode-CP）

仅 `all_gather`（PCP/DCP/DYCP 组）、`all_to_all_single`（DCP 组，dcp=1 时 no-op）、`npu_attention_update(_v2)`（online-softmax 合并 kernel）。**无 ring-attention、无 attention 内 reduce_scatter**。

## 6. dycp_sampling（跨 rank 确定性采样）

**为何需要**：long 请求在 16 个 dycp rank 各自 decode + 合并 attention 后，**每 rank 都要采样下一 token**；必须保证 16 rank 采出**同一** token（否则各 rank 状态分裂）。

- `make_dycp_sample_seed`（dycp_sampling.py:37-47）：`BLAKE2b(model_seed, req_id, sample_pos, phase)` 派生 per-`(req, pos, phase)` 确定性种子 → 所有 rank 对同请求同位置生成相同随机数。
- `temporary_dycp_sample_generators`（dycp_sampling.py:90+）上下文管理器；在 model_runner_v1.py:475-507（`_dycp_deterministic_sample_generators`）包裹采样，`num_cp_reqs = scheduler_output.num_cp_request`（model_runner_v1.py:1695）——即只对 long（CP）请求用 dycp 种子；short 请求用常规采样。
- 结果：16 rank 同种子 → 同随机数 → 同 token；最终仅保留一份写回序列。

## 7. KV 加载（PD handoff，Decode 侧正常路径）

Decode 引擎为 `kv_consumer`，通过 `MooncakeConnector` 从 Prefill 引擎拉取 prompt KV（正常路径，与抢占无关）。

- **后台线程**：`kv_role=='kv_consumer'` → `KVCacheRecvingThread`（mooncake_connector.py:1316-1331）。
- **匹配/_alloc**：`get_num_new_matched_tokens`（:967-1001）返回完整未 prefill 的 prompt 长度；`update_state_after_alloc`（:1003-1029）记录 `local_block_ids`。
- **加载映射**：`start_load_kv` → `_get_kv_split_metadata`（:1364-1651）计算 P→D block/port 映射，`get_local_remote_block_port_mappings`（:1450-1501）按 `cp-kv-cache-interleave-size=128` block 粒度拆分，`batch_transfer_sync_read`（:544）执行拉取。
- **端口映射**：`domain_port_base = kv_port + domain_parallel_rank * tp * pp * dp_per_domain`（:1188-1194）；`pd_tp_ratio = prefill_tp // decode_tp = 8/1 = 8`（ascend_config.py:92-99）。Prefill dp2/tp8 ↔ Decode dp32/tp1：32 个 decode rank 各自从匹配的 prefill rank 拉 head/block 分片。
- **ack**：producer 不主动 push，等 consumer `DONE_RECVING`（mooncake_connector.py:64, 264-265）。

### 7.1 调度侧 load_kv_async（正常 KV 加载状态）

CrossDPScheduler waiting 循环中远程 KV 异步加载（cross_dp_scheduler.py:1238-1241）：`load_kv_async=True` 时 `num_new_tokens=0`（KV 还没就绪的正常态）；`allocate_slots(..., delay_cache_blocks=load_kv_async)`（:1379）；未就绪请求在 :1426-1437 被计数、`prepend` 回 waiting 头、置 `WAITING_FOR_REMOTE_KVS` 跳过本步。KV 就绪后后续 schedule 正常推进（prefill-append 紧接着 decode）。

> 注：`load_kv_async` 的 normal 语义就是"等远程 KV"。抢占场景下它与 encoder 分支的交互（`and not load_kv_async` 守卫）属缺陷修复范畴，不在本文件——见综合文档 §8.7。

## 8. 端到端 Decode 流程（正常，无抢占）

### 8.1 ASCII 数据流（仅 Decode 侧）

```
   (Prefill 引擎已算好 prompt KV，Mooncake 推送) ──────────┐
                                                          ▼
  ┌──────────────────────── Decode Engine (kv_consumer) ────────────────┐
  │ dp=32, tp=1, dp_per_domain=16 → CrossDPScheduler×2, cp_world_size=16 │
  │                                                                      │
  │  ① 请求入队 → CrossDPScheduler.schedule()                            │
  │     is_long?  N=prompt_len-0  ≥ 100 → long                           │
  │     select_dp: long → cp_ranks=[0..15], cp_size=16                    │
  │                 short → cp_ranks=[r*],   cp_size=1                    │
  │     num_cp_request = #{long}；req_id_to_cp_size 落地                  │
  │                                                                      │
  │  ② KV 加载 (Mooncake consumer)                                       │
  │     load_kv_async=True, num_new_tokens=0                             │
  │     allocate_slots(delay_cache_blocks=True) → WAITING_FOR_REMOTE_KVS │
  │     _get_kv_split_metadata: P→D 按 128-block 映射, batch_transfer     │
  │     KV ready → 后续步 prefill-append (非 CP, prefill_dycp_size=1)    │
  │                                                                      │
  │  ③ decode 步                                                         │
  │     long: 16 rank 各持 1/16 KV (decode_dycp_word_size=16,            │
  │            _get_cp_local_seq_lens 按 128-block 轮转分片)             │
  │            每 rank 对本地 KV slice 算 partial (out, LSE)             │
  │            _npu_update_dycp_attn: DYCP 组 allgather + npu_attn_update│
  │            dycp_sampling: BLAKE2b 种子 → 16 rank 同 token            │
  │     short: 单 rank 全 KV, 常规 decode, 无合并                         │
  │                                                                      │
  │  ④ output → API                                                      │
  └──────────────────────────────────────────────────────────────────────┘
```

### 8.2 long 请求 decode 步（逐步）

1. `CrossDPScheduler.schedule()` 判 long（prompt≥100）→ `cp_ranks=[0..15]`、`cp_size=16`（cross_dp_scheduler.py:1390-1392）；`num_cp_request` 计入。
2. running 循环把请求 append 到 16 个 rank 的 `scheduled_running_reqs`（:1124-1125），每 rank 扣 `ceil(1/16)=1` 预算（:1131）。
3. 每 rank worker：`num_dycp_reqs=num_cp_request`（model_runner_v1.py:926-927）；`update_tokens_for_pcp` 处理该 long 请求（pcp_utils.py:572）；`generate_pcp_metadata` 算本 rank KV 长度（`num_computed_tokens_of_pcp_dcp[:,0,rank]`，pcp_utils.py:1113）。
4. MLA decode-CP：`_forward_decode` 用本 rank KV 长度读 1/16 KV slice（mla_cp.py:1084）→ partial `(out,LSE)` → `_npu_update_dycp_attn` 跨 16 rank 合并（mla_cp.py:1161-1168）。
5. `dycp_sampling`：16 rank 同 BLAKE2b 种子 → 同 token（dycp_sampling.py:37-47；model_runner_v1.py:1665,1695）。
6. 仅一份输出写回 → API。

### 8.3 short 请求 decode 步

1. 判 short → `cp_ranks=[单rank]`、`cp_size=1`；不计入 `num_cp_request`。
2. 单 rank 持全 KV；`update_tokens_for_pcp`/CP 分片不触及（pcp_utils.py:572）。
3. 常规 decode，无跨 rank 合并、无 dycp 种子协调。
4. 输出 → API。

### 8.4 混合 batch

同一 step 可含 long（前 `num_cp_request`，走 16-rank CP）+ short（其后，走单 rank DP）。`_build_attn_state`（model_runner_v1.py:1112-1141）按 `num_scheduled_tokens` vs `decode_threshold` 分 DecodeOnly / ChunkedPrefill 等相位；`with_prefill`（:692-693）控制是否需 prefill 处理（Decode 节点 prefill 非_cp）。

## 9. cp-kv-cache-interleave-size=128（Decode 侧作用）

- 设 `parallel_config.cp_kv_cache_interleave_size=128`。
- 断言 `pcp*dcp>1` 时 `== cache_config.block_size`（=128，platform.py:490-499）。
- decode KV 分片粒度：`_get_cp_local_seq_lens` 以 128-token block 轮转切分（pcp_utils.py:1075-1080）→ 每 rank KV slice 恒为整 block 对齐，P→D KV 传输分片亦为整 block（简化传输、与 `block_size` 对齐）。

## 10. 注意事项（Decode 正常路径相关）

- **`num_cp_seqs` 默认 0 陷阱**：`max_long_requests=num_cp_seqs`（cross_dp_scheduler.py:242,249），默认 0（scheduler.py:149）→ long 全被跳过（request_queue.py:263-265）。本地脚本与不在仓库内的 `common.sh` 未见显式 `--num-cp-seqs`；但 long 请求实测在跑（CP 路径激活）→ 部署侧已注入 `>0`。**部署/迁移须确保 `--num-cp-seqs>0`**，否则 DyCP decode KV 分片路径被静默关闭、long 退化为单 rank。
- **调试残留 `flagg=1` 强制抢占**（cross_dp_scheduler.py:824, 968-971）：当 ≥2 running 时每步强制 `new_blocks=None` 触发无端抢占——**会破坏正常 decode 流**，合并前必须 `git checkout --` 清除。属调试代码，非正常逻辑，但若残留会影响 Decode 正常调度。
- **`prefill_dycp_size=1`**：Decode 节点无 prefill-CP，DyCP 仅作用于 decode 阶段的 KV 分片；本文不展开 prefill（producer 侧 `prefill_dycp_size=dycp_size` 的 prefill 切分见综合文档 §4）。
- **`kv_connector_module_path: "vllm_ascend.distributed.mooncake_connector"`**：两脚本均设但路径不存在，实际注册路径 `vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_connector`（被忽略，建议修正）。
- **`use_ascend_direct`/`use_layerwise`**：当前 Mooncake 路径不消费（惰性 flag）。
- **`DATA_PARALLEL_HEAD_ADDRESS`**：DyCP 配置 `333.182.141.223`（`333` 非合法 octet，疑似笔误），Baseline `33.182.141.223`。
- **混合 batch 正确性依赖 rank 同步**：long 请求 16 rank 必须同步 decode + 同种子采样，若任一 rank 掉队/失步会导致 token 分裂——`dycp_sampling` 与 DYCP 组 `all_gather` 是同步点。

---

**落盘信息**：本文落盘于 `D:/xym/落盘/DyCP-Decode节点代码逻辑分析.md`。综合（含 Prefill 引擎、抢占/encoder-cache-miss/patch3、参考 PR 全表）见同目录 `DyCP代码处理路径分析.md`；抢占缺陷专题见 `抢占逻辑优化/方案结论.md`。本文所有 file:line 引用均回读 Decode 节点相关源码核对：调度（cross_dp_scheduler.py / request_queue.py / engine/core.py / config/scheduler.py）、运行时（model_runner_v1.py / pcp_utils.py）、attention（mla_cp.py / attention_cp.py / common_cp.py）、采样（dycp_sampling.py）、KV 加载（mooncake_connector.py / ascend_config.py / platform.py）、并行态（parallel_state.py）。
